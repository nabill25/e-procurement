<?php
//include_once 'class.phpmailer.php';
require 'mail/PHPMailerAutoload.php';

class KMail extends PHPMailer{
    function __construct($exceptions = false) {
        parent::__construct($exceptions);

        $this->IsSMTP();
		$this->SMTPOptions = array(
			'ssl' => array(
				'verify_peer' => false,
				'verify_peer_name' => false,
				'allow_self_signed' => true
			)
		);

    $this->SMTPDebug = 0;
    //Ask for HTML-friendly debug output
    $this->Host     = "mail.eproc19.com"; // mail.eproc19.com
    $this->Port     = 465; // 465 or 587
    $this->SMTPAuth = TRUE;
    $this->Username = "noreplay@eproc19.com"; // noreplay@eproc19.com
    $this->Password = "[(9l2L@8C0~D"; // [(9l2L@8C0~D

    $this->From     = "noreplay@eproc19.com";
    $this->FromName = "eProcurement System";
    $this->SMTPSecure  = "ssl";

    $this->WordWrap = 50;
    $this->Priority = 1;
    $this->CharSet = "UTF-8";
    $this->IsHTML(TRUE);
    $this->AltBody    = "To view the message, please use an HTML compatible email viewer!";

    }
}

?>
