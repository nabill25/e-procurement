<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class libkontrak
{
  private $_CI;

  function __construct()
  {
    $this->_CI =& get_instance();
    $this->_CI->load->library('kauth');
    $this->_CI->ID              =  $this->_CI->kauth->getInstance()->getIdentity()->REKANAN_ID;
    $this->_CI->USER_LOGIN_ID   =  $this->_CI->kauth->getInstance()->getIdentity()->USER_LOGIN_ID;
    $this->_CI->USER_LOGIN      =  $this->_CI->kauth->getInstance()->getIdentity()->USER_LOGIN;
    $this->_CI->USER_NAMA       =  $this->_CI->kauth->getInstance()->getIdentity()->USER_NAMA;
    $this->_CI->USER_TYPE_ID    =  $this->_CI->kauth->getInstance()->getIdentity()->USER_TYPE_ID;
    $this->_CI->LEGAL           =  $this->_CI->kauth->getInstance()->getIdentity()->LEGAL;
    $this->_CI->HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
  }

  function baseProses($getTahun='all')
  {
    $this->_CI->load->model("Contracting");
    $getMenu = new Contracting();
    $getMenu->selectMenuProses(array("A.cp_show" => "1"));
    $totalRow = $getMenu->countRow();
    $totalRowPersen = 100 / $totalRow;
    $html  = '';
    $html .= '<ul class="nav nav-tabs process-model more-icon-preocess" role="tablist">';
              while($getMenu->nextRow()){
                $this->_CI->load->model("Contractingrekanan");
                $contractingrekanan = new Contractingrekanan();
                if ($getTahun == 'all' || $getTahun == '') {
                  if ($getMenu->getField('contractingprosesid') == '3'  || $getMenu->getField('contractingprosesid') == '4'
                     ) // Pelaksanaan & Monitoring Berjalan Bersamaan
                  {
                    if ($this->_CI->LEGAL == '1') { // PENG. KONTRAK BAGIAN LEGAL
                      $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID in ('3','4')");
                    } else {
                      if ($this->_CI->USER_TYPE_ID == '20') { // Pemeriksa
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID in ('3','4') AND A.JNS_KONTRAK = '1' ");
                      } else {
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND C.PPK = '".$this->_CI->USER_LOGIN_ID."' AND A.CONTRACTINGPROSESID in ('3','4')");
                      }
                    }
                  } else {
                    if ($this->_CI->LEGAL == '1') { // PENG. KONTRAK BAGIAN LEGAL
                      $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."'");
                    } else {
                      if ($this->_CI->USER_TYPE_ID == '20') { // Pemeriksa
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."' AND A.JNS_KONTRAK = '1'");
                      } else {
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND C.PPK = '".$this->_CI->USER_LOGIN_ID."' AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."'");
                        // echo $contractingrekanan->query;
                      }
                    }
                  }
                } else {
                  if ($getMenu->getField('contractingprosesid') == '3'  || $getMenu->getField('contractingprosesid') == '4'
                     ) // Pelaksanaan & Monitoring Berjalan Bersamaan
                  {
                    if ($this->_CI->LEGAL == '1') { // PENG. KONTRAK BAGIAN LEGAL
                      $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID in ('3','4') AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' ");
                    } else {
                      if ($this->_CI->USER_TYPE_ID == '20') { // Pemeriksa
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID in ('3','4') AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' AND A.JNS_KONTRAK = '1'");
                      } else {
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND C.PPK = '".$this->_CI->USER_LOGIN_ID."' AND A.CONTRACTINGPROSESID in ('3','4') AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' ");
                      }
                    }
                  } else {
                    if ($this->_CI->LEGAL == '1') { // PENG. KONTRAK BAGIAN LEGAL
                      $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."' AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' ");
                    } else {
                      if ($this->_CI->USER_TYPE_ID == '20') { // Pemeriksa
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."' AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' AND A.JNS_KONTRAK = '1'");
                      } else {
                        $totalProses = $contractingrekanan->selectByParamsCount2(array(), " AND C.PPK = '".$this->_CI->USER_LOGIN_ID."' AND A.CONTRACTINGPROSESID = '".$getMenu->getField('CONTRACTINGPROSESID')."' AND date_part('year'::text, CR_LEGAL_TANGGAL) = '".$getTahun."' ");
                      }
                    }
                  }
                }

                $class = '';
                if ($getMenu->getField('cp_link') == 'kontrak/index/'.$this->_CI->uri->segment(3, "")) {
                  $class = 'class="active"';
                }
    $html .=   '<li role="presentation" style="width: '.$totalRowPersen.'% !important;" '.$class.'>
                <a href="'.$getMenu->getField('cp_link').'?tahun='.$getTahun.'">
                  <i class="'.$getMenu->getField('cp_icon').'" aria-hidden="true"></i>
                  <p> <span class="badge badge-primary" style="font-size: 1.3em">'.$totalProses.'</span><br>'.$getMenu->getField('cp_name').' </p>
                </a>
              </li>';
              }
    $html .= '</ul> ';

    return $html;
  }

  function getMenu($contractingrekananid,$reqProses=null)
  {
    $this->_CI->load->model("Contracting");
    $this->_CI->load->model("Contractingrekanan");

    $getMenu = new Contracting();
    $getMenuSub = new Contracting();
    $contractingrekanan = new Contractingrekanan();

    if ($reqProses) {
      $reqProses = $reqProses;
    } else {
      $reqProses = $this->_CI->session->userdata('setProsesKontrak');
    }

    $contractingrekanan->selectByParams(array("A.CONTRACTINGREKANANID" => $contractingrekananid));
    $contractingrekanan->firstRow();
    $contractingprosesid = $contractingrekanan->getField('CONTRACTINGPROSESID');
    $jnsKontrak = $contractingrekanan->getField('JNS_KONTRAK');
    $html  = '<style type="text/css">
      a.list-group-item { color: #000 !important; }
      .list-group-item { padding: 0.7rem 1.25rem !important; }
    </style>';

    // Ketika proses di flow 3 (palaksanaan kontrak) maka flow 4 bisa buka flow 3
    if ($reqProses == '4') { // di Hardcode  $reqProses untuk link di flow 4 ajah
      if ($jnsKontrak == '3') { // Kontrak Payung
        $getMenu->selectMenuProses(array("A.CONTRACTINGPROSESID" => '4'));
        $getMenu->firstRow();
        $cp_name = $getMenu->getField('CP_NAME');
        $cp_link = $getMenu->getField('CP_LINK');
        $getMenuSub->selectMatrix(array("A.CONTRACTINGPROSESID" => '4', "JNS_KONTRAK" => $jnsKontrak), -1, -1, " OR ( A.CONTRACTINGPROSESID = '6' AND JNS_KONTRAK = '3') AND A.CM_STATUS='1'");  // JNS_KONTRAK 0:SPK, 1:PKS, 2:ALL

        $html .= '<div class="list-group">
                    <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> '.$cp_name.'</a>';
                     while($getMenuSub->nextRow())
                     {
                      if ($getMenuSub->getField('cm_link') == 'kontrak/index/'.$this->_CI->uri->segment(3, "") ||
                          ($getMenuSub->getField('cm_name_menu') == "SPPBJ" && $this->_CI->uri->segment(3, "") == 'contracting_persiapan_sppbj_edit')
                          ) {
                        $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                        $colorFotn = ' color:#fff';
                      } else { $colorBg=""; $colorFotn ="";}
        $html .=      '
                          <a class="list-group-item" href="'.$getMenuSub->getField('cm_link').'?reqId='.$contractingrekananid.'&reqProses='.$reqProses.'" style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                            <i class="fa fa-angle-double-right">
                            <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$getMenuSub->getField('cm_name_menu') .' </i>
                             <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$getMenuSub->getField('cm_name') .'</small>
                            </i>
                          </a>
                          ';
                    }
      } else
      {
        $getMenu->selectMenuProses(array("A.CONTRACTINGPROSESID" => '4'));
        $getMenu->firstRow();
        $cp_name = $getMenu->getField('CP_NAME');
        $cp_link = $getMenu->getField('CP_LINK');
        // $getMenuSub->selectMatrix(array("A.CONTRACTINGPROSESID" => '4', "JNS_KONTRAK" => $jnsKontrak), -1, -1, " OR ( A.CONTRACTINGPROSESID = '6' AND JNS_KONTRAK = '2' ) ");  // JNS_KONTRAK 0:SPK, 1:PKS, 2:ALL
        $getMenuSub->selectMatrix(array("A.CONTRACTINGPROSESID" => '4', "JNS_KONTRAK" => $jnsKontrak), -1, -1, " OR ( A.CONTRACTINGPROSESID = '6' AND JNS_KONTRAK = '2' ) OR ( A.CONTRACTINGPROSESID = '4' AND JNS_KONTRAK = '2' ) AND A.CM_STATUS='1'");  // JNS_KONTRAK 0:SPK, 1:PKS, 2:ALL

        $html .= '<div class="list-group">
                    <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> '.$cp_name.'</a>';
                     while($getMenuSub->nextRow())
                     {
                      if ($getMenuSub->getField('cm_link') == 'kontrak/index/'.$this->_CI->uri->segment(3, "") ||
                          ($getMenuSub->getField('cm_name_menu') == "SPPBJ" && $this->_CI->uri->segment(3, "") == 'contracting_persiapan_sppbj_edit')
                          ) {
                        $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                        $colorFotn = ' color:#fff';
                      } else { $colorBg=""; $colorFotn ="";}
        $html .=      '
                        <a class="list-group-item" href="'.$getMenuSub->getField('cm_link').'?reqId='.$contractingrekananid.'&reqProses='.$reqProses.'" style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                          <i class="fa fa-angle-double-right">
                          <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$getMenuSub->getField('cm_name_menu') .' </i>
                            <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$getMenuSub->getField('cm_name') .'</small>
                          </i>
                        </a> ';
                    }
      }
    } else
    {
      if ($jnsKontrak == '3') { // Kontrak Payung
        $getMenu->selectMenuProses(array("A.CONTRACTINGPROSESID" => $contractingprosesid));
        $getMenu->firstRow();
        $cp_name = $getMenu->getField('CP_NAME');
        $cp_link = $getMenu->getField('CP_LINK');
        $getMenuSub->selectMatrix(array("A.CONTRACTINGPROSESID" => $contractingprosesid, "JNS_KONTRAK" => $jnsKontrak), -1, -1, " OR ( A.CONTRACTINGPROSESID = '6' AND JNS_KONTRAK = '3' ) OR ( A.CONTRACTINGPROSESID = '".$contractingprosesid."' AND JNS_KONTRAK = '3' ) AND A.CM_STATUS='1'");  // JNS_KONTRAK 0:SPK, 1:PKS, 2:ALL

        $html .= '<div class="list-group">
                    <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> '.$cp_name.'</a>';
                     while($getMenuSub->nextRow())
                     {
                      if ($getMenuSub->getField('cm_link') == 'kontrak/index/'.$this->_CI->uri->segment(3, "") ||
                          ($getMenuSub->getField('cm_name_menu') == "SPPBJ" && $this->_CI->uri->segment(3, "") == 'contracting_persiapan_sppbj_edit')
                          ) {
                        $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                        $colorFotn = ' color:#fff';
                      } else { $colorBg=""; $colorFotn ="";}
        $html .=      '
                          <a class="list-group-item" href="'.$getMenuSub->getField('cm_link').'?reqId='.$contractingrekananid.'&reqProses='.$reqProses.'" style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                            <i class="fa fa-angle-double-right">
                            <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$getMenuSub->getField('cm_name_menu') .' </i>
                             <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$getMenuSub->getField('cm_name') .'</small>
                            </i>
                          </a>
                          ';
                    }
      } else
      {

        $getMenu->selectMenuProses(array("A.CONTRACTINGPROSESID" => $contractingprosesid));
        $getMenu->firstRow();
        $cp_name = $getMenu->getField('CP_NAME');
        $cp_link = $getMenu->getField('CP_LINK');
        $getMenuSub->selectMatrix(array("A.CONTRACTINGPROSESID" => $contractingprosesid, "JNS_KONTRAK" => $jnsKontrak), -1, -1, " OR ( A.CONTRACTINGPROSESID = '6' AND JNS_KONTRAK = '2' ) OR ( A.CONTRACTINGPROSESID = '".$contractingprosesid."' AND JNS_KONTRAK = '2' ) AND A.CM_STATUS='1'");  // JNS_KONTRAK 0:SPK, 1:PKS, 2:ALL

        $html .= '<div class="list-group">
                    <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> '.$cp_name.'</a>';
                     while($getMenuSub->nextRow())
                     {
                      if ($getMenuSub->getField('cm_link') == 'kontrak/index/'.$this->_CI->uri->segment(3, "") ||
                          ($getMenuSub->getField('cm_name_menu') == "SPPBJ" && $this->_CI->uri->segment(3, "") == 'contracting_persiapan_sppbj_edit')
                          ) {
                        $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                        $colorFotn = ' color:#fff';
                      } else { $colorBg=""; $colorFotn ="";}
        $html .=      '
                          <a class="list-group-item" href="'.$getMenuSub->getField('cm_link').'?reqId='.$contractingrekananid.'&reqProses='.$reqProses.'" style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                            <i class="fa fa-angle-double-right">
                            <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$getMenuSub->getField('cm_name_menu') .' </i>
                             <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$getMenuSub->getField('cm_name') .'</small>
                            </i>
                          </a>
                          ';
                    }
      }
    }
    // $html .=      '<li>
    //                 <div style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
    //                   <a href="kontrak/index/contracting_persiapan_file?reqId='.$contractingrekananid.'">
    //                     <i class="fa fa-angle-double-right">
    //                     <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> Upload File </i>
    //                      <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.ucfirst(strtolower($cp_name)).' </small>
    //                     </i>
    //                   </a>
    //                 </div>
    //               </li>';
    $html .=  '</div>';

    return $html;
  }

  function getMenuPenyedia($contractingrekananid)
  {
    $this->_CI->load->model("Contractingrekanan");
    $contractingrekanan = new Contractingrekanan();
    $proses4 = new Contractingrekanan();

    $contractingrekanan->selectByParams(array("A.CONTRACTINGREKANANID" => $contractingrekananid));
    $contractingrekanan->firstRow();
    $reqjnsKontrak = $contractingrekanan->getField('JNS_KONTRAK');

    $proses4->selectProses4(array("A.CONTRACTINGREKANANID" => $contractingrekananid));
    $proses4->firstRow();
    $reqPerubahan = $proses4->getField('CR_PERUBAHAN');
    $reqPerubahanAlasan = $proses4->getField('CR_PERUBAHAN_ALASAN');
    $reqPenyesuaian = $proses4->getField('CR_PENYESUAIAN');
    $reqPenyesuaianAlasan = $proses4->getField('CR_PENYESUAIAN_ALASAN');
    $reqKahar = $proses4->getField('CR_KAHAR');
    $reqKaharAlasan = $proses4->getField('CR_KAHAR_ALASAN');
    $reqBerakhir = $proses4->getField('CR_BERAKHIR');
    $reqBerakhirAlasan = $proses4->getField('CR_BERAKHIR_ALASAN');
    $reqPemutusan = $proses4->getField('CR_PEMUTUSAN');
    $reqPemutusanAlasan = $proses4->getField('CR_PEMUTUSAN_ALASAN');
    $reqKesempatan = $proses4->getField('CR_KESEMPATAN');
    $reqKesempatanAlasan = $proses4->getField('CR_KESEMPATAN_ALASAN');
    $reqDenda = $proses4->getField('CR_DENDA');
    $reqDendaAlasan = $proses4->getField('CR_DENDA_ALASAN');

    if ($reqjnsKontrak == '3') { // Kontrak Payung
      $jnsKontrak = 'Payung';
      $arrayLink1 = array(
                          'kontrak/index/contracting_penyedia_sppbj_multi',
                          'kontrak/index/contracting_penyedia_perjanjian_multi',
                          'kontrak/index/contracting_penyedia_surat_pesanan_multi',
                          // 'kontrak/index/contracting_penyedia_realisasi_multi',
                          'kontrak/index/contracting_penyedia_termin_multi',
                          // 'kontrak/index/contracting_penyedia_termin_multi',
                         );

      $arrayMenu1 = array(
                          'SPPBJ' => 'Penetapan Surat Penunjukan Penyedia Barang/Jasa',
                          'Data Kontrak Payung' => 'Perancangan Kontrak',
                          'Surat Pesanan' => 'Kontrak',
                          // 'Realisasi Pekerjaan' => 'Kontrak',
                          'Termin Pembayaran' => 'Kontrak',
                          // 'Termin Pembayaran' => 'Kontrak',
                        );

    } else if ($reqjnsKontrak == '1') { // Surat Perjanjian
      $jnsKontrak = 'PKS';
      $arrayLink1 = array(
                          'kontrak/index/contracting_penyedia_sppbj',
                          'kontrak/index/contracting_penyedia_perjanjian',
                          'kontrak/index/contracting_penyedia_realisasi',
                          'kontrak/index/contracting_penyedia_termin',
                         );

      $arrayMenu1 = array(
                          'SPPBJ' => 'Penetapan Surat Penunjukan Penyedia Barang/Jasa',
                          'Data Perjanjian' => 'Perancangan Kontrak',
                          'Realisasi Pekerjaan' => 'Kontrak',
                          'Termin Pembayaran' => 'Kontrak',
                        );

    } else if ($reqjnsKontrak == '0') { // SKP
      $arrayLink1 = array(
                          'kontrak/index/contracting_penyedia_sppbj',
                          'kontrak/index/contracting_penyedia_perjanjian',
                          'kontrak/index/contracting_penyedia_realisasi',
                          'kontrak/index/contracting_penyedia_termin',
                         );

      $arrayMenu1 = array(
                          'SPPBJ' => 'Penetapan Surat Penunjukan Penyedia Barang/Jasa',
                          'Data Perjanjian' => 'Perancangan Kontrak',
                          'Realisasi Pekerjaan' => 'Kontrak',
                          'Termin Pembayaran' => 'Kontrak',
                        );
    }

    if ($reqjnsKontrak == '3') { // Kontrak Payung
      if ($reqPerubahan == '1') {
      $arrayLink2 = array('kontrak/index/contracting_penyedia_perubahan_multi');
      $arrayMenu2 = array('Perubahan' => 'Kontrak');
      } else { $arrayLink2 = array(); $arrayMenu2 = array(); }
    } else {
      if ($reqPerubahan == '1') {
      $arrayLink2 = array('kontrak/index/contracting_penyedia_perubahan');
      $arrayMenu2 = array('Perubahan' => 'Kontrak');
      } else { $arrayLink2 = array(); $arrayMenu2 = array(); }
    }

    if ($reqPenyesuaian == '1') {
    $arrayLink3 = array('kontrak/index/contracting_penyedia_harga');
    $arrayMenu3 = array('Penyesuaian Harga' => 'Kontrak');
    } else { $arrayLink3 = array(); $arrayMenu3 = array(); }

    if ($reqKahar == '1') {
    $arrayLink4 = array('kontrak/index/contracting_penyedia_kahar');
    $arrayMenu4 = array('Keadaan Kahar' => 'Kontrak');
    } else { $arrayLink4 = array(); $arrayMenu4 = array(); }

    if ($reqBerakhir == '1') {
    $arrayLink5 = array('kontrak/index/contracting_penyedia_berakhir');
    $arrayMenu5 = array('Berakhir' => 'Kontrak');
    } else { $arrayLink5 = array(); $arrayMenu5 = array(); }

    if ($reqPemutusan == '1') {
    $arrayLink6 = array('kontrak/index/contracting_penyedia_pemutusan');
    $arrayMenu6 = array('Pemutusan' => 'Kontrak');
    } else { $arrayLink6 = array(); $arrayMenu6 = array(); }

    if ($reqKesempatan == '1') {
    $arrayLink7 = array('kontrak/index/contracting_penyedia_kesempatan');
    $arrayMenu7 = array('Pemberian Kesempatan' => 'Kontrak');
    } else { $arrayLink7 = array(); $arrayMenu7 = array(); }

    if ($reqDenda == '1') {
    $arrayLink8 = array('kontrak/index/contracting_penyedia_denda');
    $arrayMenu8 = array('Sanksi dan Denda' => 'Kontrak');
    } else { $arrayLink8 = array(); $arrayMenu8 = array(); }

    if ($reqjnsKontrak == '3') { // Kontrak Payung
      $arrayLink10 = array('kontrak/index/contracting_multi_penyedia_dokumen',);
      $arrayMenu10 = array('Dokumen Pendukung' => 'file pendukung lainnya');
    } else {
      $arrayLink10 = array('kontrak/index/contracting_penyedia_dokumen',);
      $arrayMenu10 = array('Dokumen Pendukung' => 'file pendukung lainnya');
    }

    $arrayLink = array_merge($arrayLink1,$arrayLink2,$arrayLink3,$arrayLink4,$arrayLink5,$arrayLink6,$arrayLink7,$arrayLink8,$arrayLink10);
    $arrayMenu = array_merge($arrayMenu1,$arrayMenu2,$arrayMenu3,$arrayMenu4,$arrayMenu5,$arrayMenu6,$arrayMenu7,$arrayMenu8,$arrayMenu10);


    $html  = '<style type="text/css">
      a.list-group-item { color: #000 !important; }
      .list-group-item { padding: 0.7rem 1.25rem !important; }
    </style>';
    $html .= '<div class="list-group">
               <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> Kontrak Detail</a>';
                 $no=0;
                 foreach ($arrayMenu as $key => $value) {
                  if ($arrayLink[$no] == 'kontrak/index/'.$this->_CI->uri->segment(3, ""))
                  {
                    $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                    $colorFotn = ' color:#fff';
                  } else { $colorBg=""; $colorFotn ="";}
    $html .=      '
                      <a class="list-group-item" href="'.$arrayLink[$no].'?reqId='.$contractingrekananid.'"  style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                        <i class="fa fa-angle-double-right">
                        <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$key.' </i>
                         <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$value.'</small>
                        </i>
                      </a>
                    ';
                 $no++;
                }

    $html .=  '</div>';

    return $html;
  }

  function getMenuLegal($contractingrekananid)
  {
    $this->_CI->load->model("Contractingrekanan");
    $contractingrekanan = new Contractingrekanan();
    $proses4 = new Contractingrekanan();

    $contractingrekanan->selectByParams(array("A.CONTRACTINGREKANANID" => $contractingrekananid));
    $contractingrekanan->firstRow();
    $reqjnsKontrak = $contractingrekanan->getField('JNS_KONTRAK');

    $proses4->selectProses4(array("A.CONTRACTINGREKANANID" => $contractingrekananid));
    $proses4->firstRow();
    $reqPerubahan = $proses4->getField('CR_PERUBAHAN');
    $reqPerubahanAlasan = $proses4->getField('CR_PERUBAHAN_ALASAN');
    $reqPenyesuaian = $proses4->getField('CR_PENYESUAIAN');
    $reqPenyesuaianAlasan = $proses4->getField('CR_PENYESUAIAN_ALASAN');
    $reqKahar = $proses4->getField('CR_KAHAR');
    $reqKaharAlasan = $proses4->getField('CR_KAHAR_ALASAN');
    $reqBerakhir = $proses4->getField('CR_BERAKHIR');
    $reqBerakhirAlasan = $proses4->getField('CR_BERAKHIR_ALASAN');
    $reqPemutusan = $proses4->getField('CR_PEMUTUSAN');
    $reqPemutusanAlasan = $proses4->getField('CR_PEMUTUSAN_ALASAN');
    $reqKesempatan = $proses4->getField('CR_KESEMPATAN');
    $reqKesempatanAlasan = $proses4->getField('CR_KESEMPATAN_ALASAN');
    $reqDenda = $proses4->getField('CR_DENDA');
    $reqDendaAlasan = $proses4->getField('CR_DENDA_ALASAN');

    if ($reqjnsKontrak == '1') {
      $jnsKontrak = 'Surat Perjanjian';
      $arrayLink1 = array(
                          'kontrak/index/contracting_legal_file',
                          'kontrak/index/contracting_legal_sppbj',
                          'kontrak/index/contracting_legal_perjanjian',
                          'kontrak/index/contracting_legal_realisasi',
                          'kontrak/index/contracting_legal_termin',
                         );

      $arrayMenu1 = array(
                          'Dokumen Pemilihan' => 'dokumen-dokumen hasil sourcing',
                          'SPPBJ' => 'Penetapan Surat Penunjukan Penyedia Barang/Jasa',
                          'Data Perjanjian' => 'Perancangan Kontrak',
                          'Realisasi Pekerjaan' => 'Kontrak',
                          'Termin Pembayaran' => 'Kontrak',
                        );

    } else {
      $arrayLink1 = array(
                          'kontrak/index/contracting_legal_file',
                          'kontrak/index/contracting_legal_perjanjian',
                          'kontrak/index/contracting_legal_realisasi',
                          'kontrak/index/contracting_legal_termin',
                         );

      $arrayMenu1 = array(
                          'Dokumen Pemilihan' => 'dokumen-dokumen hasil sourcing',
                          'Data SPK' => 'Perancangan Kontrak',
                          'Realisasi Pekerjaan' => 'Kontrak',
                          'Termin Pembayaran' => 'Kontrak',
                        );
    }

    if ($reqPerubahan == '1') {
    $arrayLink2 = array('kontrak/index/contracting_legal_perubahan');
    $arrayMenu2 = array('Perubahan' => 'Kontrak');
    } else { $arrayLink2 = array(); $arrayMenu2 = array(); }

    if ($reqPenyesuaian == '1') {
    $arrayLink3 = array('kontrak/index/contracting_legal_harga');
    $arrayMenu3 = array('Penyesuaian Harga' => 'Kontrak');
    } else { $arrayLink3 = array(); $arrayMenu3 = array(); }

    if ($reqKahar == '1') {
    $arrayLink4 = array('kontrak/index/contracting_legal_kahar');
    $arrayMenu4 = array('Keadaan Kahar' => 'Kontrak');
    } else { $arrayLink4 = array(); $arrayMenu4 = array(); }

    if ($reqBerakhir == '1') {
    $arrayLink5 = array('kontrak/index/contracting_legal_berakhir');
    $arrayMenu5 = array('Berakhir' => 'Kontrak');
    } else { $arrayLink5 = array(); $arrayMenu5 = array(); }

    if ($reqPemutusan == '1') {
    $arrayLink6 = array('kontrak/index/contracting_legal_pemutusan');
    $arrayMenu6 = array('Pemutusan' => 'Kontrak');
    } else { $arrayLink6 = array(); $arrayMenu6 = array(); }

    if ($reqKesempatan == '1') {
    $arrayLink7 = array('kontrak/index/contracting_legal_kesempatan');
    $arrayMenu7 = array('Pemberian Kesempatan' => 'Kontrak');
    } else { $arrayLink7 = array(); $arrayMenu7 = array(); }

    if ($reqDenda == '1') {
    $arrayLink8 = array('kontrak/index/contracting_legal_denda');
    $arrayMenu8 = array('Sanksi dan Denda' => 'Kontrak');
    } else { $arrayLink8 = array(); $arrayMenu8 = array(); }

    $arrayLink10 = array('kontrak/index/contracting_legal_dokumen',);
    $arrayMenu10 = array('Dokumen Pendukung' => 'file pendukung lainnya');

    $arrayLink = array_merge($arrayLink1,$arrayLink2,$arrayLink3,$arrayLink4,$arrayLink5,$arrayLink6,$arrayLink7,$arrayLink8,$arrayLink10);
    $arrayMenu = array_merge($arrayMenu1,$arrayMenu2,$arrayMenu3,$arrayMenu4,$arrayMenu5,$arrayMenu6,$arrayMenu7,$arrayMenu8,$arrayMenu10);


    $html  = '<style type="text/css">
      a.list-group-item { color: #000 !important; }
      .list-group-item { padding: 0.7rem 1.25rem !important; }
    </style>';
    $html .= '<div class="list-group">
                <a class="btn-primary text-white list-group-item disabled" style="color:#fff !important;"> Kontrak Detail</a>';

                 $no=0;
                 foreach ($arrayMenu as $key => $value) {
                  if ($arrayLink[$no] == 'kontrak/index/'.$this->_CI->uri->segment(3, ""))
                  {
                    $colorBg = '  background-color: #cf252d !important; opacity: 0.5;';
                    $colorFotn = ' color:#fff';
                  } else { $colorBg=""; $colorFotn ="";}
    $html .=      '
                      <a class="list-group-item" href="'.$arrayLink[$no].'?reqId='.$contractingrekananid.'"  style="border-bottom: 1px solid #f5ebeb; cursor: pointer; '.$colorBg.'">
                        <i class="fa fa-angle-double-right">
                        <i style="height: 20px; font-size: 17px; '.$colorFotn.'"> '.$key.' </i>
                         <small style="font-size: 10px; display: block; font-weight: normal; margin:5px 0 0 12px; '.$colorFotn.'" class="hidden-md">'.$value.'</small>
                        </i>
                      </a>
                      ';
                 $no++;
                }

    $html .=  '</div>';

    return $html;
  }

  function getInfoPaket($reqId)
  {
    $this->_CI->load->model("Paket");
    $paket = new Paket();

    $paket->selectByParamsMonitoring(array(), -1, -1, " AND PAKET_ID = '".$reqId."' ");
    $paket->firstRow();

    $html  = '';
    $html .=  '<div class="alert alert-icon-left alert-arrow-left alert-info mb-2" role="alert">
                <span class="alert-icon"><i class="fa fa-info"></i></span>
                <h4 style="color: #000; font-weight: bold">'.$paket->getField("NAMA").'</h4>
                </div>
                <table class="table table-bordered table-hover">
                  <tbody>
                    <tr>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-calendar"></i> Tahun Anggaran</small> <br>
                        '.getYear($paket->getField("TAHUN_ANGGARAN")).'
                      </td>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-map-marker"></i> Lokasi Pekerjaan</small> <br>
                        '.$paket->getField("LOKASI").'
                      </td>
                    </tr>
                    <tr>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-inbox"></i> Jenis Pengadaan</small> <br>
                        '.$paket->getField("PAKET_JENIS").'
                      </td>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-tag"></i> Metode Pengadaan</small> <br>
                        '.$paket->getField("METODE_LELANG").'
                      </td>
                    </tr>';
                    if ($paket_metode_lelang_id != '6')
                    {
      $html .=      '<tr>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-folder-open"></i> Metode Penyampaian Penawaran</small> <br>
                        '.$paket->getField("SISTEM_SAMPUL").' File
                      </td>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-exchange"></i> Metode Evaluasi</small> <br>
                        '.$paket->getField("METODE_EVALUASI").'
                      </td>
                    </tr>';
                    }

                    if ($paket_metode_lelang_id != '6')
                    {
      $html .=      '<tr>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-file-text"></i> Kualifikasi Usaha</small> <br>
                        '.$paket->getField("REKANAN_KUALIFIKASI").'
                      </td>
                      <td width="25%" colspan="2">
                        <small><i class="fa fa-clock-o"></i> Sistem Negosiasi</small> <br>';

                        if ($paket->getField("BIDDING") == 1) {
                          $html .= 'e-Reverse Auction '.$paket->getField("BIDDING_MENIT").' menit';
                        } else {
                          $html .= "Chatting Nego";
                        }
      $html .=     '</tr>';
                    }
      $html .=     '<tr>
                      <td width="25%" colspan="4">
                        <small><i class="fa fa-money"></i> Perkiraan Nilai Pekerjaan</small> <br>
                        '.$paket->getField("NILAI_MATA_UANG").' '.currencyToPage($paket->getField("NILAI")).'
                      </td>
                      </td>
                    </tr>';

                    if ($paket_metode_lelang_id != '6')
                    { // bukan Purchasing/Pembelian Langsung .'
      $html .=      '<tr>
                      <td width="25%" colspan="4">
                        <small><i class="fa fa-suitcase"></i> Bidang / Sub Bidang</small><br>';
                        if(trim($paket->getField("BIDANG_USAHA2")) == "()")
                            $html .= "-";
                           else
                            $html .= str_replace("---"," <br/> ", $paket->getField("BIDANG_USAHA2"));
      $html .=     ' </td>
                    </tr>
                    <tr>
                      <td width="25%" colspan="4">
                        <small><i class="fa fa-th-list"></i> Persyaratan Peserta</small><br>
                        '.$paket->getField("URAIAN").'
                      </td>
                    </tr>';
                    }
      $html .=   '</tbody>
                </table>';

    return $html;
  }

  // $status=ContractingStatusKontrakId, $id=CONTRACTINGREKANANID, $type=tipe user, $skketerangan=jenis kontrak (SPK/PKS)
  public function getStatusKontrakTeruskan($status,$id,$typeid,$legal,$skketerangan)
  {
    // get jns kontra (SPK/PKS)
    $this->_CI->load->model("Contractingrekanan");
    $spkpks = new Contractingrekanan();
    $spkpks->selectByParams(array("A.CONTRACTINGREKANANID" => $id));
    $spkpks->firstRow();
    $contractingrekananproses1id = $spkpks->getField('CONTRACTINGREKANANPROSES1ID');
    $reqPaketId = $spkpks->getField('PAKET_ID') ?: '-';

    switch ($spkpks->getField('JNS_KONTRAK')) {
      case '0':
        $jnsKontrak = 'SPK';
        break;
      case '1':
        $jnsKontrak = 'Surat Perjanjian';
        break;
      case '2':
        $jnsKontrak = 'ALl';
        break;
      case '3':
        $jnsKontrak = 'Kontrak Payung';
        break;

      default:
        // code...
        break;
    }

    $html  = '';

    if ($skketerangan == 'SPPBJ') {
      if ($status > 0) {
        switch ($status) {
          case '1': // 1:Konfirmasi Penyedia
            if ($typeid == '6') { // Penyedia
             $html .= '<a onClick="prosesKontrak(\'2\',\''.$contractingrekananproses1id.'\',\'Konfirmasi SPPBJ ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> <i class="fa fa-gavel"></i> Konfirmasi SPPBJ </a>';
            } else { // Notif Untuk Pengelola Kontrak
              $html .= '<div class="alert alert-danger mr-1 text-center" style="font-weight:bold; margin-top:1%">. : : Menunggu Konfirmasi dari Penyedia : : .</div>';
            }
            break;

          case '2': // 2:Approve Konfirmasi SPPBJ
            if ($typeid != '6') { // Pengelola Kontrak
              $html .= '<div class="alert alert-info" style="font-weight:bold; margin-top:1%; text-align:center">. : : SPPBJ Sudah Diterima Oleh Penyedia. Silahkan ke tahap selanjutnya pembuatan '.$jnsKontrak.' : : .</div>';
            } else { // Notif Untuk Penyedia
              $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : SPPBJ Sudah Diterima : : .</div>';
            }
            break;

          default:
            $html .= '';
            break;
        }
      } else {
        if ($typeid != '6') { // Pengelola Kontrak
          if ($legal=='' || $legal == '0') { // bukan legal
            $html .= '<a onClick="prosesKontrak(\'1\',\''.$contractingrekananproses1id.'\',\'Kirim SPPBJ ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> '.BTN_KIRIM.' Ke Penyedia </a>';
          }
        } else { // Notif Untuk Penyedia
          $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Tahap Pembuatan SPPBJ : : .</div>';

        }
      }
    }

    if ($skketerangan == 'SPK-PKS') {
      switch ($status) {
        case '3': // 3:Buat SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'4\',\''.$contractingrekananproses1id.'\',\'Kirim '.$jnsKontrak.' ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-send"></i> Kirim Ke Penyedia </a>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Tahap pembuatan '.$jnsKontrak.' : : .</div>';
          }
          break;

        case '4': // 4:Persetujuan Penyedia SPK/PKS
          if ($typeid == '6') { // Penyedia
            $html .= '<a onClick="prosesKontrak(\'5\',\''.$contractingrekananproses1id.'\',\'Setujui '.$jnsKontrak.' ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> <i class="fa fa-gavel"></i> Setujui '.$jnsKontrak.' </a>';
            $html .= '<a onClick="prosesKontrak(\'51\',\''.$contractingrekananproses1id.'\',\'Kembalikan '.$jnsKontrak.' untuk di revisi ?\')" class="'.CLASS_BTN_DANGER.'"> <i class="fa fa-times"></i> Kembalikan '.$jnsKontrak.' </a>';
          } else { // Notif Untuk Pengelola Kontrak
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Menunggu Persetujuan '.$jnsKontrak.' dari Penyedia : : .</div>';
          }
          break;

        case '5': // 4:Approve SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'6\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Pelaksanaan Kontrak ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-gavel"></i> Pelaksanaan Kontrak </a>';
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Sudah Disetujui Oleh Penyedia Silahkan ke tahap selanjutnya Pelaksanaan Kontrak : : .</div>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Sudah Disetujui : : .</div>';
          }
          break;

        case '51': // 4:Tolak SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'4\',\''.$contractingrekananproses1id.'\',\'Kirim '.$jnsKontrak.' ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-send"></i> Kirim Ke Penyedia </a>';
            $html .= '<div class="'.CLASS_BTN_DANGER.'" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Di Kembalikan Oleh Penyedia Silahkan revisi dan kirim kembali : : .</div>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' sedang di revisi : : .</div>';
          }
          break;

        default:
          $html .= '';
          break;
      }
    }

    if ($skketerangan == 'PELAKSANAAN') {
      switch ($status) {
        case '6': // 6: Pelaksanaan Kontrak
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sedang Berjalan : : .</div>';
          }
          break;
        case '7': // 7: Perubahan Kontrak
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '8': // 8: Penyesuaian Harga
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '9': // 9: Keadaan Kahar
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '10': // 10: Berakhir Kontrak
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '11': // 11: Pemutusan Kontrak
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '12': // 12: Pemberian Kesempatan
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;
        case '13': // 13: Sanksi dan Denda
          if ($typeid != '6') { // Pengelola Kontrak
            $url3 = $this->_CI->uri->segment(3, "");
            if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
              $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
            }
          } else { // Notif Untuk Penyedia
            $html .= '<div class="aler alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
          }
          break;

        default:
          $html .= '';
          break;
      }
    }

    if ($skketerangan == 'PENUTUPAN') {
      if ($spkpks->getField('JNS_KONTRAK') == '3') { // Kontrak Payung
        $html .= '<a onClick="prosesKontrak(\'200\',\''.$contractingrekananproses1id.'\',\'Apakah anda yakin kontrak sudah selesai ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Kontrak Selesai ?</a>';
      } else
      {
        switch ($status) {
          case '100': // 100: Penutupan Kontrak
            if ($typeid != '6') { // bukan penyedia tapi Pengelola Kontrak
              $spkpksKontrak = new Contractingrekanan();
              $spkpksKontrak->selectViewPKSSPK(array("A.CONTRACTINGREKANANID" => $id));
              $spkpksKontrak->firstRow();

              $reqNilaiKontrak = $spkpksKontrak->getField('CR_NILAI_KONTRAK') ?: '-';
              $reqJnsKontrak = $spkpksKontrak->getField('JNS_KONTRAK') ?: '0';

              // if ($reqJnsKontrak == '1') { // Jika Kontrak PKS maka harus melalui persetutujuan pemeriksa kontrak atau > 1M
                $proses5 = new Contractingrekanan();
                $proses5->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
                $proses5->firstRow();
                $reqApprovalPemeriksa = $proses5->getField('CR_PEMERIKSA_APPROVAL');

                // if ($reqJnsKontrak == '1' && $typeid == '20') { // Jika Kontrak PKS maka harus melalui persetutujuan pemeriksa kontrak atau > 1M dan Pemeriksa Kontrak
                //   // code...
                //   if ($reqApprovalPemeriksa == '1') {
                //     $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sudah di approve : : .</div>';
                //   } else {
                //     $proses5Total = new Contractingrekanan();
                //     $proses5Total->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
                //     if ($proses5Total->countRow() > 0) {
                //       $html .= '<a onClick="approvalKontrak('.$id.')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Approve Kontrak ?</a>';
                //     } else {
                //       $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : BAST Belum di isi oleh Pengelola Kontrak : : .</div>';
                //     }
                //   }
                // } else { // Jika SPK Tidak perlu approval pemeriksa
                  if ($typeid == '12') { // Pengelola Kontrak
                    $proses5Total = new Contractingrekanan();
                    $proses5Total->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
                    // if ($proses5Total->countRow() > 0) {
                      // if ($reqJnsKontrak == '1' && $reqApprovalPemeriksa == '1') { // PKS & sudah approval pemeriksa kontrak
                        $html .= '<a onClick="prosesKontrak(\'200\',\''.$contractingrekananproses1id.'\',\'Apakah anda yakin kontrak sudah selesai ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Kontrak Selesai ?</a>';
                      } else if ($reqJnsKontrak == '0') {
                        $html .= '<a onClick="prosesKontrak(\'200\',\''.$contractingrekananproses1id.'\',\'Apakah anda yakin kontrak sudah selesai ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Kontrak Selesai ?</a>';
                      }
                    // } else {
                      // $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : BAST Belum di isi oleh Pengelola Kontrak : : .</div>';
                    // }
                  // }
                // }


              // }


            } else { // Notif Untuk Penyedia
              $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sedang proses Serah Terima Pekerjaan : : .</div>';
            }
            break;

          default:
            $html .= '';
            break;
        }
      }
    }

    $html .= '';

    return $html;
  }

  // $status=ContractingStatusKontrakId, $id=CONTRACTINGREKANANID, $type=tipe user, $skketerangan=jenis kontrak (SPK/PKS)
  public function getStatusKontrakTeruskanMulti($status,$id,$typeid,$legal,$skketerangan)
  {
    // get jns kontra (SPK/PKS)
    $this->_CI->load->model("Contractingrekanan");

    if ($typeid == '6') { // Penyedia
      $spkpks = new Contractingrekanan();
      $spkpks->selectByParams(array("A.CONTRACTINGREKANANPROSES1ID" => $id));
      $spkpks->firstRow();
      $contractingrekananproses1id = $spkpks->getField('CONTRACTINGREKANANPROSES1ID');
      $reqPaketId = $spkpks->getField('PAKET_ID') ?: '-';
    } else { // Pengelola Kontrak
      $spkpks = new Contractingrekanan();
      $spkpks->selectByParams(array("A.CONTRACTINGREKANANID" => $id));
      $spkpks->firstRow();
      $contractingrekananproses1id = $spkpks->getField('CONTRACTINGREKANANPROSES1ID');
      $reqPaketId = $spkpks->getField('PAKET_ID') ?: '-';
    }

    switch ($spkpks->getField('JNS_KONTRAK')) {
      case '0':
        $jnsKontrak = 'SPK';
        break;
      case '1':
        $jnsKontrak = 'Surat Perjanjian';
      case '2':
        $jnsKontrak = 'ALl';
        break;
      case '3':
        $jnsKontrak = 'Kontrak Payung';
        break;

      default:
        // code...
        break;
    }

    $html  = '';

    if ($skketerangan == 'SPPBJ') {
      if ($status > 0) {
        switch ($status) {
          case '1': // 1:Konfirmasi Penyedia
            if ($typeid == '6') { // Penyedia
             $html .= '<a onClick="prosesKontrak(\'2\',\''.$id.'\',\'Konfirmasi SPPBJ ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> <i class="fa fa-gavel"></i> Konfirmasi SPPBJ </a>';
            } else { // Notif Untuk Pengelola Kontrak
              $html .= '<div class="alert alert-danger mr-1 text-center" style="font-weight:bold; margin-top:1%">. : : Menunggu Konfirmasi dari Penyedia : : .</div>';
            }
            break;

          case '2': // 2:Approve Konfirmasi SPPBJ
            if ($typeid != '6') { // Pengelola Kontrak
              $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%;">. : : SPPBJ Sudah Diterima Oleh Penyedia. Silahkan ke tahap selanjutnya pembuatan '.$jnsKontrak.' : : .</div>';
            } else { // Notif Untuk Penyedia
              $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : SPPBJ Sudah Diterima : : .</div>';
            }
            break;

          default:
            $html .= '';
            break;
        }
      } else {
        if ($typeid != '6') { // Pengelola Kontrak
          if ($legal=='' || $legal == '0') { // bukan legal
            $html .= '<a onClick="prosesKontrak(\'1\',\''.$id.'\',\'Kirim SPPBJ ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> '.BTN_KIRIM.' Ke Penyedia </a>';
          }
        } else { // Notif Untuk Penyedia
          $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Tahap Pembuatan SPPBJ : : .</div>';

        }
      }
    }

    if ($skketerangan == 'SPK-PKS') {
      switch ($status) {
        case '3': // 3:Buat SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'4\',\''.$id.'\',\'Kirim '.$jnsKontrak.' ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-send"></i> Kirim Ke Penyedia </a>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Tahap pembuatan '.$jnsKontrak.' : : .</div>';
          }
          break;

        case '4': // 4:Persetujuan Penyedia SPK/PKS
          if ($typeid == '6') { // Penyedia
            $html .= '<a onClick="prosesKontrak(\'5\',\''.$id.'\',\'Setujui '.$jnsKontrak.' ?\')" class="'.CLASS_BTN_SUCCESS.' mr-1"> <i class="fa fa-gavel"></i> Setujui '.$jnsKontrak.' </a>';
            // $html .= '<a onClick="prosesKontrak(\'51\',\''.$contractingrekananproses1id.'\',\'Kembalikan '.$jnsKontrak.' untuk di revisi ?\')" class="'.CLASS_BTN_DANGER.'"> <i class="fa fa-times"></i> Kembalikan '.$jnsKontrak.' </a>';
          } else { // Notif Untuk Pengelola Kontrak
            $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Menunggu Persetujuan '.$jnsKontrak.' dari Penyedia : : .</div>';
          }
          break;

        case '5': // 4:Approve SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'6\',\''.$id.'\',\'Lanjut ke Pelaksanaan Kontrak ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-gavel"></i> Pelaksanaan Kontrak </a>';
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Sudah Disetujui Oleh Penyedia Silahkan ke tahap selanjutnya Pelaksanaan Kontrak : : .</div>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Sudah Disetujui : : .</div>';
          }
          break;

        case '51': // 4:Tolak SPK/PKS
          if ($typeid != '6') { // Pengelola Kontrak
            $html .= '<a onClick="prosesKontrak(\'4\',\''.$contractingrekananproses1id.'\',\'Kirim '.$jnsKontrak.' ke Penyedia ?\')" class="'.CLASS_BTN_SUCCESS.'"> <i class="fa fa-send"></i> Kirim Ke Penyedia </a>';
            $html .= '<div class="'.CLASS_BTN_DANGER.'" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' Di Kembalikan Oleh Penyedia Silahkan revisi dan kirim kembali : : .</div>';
          } else { // Notif Untuk Penyedia
            $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : '.$jnsKontrak.' sedang di revisi : : .</div>';
          }
          break;

        default:
          $html .= '';
          break;
      }
    }

    // if ($skketerangan == 'PELAKSANAAN') {
    //   switch ($status) {
    //     case '6': // 6: Pelaksanaan Kontrak
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sedang Berjalan : : .</div>';
    //       }
    //       break;
    //     case '7': // 7: Perubahan Kontrak
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '8': // 8: Penyesuaian Harga
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '9': // 9: Keadaan Kahar
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '10': // 10: Berakhir Kontrak
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '11': // 11: Pemutusan Kontrak
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '12': // 12: Pemberian Kesempatan
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;
    //     case '13': // 13: Sanksi dan Denda
    //       if ($typeid != '6') { // Pengelola Kontrak
    //         $url3 = $this->_CI->uri->segment(3, "");
    //         if ($url3 == 'contracting_pengelolaan_realisasi' || $url3 == 'contracting_pengelolaan_termin') {
    //           $html .= '<a onClick="prosesKontrak(\'100\',\''.$contractingrekananproses1id.'\',\'Lanjut ke Penutupan Kontrak ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Penutupan Kontrak </a>';
    //         }
    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="aler alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Perubahan Kontrak : : .</div>';
    //       }
    //       break;

    //     default:
    //       $html .= '';
    //       break;
    //   }
    // }

    // if ($skketerangan == 'PENUTUPAN') {
    //   switch ($status) {
    //     case '100': // 100: Penutupan Kontrak
    //       if ($typeid != '6') { // bukan penyedia tapi Pengelola Kontrak
    //         $spkpksKontrak = new Contractingrekanan();
    //         $spkpksKontrak->selectViewPKSSPK(array("A.CONTRACTINGREKANANID" => $id));
    //         $spkpksKontrak->firstRow();

    //         $reqNilaiKontrak = $spkpksKontrak->getField('CR_NILAI_KONTRAK') ?: '-';
    //         $reqJnsKontrak = $spkpksKontrak->getField('JNS_KONTRAK') ?: '0';

    //         // if ($reqJnsKontrak == '1') { // Jika Kontrak PKS maka harus melalui persetutujuan pemeriksa kontrak atau > 1M
    //           $proses5 = new Contractingrekanan();
    //           $proses5->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
    //           $proses5->firstRow();
    //           $reqApprovalPemeriksa = $proses5->getField('CR_PEMERIKSA_APPROVAL');

    //           // if ($reqJnsKontrak == '1' && $typeid == '20') { // Jika Kontrak PKS maka harus melalui persetutujuan pemeriksa kontrak atau > 1M dan Pemeriksa Kontrak
    //           //   // code...
    //           //   if ($reqApprovalPemeriksa == '1') {
    //           //     $html .= '<div class="alert alert-info text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sudah di approve : : .</div>';
    //           //   } else {
    //           //     $proses5Total = new Contractingrekanan();
    //           //     $proses5Total->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
    //           //     if ($proses5Total->countRow() > 0) {
    //           //       $html .= '<a onClick="approvalKontrak('.$id.')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Approve Kontrak ?</a>';
    //           //     } else {
    //           //       $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : BAST Belum di isi oleh Pengelola Kontrak : : .</div>';
    //           //     }
    //           //   }
    //           // } else { // Jika SPK Tidak perlu approval pemeriksa
    //             if ($typeid == '12') { // Pengelola Kontrak
    //               $proses5Total = new Contractingrekanan();
    //               $proses5Total->selectProses5(array("A.CONTRACTINGREKANANID" => $id));
    //               if ($proses5Total->countRow() > 0) {
    //                 // if ($reqJnsKontrak == '1' && $reqApprovalPemeriksa == '1') { // PKS & sudah approval pemeriksa kontrak
    //                   $html .= '<a onClick="prosesKontrak(\'200\',\''.$contractingrekananproses1id.'\',\'Apakah anda yakin kontrak sudah selesai ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Kontrak Selesai ?</a>';
    //                 } else if ($reqJnsKontrak == '0') {
    //                   $html .= '<a onClick="prosesKontrak(\'200\',\''.$contractingrekananproses1id.'\',\'Apakah anda yakin kontrak sudah selesai ?\')" class="'.CLASS_BTN_WARNING.'"> <i class="fa fa-gavel"></i> Kontrak Selesai ?</a>';
    //                 }
    //               } else {
    //                 $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : BAST Belum di isi oleh Pengelola Kontrak : : .</div>';
    //               }
    //             // }
    //           // }


    //         // }


    //       } else { // Notif Untuk Penyedia
    //         $html .= '<div class="alert alert-danger text-center" style="font-weight:bold; margin-top:1%">. : : Kontrak sedang proses Serah Terima Pekerjaan : : .</div>';
    //       }
    //       break;

    //     default:
    //       $html .= '';
    //       break;
    //   }
    // }

    $html .= '';

    return $html;
  }

  public function getTableFile($reqId,$statement=null)
  {

    $this->_CI->load->model("Contractingfile");

    $contractingfile = new Contractingfile();
    $contractingfile->selectByParams(array("A.CONTRACTINGREKANANID" => $reqId),-1,-1,$statement);

    $html  =  '';
    $html .= '
      <thead>
        <tr class="backcolornew">
          <th class="text-center" width="10px">No<br>&nbsp;</th>
          <th>Nama Dokumen<br>&nbsp;</th>
          <th>Keterangan<br>&nbsp;</th>
          <th class="text-center" width="20px">Tahap<br>&nbsp;</th>';
    if ($this->_CI->USER_TYPE_ID != '20') { // Bukan Pemeriksa Kontrak
    $html .= '
          <th class="text-center" width="10px">Kirim ke<br> Penyedia</th>';
    }

    $html .= '
          <th class="text-center" width="10px">Aksi<br>&nbsp;</th>
        </tr>
      </thead>';
      $html .= '
      <tbody> ';
        $no=1;
        if ($contractingfile->countRow() > 0) {
          while($contractingfile->nextRow())
          {
            switch ($contractingfile->getField('contractingprosesid')) {
              case '1': // Inisisai
                $tahap = '<span class="badge badge-info">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '2': // Perencanaan
                $tahap = '<span class="badge badge-primary">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '3': // Pelaksanaan
                $tahap = '<span class="badge badge-warning">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '4': // Monitoring
                $tahap = '<span class="badge badge-success">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '5': // Penutupan
                $tahap = '<span class="badge badge-danger">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '6': // Selesai
                $tahap = '<span class="badge badge-dark">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;

              default:
                break;
            }

            if ($contractingfile->getField('file_nama_encrypt') != '' && file_exists($contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt'))) {
              $linkDok = '<a href="'.$contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt').'" target="_blank">'.$contractingfile->getField('file_nama').'</a>';
            } else {
              $linkDok = $contractingfile->getField('file_nama');
            }

            if ($contractingfile->getField('file_publish_penyedia') == '1') {
              $publish = '<a onClick="publishFile(\'contracting_json/publishFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").',\'0\')" class="fa fa-check btn-xs btn-primary" style="padding:5px; border-radius:4px; color:#fff"></a>';
            } else {
              $publish = '<a onClick="publishFile(\'contracting_json/publishFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").',\'1\')" class="fa fa-times btn-xs btn-danger" style="padding:5px; border-radius:4px; color:#fff"></a>';
            }

      $html .= '
            <tr>
              <td class="text-center">'.$no.'</td>
              <td>
                '.$linkDok.'<br>
                <span class="badge badge-primary">Jenis Dok: '.$contractingfile->getField('file_jenis').'</span> <br>
                <small><i>Oleh: '.$contractingfile->getField('created_by_str').'</i></small>
              </td>
              <td>'.$contractingfile->getField('file_keterangan').'</td>
              <td class="text-center">'.$tahap.'</td>';
      if ($this->_CI->USER_TYPE_ID != '20') { // Bukan Pemeriksa Kontrak
      $html .= '
              <td class="text-center">'.$publish.'</td>';
      }
      if ($contractingfile->getField('created_by') == $this->_CI->USER_LOGIN_ID) {
      $html .= '<td class="text-center"><a onClick="deleteData(\'contracting_json/deleteFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").')"><span class="fa fa-trash btn-xs btn-danger" style="padding:5px; border-radius:4px"></span></a></td>';
      } else {
      $html .= '<td class="text-center">-</td>';
      }
      $html .= '
            </tr>
           ';
            $no++;
          }
        } else {
          // echo '<tr><td colspan="6">. : : Tidak ada dokumen : : .</td></tr>';
          // $html .= '<tr><td>. : : Tidak ada dokumen : : .</td></tr>';
        }
    $html .= '
      </tbody>';

    return $html;
  }

  public function getTableFileMulti($reqId,$statement=null)
  {

    $this->_CI->load->model("Contractingfile");

    $contractingfile = new Contractingfile();
    $contractingfile->selectByParamsMulti(array("A.CONTRACTINGREKANANID" => $reqId),-1,-1,$statement);

    $html  =  '';
    $html .= '
      <thead>
        <tr class="backcolornew">
          <th class="text-center" width="10px">No<br>&nbsp;</th>
          <th>Nama Dokumen<br>&nbsp;</th>
          <th>Keterangan<br>&nbsp;</th>
          <th class="text-center" width="20px">Tahap<br>&nbsp;</th>';
    if ($this->_CI->USER_TYPE_ID != '20') { // Bukan Pemeriksa Kontrak
    $html .= '
          <th class="text-center" width="10px">Kirim ke<br> Penyedia</th>';
    }

    $html .= '
          <th class="text-center" width="10px">Aksi<br>&nbsp;</th>
        </tr>
      </thead>';
      $html .= '
      <tbody> ';
        $no=1;
        if ($contractingfile->countRow() > 0) {
          while($contractingfile->nextRow())
          {
            switch ($contractingfile->getField('contractingprosesid')) {
              case '1': // Inisisai
                $tahap = '<span class="badge badge-info">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '2': // Perencanaan
                $tahap = '<span class="badge badge-primary">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '3': // Pelaksanaan
                $tahap = '<span class="badge badge-warning">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '4': // Monitoring
                $tahap = '<span class="badge badge-success">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '5': // Penutupan
                $tahap = '<span class="badge badge-danger">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;
              case '6': // Selesai
                $tahap = '<span class="badge badge-dark">'.str_replace('KONTRAK','',$contractingfile->getField('proses_str')).'</span>'; break;

              default:
                break;
            }

            if ($contractingfile->getField('file_nama_encrypt') != '' && file_exists($contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt'))) {
              $linkDok = '<a href="'.$contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt').'" target="_blank">'.$contractingfile->getField('file_nama').'</a>';
            } else {
              $linkDok = $contractingfile->getField('file_nama');
            }

            if ($contractingfile->getField('file_publish_penyedia') == '1') {
              $publish = '<a onClick="publishFile(\'contracting_json/publishFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").',\'0\')" class="fa fa-check btn-xs btn-primary" style="padding:5px; border-radius:4px; color:#fff"></a><br>';
              if ($contractingfile->getField('created_by') == $this->_CI->USER_LOGIN_ID) {
                $publish .= '<small style="font-size:10px">'.$contractingfile->getField('nama').'</small>';
              }
            } else {
              $publish = '<a onClick="publishFile(\'contracting_json/publishFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").',\'1\')" class="fa fa-times btn-xs btn-danger" style="padding:5px; border-radius:4px; color:#fff"></a>';
            }

      $html .= '
            <tr>
              <td class="text-center">'.$no.'</td>
              <td>
                '.$linkDok.'<br>
                <span class="badge badge-primary">Jenis Dok: '.$contractingfile->getField('file_jenis').'</span> <br>
                <small><i>Oleh: '.$contractingfile->getField('created_by_str').'</i></small>
              </td>
              <td>'.$contractingfile->getField('file_keterangan').'</td>
              <td class="text-center">'.$tahap.'</td>';
      if ($this->_CI->USER_TYPE_ID != '20') { // Bukan Pemeriksa Kontrak
      $html .= '
              <td class="text-center">'.$publish.'</td>';
      }
      if ($contractingfile->getField('created_by') == $this->_CI->USER_LOGIN_ID) {
      $html .= '<td class="text-center"><a onClick="deleteData(\'contracting_json/deleteFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").')"><span class="fa fa-trash btn-xs btn-danger" style="padding:5px; border-radius:4px"></span></a></td>';
      } else {
      $html .= '<td class="text-center">-</td>';
      }
      $html .= '
            </tr>
           ';
            $no++;
          }
        } else {
          // echo '<tr><td colspan="6">. : : Tidak ada dokumen : : .</td></tr>';
          // $html .= '<tr><td>. : : Tidak ada dokumen : : .</td></tr>';
        }
    $html .= '
      </tbody>';

    return $html;
  }

  public function getTableFilePenyedia($reqId,$statement=null)
  {

    $this->_CI->load->model("Contractingfile");

    $contractingfile = new Contractingfile();
    $contractingfile->selectByParams(array("A.CONTRACTINGREKANANID" => $reqId),-1,-1,$statement);
    // echo $contractingfile->query; die;

    $html  =  '';
    $html .= '
      <thead>
        <tr class="backcolornew">
          <th class="text-center" width="10px">No<br>&nbsp;</th>
          <th>Nama Dokumen<br>&nbsp;</th>
          <th>Keterangan<br>&nbsp;</th>
          <th class="text-center" width="10px">Aksi<br>&nbsp;</th>
        </tr>
      </thead>';
      $html .= '
      <tbody> ';
        $no=1;
        if ($contractingfile->countRow() > 0) {
          while($contractingfile->nextRow())
          {
            if ($contractingfile->getField('file_nama_encrypt') != '' && file_exists($contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt'))) {
              $linkDok = '<a href="'.$contractingfile->getField('file_path').'/'.$contractingfile->getField('file_nama_encrypt').'" target="_blank">'.$contractingfile->getField('file_nama').'</a>';
            } else {
              $linkDok = $contractingfile->getField('file_nama');
            }

      $html .= '
            <tr>
              <td class="text-center">'.$no.'</td>
              <td>
                '.$linkDok.'<br>
                <span class="badge badge-primary">Jenis Dok: '.$contractingfile->getField('file_jenis').'</span>';
      if ($contractingfile->getField('created_by') == $this->_CI->USER_LOGIN_ID) {
      $html .= '<br> <small><i>Oleh: '.$contractingfile->getField('created_by_str').'</i></small>';
      }
      $html .= '</td>
              <td>'.$contractingfile->getField('file_keterangan').'</td>';
              if ($contractingfile->getField('created_by') == $this->_CI->USER_LOGIN_ID) {
      $html .= '<td class="text-center"><a onClick="deleteData(\'contracting_json/deleteFile/\', '.$contractingfile->getField("CONTRACTINGFILEID").')"><span class="fa fa-trash btn-xs btn-danger" style="padding:5px; border-radius:4px"></span></a></td>';
      } else {
      $html .= '<td class="text-center">-</td>';
      }
      $html .= '
            </tr>
           ';
            $no++;
          }
        } else {
          // $html .= '<tr><td></td><td>. : : Tidak ada dokumen : : .</td><td></td><td></td></tr>';
        }
    $html .= '
      </tbody>';

    return $html;
  }

  public function getDokumenPendukung($paketId,$pemenangid=null)
  {
    $html  = '';
    $this->_CI->load->model("PermohonanPaketFile");
    $this->_CI->load->model("PaketDokumen");
    $this->_CI->load->model("Paket");
    $this->_CI->load->model("PaketRekanan");

    // Dokumen Pendukung dari Proses Pengadaan yang sudah dilaksanakan

    $paket = new Paket();
    $permohonan_paket_file = new PermohonanPaketFile();
    $paket_dokumen = new PaketDokumen();
    $paket_dokumen_ba_evaluasi = new PaketDokumen();
    $paket_rekanan = new PaketRekanan();
    $paket_dokumen_penawaran = new PaketDokumen();

    // Password Penawaran
    $paket_rekanan->selectByParams2(array("A.PAKET_ID" => $paketId, "A.REKANAN_ID" => $pemenangid), -1, -1, " AND A.TANGGAL_DAFTAR IS NOT NULL AND A.LULUS_PENDAFTARAN = 1 AND A.LULUS_KUALIFIKASI = 1 AND A.KIRIM_PENAWARAN = 1 ");
    $paket_rekanan->firstRow();

    // Dok. Permohonan
    $paket->selectByParamsMonitoring(array(), -1, -1, " AND PAKET_ID = '".$paketId."' ");
    $paket->firstRow();
    $reqPermohonanPaket = $paket->getField("PERMOHONAN_PAKET_ID");
    $permohonan_paket_file->selectByParams(array("PERMOHONAN_PAKET_ID" => coalesce($reqPermohonanPaket, 0)));

    // Dok. BA Aanwijzing
    $paket_dokumen->selectByParams(array("PAKET_ID" => $paketId),-1,-1," AND (JENIS_DOKUMEN = 'LELANG' OR JENIS_DOKUMEN = 'BERITA_ACARA_AANWIJZING') ");
    // Dok. BA Evaluasi Penawaran
    $paket_dokumen_ba_evaluasi->selectByParams(array("PAKET_ID" => $paketId),-1,-1," AND (JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_ADMINISTRASI' OR JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_TEKNIS' OR JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_HARGA') ");
    // Dok. Penawaran
    $paket_dokumen_penawaran->selectByParams(array("PAKET_ID" => $paketId, "REKANAN_USER_ID" => $pemenangid), -1, -1, " AND JENIS_DOKUMEN LIKE 'PENAWARAN%' ");



    $html .= '
              <script type="text/javascript">
                function myFunction(a) {
                  var id = "myPass"+a;
                  var copyText = document.getElementById(id);
                  copyText.select();
                  copyText.setSelectionRange(0, 99999)
                  document.execCommand("copy");
                  // alert("Copied the text: " + copyText.value);
                  alert("Password disalin "+copyText.value);
                }
              </script>
              <table class="table-bordered table mb-0">
                <thead>
                  <tr class="judul-kolom">
                    <th style="width: 90%">Nama Dokumen</th>
                    <th>Download</th>
                  </tr>
                </thead>
                <tbody id="tbodyPermohonanPaketFile">';
                    // Dok. Permohonan Paket
                    while($permohonan_paket_file->nextRow())
                    {

    $html .= '      <tr>
                       <td>'.$permohonan_paket_file->getField("JUDUL").'</td>
                       <td style="text-align: center;">';
                          if ($permohonan_paket_file->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/permohonan_paket/'.$permohonan_paket_file->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }
                     // Dok. dokumen pengadaan
                     while($paket_dokumen->nextRow())
                     {
    $html .= '      <tr>
                       <td>'.$paket_dokumen->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/lelang/'.$paket_dokumen->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }
                     if ($paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD")) {
    $html .= '      <tr>
                       <td>
                        Password Dok. Penawaran <br>
                        <a onClick="return myFunction(\'1\')">
                          <div class="input-group" style="margin-top:1%">
                            <div class="input-group-prepend">
                              <i class="fa fa-copy"></i> &nbsp;&nbsp;
                            </div>
                            <input class="form-control" type="text" value="'.$paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD").'" id="myPass1" style="border:none; height:10px; cursor:copy;" readonly>
                          </div>
                        </a>
                        ';
                          if ($paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD2")) {
    $html .= '            <br>
                            <a onClick="return myFunction(\'2\')">
                            <div class="input-group" style="margin-top:1%">
                              <div class="input-group-prepend">
                                <i class="fa fa-copy"></i> &nbsp;&nbsp;
                              </div>
                              <input class="form-control" type="text" value="'.$paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD2").'" id="myPass2" style="border:none; height:10px; cursor:copy;" readonly>
                            </div>
                          </a>';
                          }
    $html .= '          </td>';
    $html .= '          <td style="text-align: center;"> <span class="fa fa-lock"></span></td>';
    $html .= '         </tr>';
                     }
                     // Dok. Penawaran Pemenang
                     while($paket_dokumen_penawaran->nextRow())
                     {
    $html .= '      <tr>
                       <td>'.$paket_dokumen_penawaran->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen_penawaran->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/penawaran/'.$paket_dokumen_penawaran->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }

                     // Dok. BA Evaluasi
                     while($paket_dokumen_ba_evaluasi->nextRow())
                     {
    $html .= '      <tr>
                       <td>Berita Acara '.$paket_dokumen_ba_evaluasi->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen_ba_evaluasi->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/penawaran/'.$paket_dokumen_ba_evaluasi->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }

    $html .= '    </tbody>
              </table>
              ';

    return $html;
  }

  public function getDokumenPendukungMulti($paketId,$pemenangid=null)
  {
    $html  = '';
    $this->_CI->load->model("PermohonanPaketFile");
    $this->_CI->load->model("PaketDokumen");
    $this->_CI->load->model("Paket");
    $this->_CI->load->model("PaketRekanan");

    // Dokumen Pendukung dari Proses Pengadaan yang sudah dilaksanakan

    $paket = new Paket();
    $permohonan_paket_file = new PermohonanPaketFile();
    $paket_dokumen = new PaketDokumen();
    $paket_dokumen_ba_evaluasi = new PaketDokumen();
    $paket_rekanan = new PaketRekanan();
    $paket_dokumen_penawaran = new PaketDokumen();

    // Password Penawaran
    $paket_rekanan->selectByParams2(array("A.PAKET_ID" => $paketId, "A.REKANAN_ID" => $pemenangid), -1, -1, " AND A.TANGGAL_DAFTAR IS NOT NULL AND A.LULUS_PENDAFTARAN = 1 AND A.LULUS_KUALIFIKASI = 1 AND A.KIRIM_PENAWARAN = 1 ");
    $paket_rekanan->firstRow();

    // Dok. Permohonan
    $paket->selectByParamsMonitoring(array(), -1, -1, " AND PAKET_ID = '".$paketId."' ");
    $paket->firstRow();
    $reqPermohonanPaket = $paket->getField("PERMOHONAN_PAKET_ID");
    $permohonan_paket_file->selectByParams(array("PERMOHONAN_PAKET_ID" => coalesce($reqPermohonanPaket, 0)));

    // Dok. BA Aanwijzing
    $paket_dokumen->selectByParams(array("PAKET_ID" => $paketId),-1,-1," AND (JENIS_DOKUMEN = 'LELANG' OR JENIS_DOKUMEN = 'BERITA_ACARA_AANWIJZING') ");
    // Dok. BA Evaluasi Penawaran
    $paket_dokumen_ba_evaluasi->selectByParams(array("PAKET_ID" => $paketId),-1,-1," AND (JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_ADMINISTRASI' OR JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_TEKNIS' OR JENIS_DOKUMEN = 'EVALUASI_PENAWARAN_HARGA') ");
    // Dok. Penawaran
    $paket_dokumen_penawaran->selectByParams(array("PAKET_ID" => $paketId, "REKANAN_USER_ID" => $pemenangid), -1, -1, " AND JENIS_DOKUMEN LIKE 'PENAWARAN%' ");



    $html .= '
              <script type="text/javascript">
                function myFunction(a) {
                  var id = "myPass"+a;
                  var copyText = document.getElementById(id);
                  copyText.select();
                  copyText.setSelectionRange(0, 99999)
                  document.execCommand("copy");
                  // alert("Copied the text: " + copyText.value);
                  alert("Password disalin "+copyText.value);
                }
              </script>
              <table class="table-bordered table mb-0">
                <thead>
                  <tr class="judul-kolom">
                    <th style="width: 90%">Nama Dokumen</th>
                    <th>Download</th>
                  </tr>
                </thead>
                <tbody id="tbodyPermohonanPaketFile">';
                    // Dok. Permohonan Paket
                    while($permohonan_paket_file->nextRow())
                    {

    $html .= '      <tr>
                       <td>'.$permohonan_paket_file->getField("JUDUL").'</td>
                       <td style="text-align: center;">';
                          if ($permohonan_paket_file->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/permohonan_paket/'.$permohonan_paket_file->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }
                     // Dok. dokumen pengadaan
                     while($paket_dokumen->nextRow())
                     {
    $html .= '      <tr>
                       <td>'.$paket_dokumen->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/lelang/'.$paket_dokumen->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }
                     if ($paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD")) {
    $html .= '      <tr>
                       <td>
                        Password Dok. Penawaran <br>
                        <a onClick="return myFunction(\''.$pemenangid.'\')">
                          <div class="input-group" style="margin-top:1%">
                            <div class="input-group-prepend">
                              <i class="fa fa-copy"></i> &nbsp;&nbsp;
                            </div>
                            <input class="form-control" type="text" value="'.$paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD").'" id="myPass'.$pemenangid.'" style="border:none; height:10px; cursor:copy;" readonly>
                          </div>
                        </a>
                        ';
                          if ($paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD2")) {
    $html .= '            <br>
                            <a onClick="return myFunction(\'2\')">
                            <div class="input-group" style="margin-top:1%">
                              <div class="input-group-prepend">
                                <i class="fa fa-copy"></i> &nbsp;&nbsp;
                              </div>
                              <input class="form-control" type="text" value="'.$paket_rekanan->getField("KIRIM_PENAWARAN_PASSWORD2").'" id="myPass2" style="border:none; height:10px; cursor:copy;" readonly>
                            </div>
                          </a>';
                          }
    $html .= '          </td>';
    $html .= '          <td style="text-align: center;"> <span class="fa fa-lock"></span></td>';
    $html .= '         </tr>';
                     }
                     // Dok. Penawaran Pemenang
                     while($paket_dokumen_penawaran->nextRow())
                     {
    $html .= '      <tr>
                       <td>'.$paket_dokumen_penawaran->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen_penawaran->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/penawaran/'.$paket_dokumen_penawaran->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }

                     // Dok. BA Evaluasi
                     while($paket_dokumen_ba_evaluasi->nextRow())
                     {
    $html .= '      <tr>
                       <td>Berita Acara '.$paket_dokumen_ba_evaluasi->getField("NAMA").'</td>
                       <td style="text-align: center;">';
                          if ($paket_dokumen_ba_evaluasi->getField("PATH_FILE")) {
    $html .= '            <a href="uploads/penawaran/'.$paket_dokumen_ba_evaluasi->getField("PATH_FILE").'" target="new">
                            <i class="fa fa-download"></i>
                          </a>';
                          }
    $html .= '          </td>
                     </tr>';
                     }

    $html .= '    </tbody>
              </table>
              ';

    return $html;
  }

  function jenisKontrak($value='')
  {
    switch ($value) {
      case '0': return "SPK";
        break;

      case '1': return "Surat Perjanjian";
        break;
      
      case '3': return "Kontrak Payung";
        break;

      default:
        return '';
        break;
    }
  }

}
