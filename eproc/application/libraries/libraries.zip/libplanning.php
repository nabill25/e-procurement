<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class libplanning
{
    private $_CI;

    function __construct()
    {
      $this->_CI =& get_instance();
      $this->_CI->load->library('session');
    }

    function headerUsulan($permohonanpaketanalisaid)
    {
      include_once("functions/string.func.php");
      include_once("functions/date.func.php");
      include_once("functions/default.func.php");

      $this->_CI->load->model("PermohonanPaket");
      $this->_CI->load->model("PermohonanPaketAnalisaFile");
      $this->_CI->load->model("PermohonanPaket");

      $permohonan_paket_analisa_file = new PermohonanPaketAnalisaFile();
      $permohonan_paket = new PermohonanPaket();
      $permohonan_paket_anggaran = new PermohonanPaket();

      $permohonan_paket->selectByParamsUsulan(array("PERMOHONAN_PAKET_ANALISA_ID" => $permohonanpaketanalisaid));
      $permohonan_paket->firstRow();

      $reqPermohonanPaketAnalisaId = $permohonan_paket->getField("PERMOHONAN_PAKET_ANALISA_ID");
      $reqPermohonanPaketId = $permohonan_paket->getField("PERMOHONAN_PAKET_ID");
      $reqTahunAnggaran = $permohonan_paket->getField("TAHUN_ANGGARAN");
      $reqKomoditasId = $permohonan_paket->getField("KOMODITAS_ID");
      $reqKomoditasNama = $permohonan_paket->getField("KOMODITAS_NAMA");
      $reqKategoriId = $permohonan_paket->getField("KATEGORI");
      $reqKategori = $permohonan_paket->getField("KATEGORI_STR");
      $reqJenisBalanja = $permohonan_paket->getField("JENIS_BELANJA_STR");
      $reqJenisBarang = $permohonan_paket->getField("JENIS_BARANG_JASA");
      $reqNamaKebutuhan = $permohonan_paket->getField("NAMA_KEBUTUHAN");
      $reqAnalisaKebutuhan = $permohonan_paket->getField("ANALISA_KEBUTUHAN_ID");
      $reqNamaKebutuhanNama = $permohonan_paket->getField("AK_NAMA");
      $reqAnalisaPasar = $permohonan_paket->getField("ANALISA_PASAR_ID");
      $reqAnalisaPasarNama = $permohonan_paket->getField("AP_NAMA");
      $reqIdentifikasiResiko = $permohonan_paket->getField("IDENTIFIKASI_RESIKO");
      $reqIdentifikasiResikoKeterangan = $permohonan_paket->getField("IDENTIFIKASI_RESIKO_KETERANGAN");
      $reqPembuat = $permohonan_paket->getField("PEMBUAT");
      $reqTanggalBuat = $permohonan_paket->getField("TANGGAL_BUAT");
      $reqPejabatBerwenang = $permohonan_paket->getField("PEJABAT_BERWENANG");
      $reqAlasanTolak = $permohonan_paket->getField("ALASAN_TOLAK");
      $reqAlasanTolakBy = $permohonan_paket->getField("ALASAN_TOLAK_BY");
      $reqAlasanTolakDate = $permohonan_paket->getField("ALASAN_TOLAK_DATE");
      $reqApproval = $permohonan_paket->getField("APPROVAL");
      $reqPublish = $permohonan_paket->getField("PUBLISH");
      $reqPublishDate = $permohonan_paket->getField("PUBLISH_DATE");
      $reqPermohonanPaketAnalisaIdEn = $permohonan_paket->getField("PERMOHONAN_PAKET_ANALISA_ID_ENCRYPT");
      $reqNamaPaket = $permohonan_paket->getField("NAMA");
      $reqAnggaran = $permohonan_paket->getField("ANGGARAN");
      $reqJenisBarangJasa = $permohonan_paket->getField("JENIS_BARANG_JASA");
      $reqJenisBarangJasaStr = $permohonan_paket->getField("JENIS_BARANG_JASA_STR");
      $reqPerkiraanBiayaHarga = $permohonan_paket->getField("PERKIRAAN_BIAYA_HARGA");
      $reqWaktuPenggunaBarangjasa = $permohonan_paket->getField("WAKTU_PENGGUNA_BARANGJASA");
      $reqRencanaPengadaan = $permohonan_paket->getField("RENCANA_PENGADAAN");
      $reqCaraPengadaan = $permohonan_paket->getField("CARA_PENGADAAN");
      $reqCaraPengadaanStr = $permohonan_paket->getField("CARA_PENGADAAN_STR");
      $reqNote = $permohonan_paket->getField("NOTE");
      $reqSumberDanaKeterangan = $permohonan_paket->getField("SUMBER_DANA_KETERANGAN");
      $reqUserJabatan = $permohonan_paket->getField("USER_JABATAN");
      $reqUserTypeIdStr = $permohonan_paket->getField("USER_TYPE_ID_STR");

      // Anggaran
      $permohonan_paket_anggaran->selectByParamsAnggaran(array("A.PERMOHONAN_PAKET_ID" => coalesce($reqPermohonanPaketId, 0)));
      $permohonan_paket_anggaran->firstRow();
      $reqPermohonanPaketAnggaranId = $permohonan_paket_anggaran->getField("PERMOHONAN_PAKET_ANGGARAN_ID");
      $reqPermohonanPaketId = $permohonan_paket_anggaran->getField("PERMOHONAN_PAKET_ID");
      $reqMataAnggaran = $permohonan_paket_anggaran->getField("MATA_ANGGARAN");
      $reqKegiatan = $permohonan_paket_anggaran->getField("KEGIATAN");
      $reqSumberDana = $permohonan_paket_anggaran->getField("SUMBER_DANA");
      $reqBudgetRemaining = $permohonan_paket_anggaran->getField("BUDGET_REMAINING");
      $reqDepartment = $permohonan_paket_anggaran->getField("DEPARTMENT");
      $reqDepartmentCode = $permohonan_paket_anggaran->getField("DEPARTMENT_CODE");
      $reqKodeMataAnggaran = $permohonan_paket_anggaran->getField("KODE_MATA_ANGGARAN");
      $reqKodeKegiatan = $permohonan_paket_anggaran->getField("KODE_KEGIATAN");
      $reqTotalBudget = $permohonan_paket_anggaran->getField("TOTAL_BUDGET");
      $reqTipeTransaksi = $permohonan_paket_anggaran->getField("TIPE_TRANSAKSI");

      if ($reqIdentifikasiResiko == '1') {
        $reqIdentifikasiResiko2 = 'Ada';
      } else {
        $reqIdentifikasiResiko2 = 'Tidak Ada';
      }

      $permohonan_paket_analisa_file->selectByParams(array("PERMOHONAN_PAKET_ANALISA_ID" => $permohonanpaketanalisaid));

      $html  = '';

      $html .= '
                <div class="alert bg-primary alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
                  <span class="alert-icon"><i class="fa fa-th"></i></span>  <strong>Usulan Kebutuhan</strong>
                </div> 
                <div class="p-1">';
                  if($reqAlasanTolak == '' || $reqApproval == '1')
                  {}
                  else
                  {
      $html .= '
                    <div class="card mb-1 border-blue border-darken-1">
                      <div class="card-content">
                        <div class="p-1">
                         <div class="row">
                          <div class="form-group col-md-12 mb-2">
                            <h4 style="color: red">Alasan Dikembalikan</h4>
                            <span style="font-weight: normal">'.$reqAlasanTolak.'</span>
                          </div> 
                        </div>
                        </div>
                      </div>
                    </div>';
                  }
      $html .= '
                  <table class="table table-bordered table-hover">
                    <tbody> 
                      <tr>
                        <td width="25%">Tahun Anggaran:</td> 
                        <td width="75%">'.$reqTahunAnggaran.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Mata Anggaran:</td> 
                        <td width="75%">'.$reqMataAnggaran.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Kegiatan:</td> 
                        <td width="75%">'.$reqKegiatan.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Sumber Dana:</td> 
                        <td width="75%">'.$reqSumberDana.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Anggaran Kegiatan:</td> 
                        <td width="75%">'.numberToIna($reqBudgetRemaining).'</td>
                      </tr>
                      <tr>
                        <td width="25%">Nama Paket:</td> 
                        <td width="75%">'.$reqNamaPaket.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Harga Perkiraan:</td>
                        <td width="75%">'.numberToIna($reqPerkiraanBiayaHarga).'</td>
                      </tr>
                    ';
                      // <tr>
                      //   <td width="25%">Identifikasi Resiko:</td> 
                      //   <td width="75%">'.$reqIdentifikasiResiko2.'</td>
                      // </tr>
      //                 if ($reqIdentifikasiResiko == '1') {
      // $html .= '
      //                 <tr>
      //                   <td width="25%">Identifikasi Resiko Keterangan:</td> 
      //                   <td width="75%">'.$reqIdentifikasiResikoKeterangan.'</td>
      //                 </tr>';
      //               }
      // $html .= '
      //                 <tr>
      //                   <td width="25%">Sumber Dana:</td> 
      //                   <td width="75%">'.$reqNamaKebutuhanNama.'</td>
      //                 </tr>';
      //                 if ($reqNamaKebutuhanNama == 'External') {
      // $html .= '
      //                 <tr>
      //                   <td width="25%">Sumber Dana dari ?</td> 
      //                   <td width="75%">'.$reqSumberDanaKeterangan.'</td>
      //                 </tr>';
      //               }
      $html .= '
                      <tr>
                        <td width="25%">Produk Dalam Negeri:</td> 
                        <td width="75%">'.$reqKategori.'</td>
                      </tr>
                      ';
                      // <tr>
                      //   <td width="25%">Jenis Belanja:</td> 
                      //   <td width="75%">'.$reqJenisBalanja.'</td>
                      // </tr>

      $html .= '
                  ';

      // $html .= '
      //           <div class="alert bg-primary alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
      //             <span class="alert-icon"><i class="fa fa-th"></i></span>  <strong>COA</strong>
      //           </div> 
      //             <table class="table table-bordered table-hover">
      //               <thead>
      //                 <tr class="judul-kolom">
      //                   <th>Nomor COA</th>
      //                   <th>Keterangan</th>
      //                   <th>Anggaran Awal</th>
      //                   <th>Anggaran Terpakai</th>
      //                   <th>Sisa Anggaran</th>
      //                 </tr>
      //               </thead>
      //               <tbody>';

      //               $permohonan_paket_coa = new PermohonanPaket();
      //               $noRand = 2021;
      //               $permohonan_paket_coa->selectByParamsCoa(array("A.PERMOHONAN_PAKET_ID" => coalesce($reqPermohonanPaketId, 0)));
      //               if ($permohonan_paket_coa->countRow() > 0) { 
      //                 while($permohonan_paket_coa->nextRow())
      //                 { 
      // $html .= '
      //                   <tr class="judul-kolom">
      //                     <td>'.$permohonan_paket_coa->getField("NOMOR").'</td>
      //                     <td>'.$permohonan_paket_coa->getField("KETERANGAN").'</td>
      //                     <td>'.numberToIna($permohonan_paket_coa->getField("BUDGET_AWAL")).'</td>
      //                     <td>'.numberToIna($permohonan_paket_coa->getField("BUDGET_TERPAKAI")).'</td>
      //                     <td>'.numberToIna($permohonan_paket_coa->getField("BUDGET_AKHIR")).'</td>
      //                   </tr>';
      //                 } 
      //               } else {
      // $html .=           '<tr><td colspan="5">. : : Tidak ada data : : .</td></tr>';
      //               }
      // $html .=      '</tbody>
      //             </table>
      //           </td>
      //         </tr>';
      $html .= '  
                      <tr>
                        <td width="25%">Cara Pengadaan:</td>
                        <td width="75%">'.$reqCaraPengadaanStr.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Jenis Barang/Jasa:</td> 
                        <td width="75%">'.$reqJenisBarangJasaStr.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Mulai Rencana Pengadaan:</td>
                        <td width="75%">'.getFormattedDate($reqRencanaPengadaan).'</td>
                      </tr> 
                      <tr>
                        <td width="25%">Waktu Penggunaan B/J:</td>
                        <td width="75%">'.getFormattedDate($reqWaktuPenggunaBarangjasa).'</td>
                      </tr>
                      <tr>
                        <td width="25%">Catatan / Keterangan Tambahan:</td> 
                        <td width="75%">'.$reqNote.'</td>
                      </tr>
                      <tr>
                        <td width="25%">Pembuat:</td> 
                        <td width="75%">'.$reqPembuat.' - '.$reqUserTypeIdStr.' <br><span style="font-size:11px"><i>'.$reqUserJabatan.'</i></span></td>
                      </tr>
                      </tbody>
                  </table>';
      $html .= '              
                  <div class="alert alert-info">Dokumen Usulan Upload</div>                                         
                  <table class="table table-striped table-hover" id="tbl_bidang">
                    <tbody>
                      <tr class="judul-kolom">
                        <th>Judul</th>
                        <th style="text-align: center;">Download File</th>
                       </tr>';
                          while($permohonan_paket_analisa_file->nextRow())
                          { 
      $html .= '
                           <tr>
                               <td>'.$permohonan_paket_analisa_file->getField("JUDUL").'</td>
                               <td style="text-align: center;">';
                                if ($permohonan_paket_analisa_file->getField("UKURAN")) {
      $html .= '
                                <a href="uploads/permohonan_paket/'.$permohonan_paket_analisa_file->getField("PATH_FILE").'" target="new"> <i class="fa fa-download"></i></a>';
                                } else { echo "";}
      $html .= '
                              </td>
                          </tr>';
                           }
      $html .= '
                    </tbody>
                  </table> 
                </div>
                ';

       return $html;
    } 

    function headerPermohonan($permohonanpaketid)
    {
      include_once("functions/string.func.php");
      include_once("functions/date.func.php");
      include_once("functions/default.func.php");

      $this->_CI->load->model("PermohonanPaket");
      $this->_CI->load->model("PermohonanPaketFile");
      $this->_CI->load->model("PaketPenawaran"); 

      $permohonan_paket_file = new PermohonanPaketFile();
      $permohonan_paket = new PermohonanPaket();
      $permohonan_paket = new PermohonanPaket();
      $paket_penawaran = new PaketPenawaran();

      $paket_penawaran->selectByParams(array("A.PERMOHONAN_PAKET_ID" => $permohonanpaketid, "ITEM_CHILD" => "0"));
      $paket_penawaran->firstRow();
      $ppi = $paket_penawaran->getField("PAKET_PENAWARAN_ID");
      $boqFile = $paket_penawaran->getField("BOQ_FILE");

      $permohonan_paket->selectByParamsPermohonanLelang(array("PERMOHONAN_PAKET_ID" => $permohonanpaketid));
      $permohonan_paket->firstRow();

      $reqNotaDinas = $permohonan_paket->getField("NOTA_DINAS");
      $reqTanggal   = $permohonan_paket->getField("TANGGAL");
      $reqNamaPaket     = $permohonan_paket->getField("NAMA");
      $reqNilai     = $permohonan_paket->getField("NILAI");
      $reqKeterangan    = $permohonan_paket->getField("KETERANGAN");
      $reqNomorPPA = $permohonan_paket->getField("NO_PPA");
      $reqPengadaanlangsung = $permohonan_paket->getField("PENGADAANLANGSUNG");
      $reqBudgetAwal = $permohonan_paket->getField("BUDGET_AWAL");
      $reqBudgetTerpakai = $permohonan_paket->getField("BUDGET_TERPAKAI");
      $reqBudgetAkhir = $permohonan_paket->getField("BUDGET_AKHIR");
      $reqTahunAnggaran = $permohonan_paket->getField("TAHUN_ANGGARAN");
      $reqPermohonanPaketAnalisaId = $permohonan_paket->getField("PERMOHONAN_PAKET_ANALISA_ID");
      $reqKodeRUP = $permohonan_paket->getField("KODE_RUP");
      $reqKodePR = $permohonan_paket->getField("KODE_PR");
      // $reqPengadaanlangsung = $permohonan_paket->getField("PENGADAANLANGSUNG");


      if ($reqPengadaanlangsung != '2') { // Selain Purchasing Wajib isi BoQ
        if ($boqFile == '') { 
          $pesanHPS = '<span class="badge badge-danger"><i class="fa fa-close"></i> Belum Lengkap</span>';   
        } else {
          $pesanHPS = '<span class="badge badge-info"><i class="fa fa-check"></i> Lengkap</span>
                       <a href="uploads/boq/'.$boqFile.'" class="badge badge-pill badge-primary" target="_blank">download</a>';   
        }
      } else {
        $pesanHPS = '-';
      }

      $permohonan_paket_file->selectByParams(array("PERMOHONAN_PAKET_ID" => $permohonanpaketid));
 

      $html  = ''; 

      
                // <tr>
                //   <td width="25%">No. Nota</td>
                //   <td width="75%">'.$reqNomorPPA.'</td>
                // </tr>
                // <tr>
                //   <td width="25%">Tanggal Nota</td>
                //   <td width="75%">'.getFormattedDate($reqTanggal).'</td>
                // </tr>

      $html .= '
            <table class="table table-bordered table-hover">
              <tbody>
                <tr>
                  <td width="25%">No. RUP</td>
                  <td width="75%">'.$reqKodeRUP.'</td>
                </tr>
                <tr>
                  <td width="25%">No. PR</td>
                  <td width="75%">'.$reqKodePR.'</td>
                </tr>
                <tr>
                  <td width="25%">Tahun Anggaran</td>
                  <td width="75%">'.$reqTahunAnggaran.'</td>
                </tr>
                <tr>
                  <td width="25%">Nama Paket</td>
                  <td width="75%">'.$reqNamaPaket.'</td>
                </tr>
                <tr>
                  <td width="25%">Harga Perkiraan</td>
                  <td width="75%">'.numberToIna($reqNilai).'</td>
                </tr>
                <tr>
                  <td width="25%">Rincian Bill of Quantity <br>(Daftar Kuantitas)</td>
                  <td width="75%">'.$pesanHPS.' </td>
                </tr>
              </tbody>
            </table>';

       return $html;
    } 

    function headerPermohonanDokumen($permohonanpaketid)
    {
      include_once("functions/string.func.php");
      include_once("functions/date.func.php");
      include_once("functions/default.func.php");

      $this->_CI->load->model("PermohonanPaketFile");

      $permohonan_paket_file = new PermohonanPaketFile(); 
      $permohonan_paket_file->selectByParams(array("PERMOHONAN_PAKET_ID" => $permohonanpaketid));
 

      $html  = '';  
      $html .= '  
                <div class="alert alert-info">Dokumen Upload</div>                                         
                <table class="table table-striped table-hover" id="tbl_bidang">
                  <tbody>
                    <tr class="judul-kolom">
                      <th>Nama</th>
                      <th style="text-align: center;">Download</th>
                     </tr>';
                        while($permohonan_paket_file->nextRow())
                        {
      $html .= '  
                         <tr>
                             <td>'.$permohonan_paket_file->getField("JUDUL").'</td>
                             <td style="text-align: center;">';
                              if ($permohonan_paket_file->getField("UKURAN")) {
      $html .= '              <a href="uploads/permohonan_paket/'.$permohonan_paket_file->getField("PATH_FILE").'" target="new"> <i class="fa fa-download"></i></a>';
                              } else { echo "";}
      $html .= '  
                            </td>
                        </tr>';
                         }
      $html .= '  
                  </tbody>
                </table> 
                ';

       return $html;
    } 


}
