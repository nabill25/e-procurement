<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class libnotification
{
  private $_CI;

  function __construct()
  {
    $this->_CI =& get_instance();
    $this->_CI->load->library('kauth');
    $this->_CI->USER_LOGIN_ID   =  $this->_CI->kauth->getInstance()->getIdentity()->USER_LOGIN_ID;
    $this->_CI->USER_LOGIN      =  $this->_CI->kauth->getInstance()->getIdentity()->USER_LOGIN;
    $this->_CI->USER_NAMA       =  $this->_CI->kauth->getInstance()->getIdentity()->USER_NAMA;
    $this->_CI->USER_TYPE_ID    =  $this->_CI->kauth->getInstance()->getIdentity()->USER_TYPE_ID;
    $this->_CI->LEGAL           =  $this->_CI->kauth->getInstance()->getIdentity()->LEGAL;
    $this->_CI->ID              =  $this->_CI->kauth->getInstance()->getIdentity()->REKANAN_ID;
    $this->_CI->HTTP_USER_AGENT = $_SERVER['HTTP_USER_AGENT'];
  }

  function notifAdminVMS()
  {
    /**
      1. Vendor Proses Approval (ok)
      2. Katalog belum diverifikasi (ok)
      3. Komplain Masuk yang belum di respone (ok)
    **/
    $this->_CI->load->model("Queryfree");
    $kirimBerkas = new Queryfree();
    $kirimBerkas->selectByParams("SELECT USER_LOGIN_ID FROM USER_LOGIN WHERE USER_STATUS = '2' ");
    $count = 0;
    $html  = '';
    if ($kirimBerkas->countRow() > 0) {
      $html .= '<a href="'.base_url('/main/index/daftar_rekanan_belum_valid').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$kirimBerkas->countRow().'</span> Vendor Proses Approval </span></a>';
      $count += 1;
    }

    // Katalog belum verifikasi
    $katalog = new Queryfree();
    $katalog->selectByParams("SELECT KATALOGID FROM KATALOG WHERE PUBLISH = '0' ");
    if ($katalog->countRow() > 0) {
      $html .= '<a href="'.base_url('/main/index/katalog_validasi').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$katalog->countRow().'</span> Katalog belum verifikasi </span></a>';
      $count += 1;
    }

    // Komplain Masuk yang belum di respone
    $countComplain = new Queryfree();
    $countComplain->selectByParams("SELECT a2.* from (
                                    SELECT a.*,
                                        (SELECT z.inboxid from inbox z where cast(z.parent AS INTEGER) = a.inboxid ) jawab
                                        from (
                                      SELECT
                                        A.inboxid,
                                        A.inboxcategoryid,
                                        A.parent,
                                        b.ic_name
                                      FROM
                                        inbox
                                        A INNER JOIN inbox_category b ON A.inboxcategoryid = b.inboxcategoryid
                                      where a.inboxcategoryid = 3 and a.parent = '0'
                                      ) a
                                    ) a2 where a2.jawab is null");
    if ($countComplain->countRow() > 0) {
      $countComplain->firstRow();

      if ($countComplain->getField("JAWAB") == '') {
        $html .= '<a href="'.base_url('/main/index/inbox_complain').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countComplain->countRow().'</span> Complain belum di respon </span></a>';
        $count += 1;
      } else {
      }
    }

    if ($count == 0) {
      $html .= '<span class="dropdown-item">. : : Tidak ada pesan : : . </span>';
      $count = '';
    }

    return array('data' => $html, 'count' => $count);
  }

  function notifRekanan()
  {
    /**
      1. Dokumen Expired (ok)
      2. RFI belum di jawab (ok)
      3. Survei belum di jawab (ok)
    **/
    $this->_CI->load->model("Queryfree");
    $countDokExpired = new Queryfree();
    $countDokExpired->selectByParams("SELECT REKANAN_ID FROM view_rekanan_dokumen_expired WHERE REKANAN_ID = ".$this->_CI->ID." ");
    $count = 0;
    $html  = '';
    if ($countDokExpired->countRow() > 0) {
      $html .= '<span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countDokExpired->countRow().'</span> Dokumen Expired </span>';
      $count += 1;
    }

    // RFI
    $countRFI = new Queryfree();
    $countRFI->selectByParams("SELECT a2.* from (
                              SELECT a.*,
                                  (SELECT z.inboxid from inbox z where cast(z.parent AS INTEGER) = a.inboxid AND cast(a.rekanan_id AS INTEGER) = z.created_by ) jawab
                                  from (
                                SELECT UNNEST
                                  (
                                  string_to_array( A.inbox_to, ',' )) rekanan_id,
                                  A.inboxid,
                                  A.inboxcategoryid,
                                  A.parent,
                                  b.ic_name
                                FROM
                                  inbox
                                  A INNER JOIN inbox_category b ON A.inboxcategoryid = b.inboxcategoryid
                                where a.inboxcategoryid = 1 and a.parent = '0'
                                ) a where a.rekanan_id = '".$this->_CI->ID."'
                              ) a2 where a2.jawab is null   ");
    if ($countRFI->countRow() > 0) {
      $countRFI->firstRow();

      if ($countRFI->getField("JAWAB") == '') {
        $html .= '<a href="'.base_url('/main/index/inbox_rfi_penyedia').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countRFI->countRow().'</span> RFI belum di respon </span></a>';
        $count += 1;
      } else {
      }
    }

    // Survei
    $countSurvei = new Queryfree();
    $countSurvei->selectByParams("SELECT a2.* from (
                              SELECT a.*,
                                  (SELECT z.inboxid from inbox z where cast(z.parent AS INTEGER) = a.inboxid AND cast(a.rekanan_id AS INTEGER) = z.created_by ) jawab
                                  from (
                                SELECT UNNEST
                                  (
                                  string_to_array( A.inbox_to, ',' )) rekanan_id,
                                  A.inboxid,
                                  A.inboxcategoryid,
                                  A.parent,
                                  b.ic_name
                                FROM
                                  inbox
                                  A INNER JOIN inbox_category b ON A.inboxcategoryid = b.inboxcategoryid
                                where a.inboxcategoryid = 2 and a.parent = '0'
                                ) a where a.rekanan_id = '".$this->_CI->ID."'
                              ) a2 where a2.jawab is null   ");
    if ($countSurvei->countRow() > 0) {
      $countSurvei->firstRow();

      if ($countSurvei->getField("JAWAB") == '') {
        $html .= '<a href="'.base_url('/main/index/inbox_survei_penyedia').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countSurvei->countRow().'</span> Survei belum di respon </span></a>';
        $count += 1;
      }
    }

    if ($count == 0) {
      $html .= '<span class="dropdown-item">. : : Tidak ada pesan : : . </span>';
      $count = '';
    }

    return array('data' => $html, 'count' => $count);
  }

  function notifPenyeliaVMS()
  {
    /**
      1. Approval Penyedia (ok)
    **/
    $this->_CI->load->model("Queryfree");
    $countVerifikasi = new Queryfree();
    $countVerifikasi->selectByParams("SELECT REKANAN_ID FROM REKANAN WHERE STATUS_VALIDASI = '3'");
    $count = 0;
    $html  = '';
    if ($countVerifikasi->countRow() > 0) {
      $html .= '<span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countVerifikasi->countRow().'</span> Vendor Proses Approval </span>';
      $count += 1;
    }

    if ($count == 0) {
      $html .= '<span class="dropdown-item">. : : Tidak ada pesan : : . </span>';
      $count = '';
    }

    return array('data' => $html, 'count' => $count);
  }

  function notifApprovalVMS()
  {
    /**
      1. Approval Penyedia (ok)
    **/
    $this->_CI->load->model("Queryfree");
    $countVerifikasi = new Queryfree();
    $countVerifikasi->selectByParams("SELECT REKANAN_ID FROM REKANAN WHERE STATUS_VALIDASI = '4'");
    $count = 0;
    $html  = '';
    if ($countVerifikasi->countRow() > 0) {
      $html .= '<a href="'.base_url('/main/index/daftar_rekanan_approval').'"><span class="dropdown-item"><span class="badge badge-info round" style="padding:4px 7px">'.$countVerifikasi->countRow().'</span> Vendor Proses Approval </span></a>';
      $count += 1;
    }

    if ($count == 0) {
      $html .= '<span class="dropdown-item">. : : Tidak ada pesan : : . </span>';
      $count = '';
    }

    return array('data' => $html, 'count' => $count);
  }

}
