<?php
include_once("WEB-INF/functions/default.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class nego_shoutbox extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
				
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->library("paketinfo"); $paketInfo = new paketinfo();
		$this->load->model("NegoShoutbox");
		$this->load->model("PaketPenawaran");
		
		$reqPaketPenawaranId = httpFilterRequest("reqPaketPenawaranId");
		$reqHalaman = httpFilterRequest("reqHalaman");
		$reqKode = httpFilterRequest("reqKode");
		
		/* validasi */
		if($userLogin->userLevel == "3" || $userLogin->userLevel == "7")
		{}
		elseif($userLogin->userLevel == "6")
		{
			$paket_penawaran = new PaketPenawaran();
			$paket_penawaran->selectByParams(array("PAKET_PENAWARAN_ID" => $reqPaketPenawaranId));
			$paket_penawaran->firstRow();
			$paketId = $paket_penawaran->getField("PAKET_ID");
			$paketInfo->getPaket($paketId);
			
			if($paketInfo->rekanan_id_pemenang == $userLogin->userRekanan)
			{}
			else
				exit;
		}
		else
			exit;
		
		
		
		  function replace(&$item, $key) {
			$item = str_replace('|', '-', $item);
		  }
		  
		  if (!function_exists('file_put_contents')) {
				function file_put_contents($fileName, $data) {
					if (is_array($data)) {
						$data = join('', $data);
					}
					$res = @fopen($fileName, 'w+b');
					if ($res) {
						$write = @fwrite($res, $data);
						if($write === false) {
							return false;
						} else {
							return $write;
						}
					}
				}
			}
		  
		  //file_put_contents('debug.txt', print_r($_GET, true));
		  switch($_GET['action']) {
			case 'add':
				array_walk($_POST, 'replace');
				$_POST['nickname'] = htmlentities($_POST['nickname']);
				$_POST['message'] = htmlentities($_POST['message']);
				$time = time();
				$arr[] = $time.'|'.$_POST['nickname'].'|'.$_POST['message'].'|'.$_SERVER['REMOTE_ADDR']."\n";
				
				$nego_shoutbox = new NegoShoutbox();
				$nego_shoutbox->setField("JAM", $time);
				$nego_shoutbox->setField("NAMA", $_POST['nickname']);
				$nego_shoutbox->setField("PESAN", formatTextToDb(strtoupper($_POST['message'])));
				$nego_shoutbox->setField("IP_ADDRESS", $_SERVER['REMOTE_ADDR']);
				$nego_shoutbox->setField("PAKET_PENAWARAN_ID", $reqPaketPenawaranId);
				$nego_shoutbox->setField("REKANAN_ID", $userLogin->userRekanan);
				$nego_shoutbox->setField("HALAMAN", $reqHalaman);
				$nego_shoutbox->setField("KODE", $reqKode);
				$nego_shoutbox->insert();
		  
				$data['response'] = 'Good work';
				$data['nickname'] = $_POST['nickname'];
				$data['message'] = $_POST['message'];
				$data['time'] = $time;
			break;
			
			case 'view':
			  $data = array();
			  if(!$_GET['time'])
				$_GET['time'] = 0;
			  $nego_shoutbox = new NegoShoutbox();
			  $nego_shoutbox->selectByParams(array("PAKET_PENAWARAN_ID" => $reqPaketPenawaranId));
			  while($nego_shoutbox->nextRow())
			  {
				$row = $nego_shoutbox->getField("JAM")."|".$nego_shoutbox->getField("WAKTU")."|".$nego_shoutbox->getField("NAMA")."|".$nego_shoutbox->getField("PESAN")."|".$nego_shoutbox->getField("HALAMAN");  
				list($aTemp['time'], $aTemp['waktu'], $aTemp['nickname'], $aTemp['message'], $aTemp['halaman']) = explode('|', $row); 
				if($aTemp['message'] AND $aTemp['time'] > $_GET['time'])
				  $data[] = $aTemp;
			  }
			break;
		  }
		  
		  require_once('WEB-INF/lib/JSON.php');
		  $json = new Services_JSON();
		  $out = $json->encode($data);
		  print $out;
	}
}
?>