<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataKualifikasiTenagaAhli extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananTenagaAhli");
		$this->load->model("RekananTenagaAhliPengalaman");
		$rekanan_tenaga_ahli = new RekananTenagaAhli();
		$rtap = new RekananTenagaAhliPengalaman();
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		if($reqId == ""){}
		else
			$statement= " AND NOT REKANAN_TENAGA_AHLI_ID IN (".$reqId.")";
			
		$rs = $rekanan_tenaga_ahli->selectByParams(array("REKANAN_ID" => $userLogin->userRekanan), -1, -1, $statement); 
		$met = array();
		$i=0;
		$whereIn = NULL;
		foreach ($rs as $v)
		{
		//    prepare IN query
			$whereIn .= "'".$v['REKANAN_TENAGA_AHLI_ID']."',";
		}
		$whereIn = "(".trim($whereIn,',').")";
		$rsp = $rtap->selectByParamsExtended(array('REKANAN_TENAGA_AHLI_ID'=>array($whereIn,FALSE,'IN')));
		
		foreach ($rsp as $v) {
			$dpengalaman[$v['REKANAN_TENAGA_AHLI_ID']] .= $v['POSISI'].'#'.$v['PEKERJAAN'].'#'.$v['PERIODE'].'#'.$v['NAMA_PERUSAHAAN'].'#'.$v['PENGALAMAN'].'<br/>';
		}
		
		while($rekanan_tenaga_ahli->nextRow()){
			$met[$i]['NAMA'] = $rekanan_tenaga_ahli->getField('NAMA');
			$met[$i]['PENDIDIKAN'] = $rekanan_tenaga_ahli->getField('PENDIDIKAN');
			$met[$i]['PENGALAMAN'] = $dpengalaman[$rekanan_tenaga_ahli->getField('REKANAN_TENAGA_AHLI_ID')];
			$met[$i]['SERTIFIKAT'] = $rekanan_tenaga_ahli->getField('SERTIFIKAT');
			$met[$i]['REKANAN_TENAGA_AHLI_ID'] = $rekanan_tenaga_ahli->getField('REKANAN_TENAGA_AHLI_ID');
			$i++;
		}
		echo json_encode($met);
	}
}
?>