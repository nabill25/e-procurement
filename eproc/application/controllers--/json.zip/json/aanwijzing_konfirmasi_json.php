<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class aanwijzing_konfirmasi_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PhpShoutbox");
		
		$php_shoutbox = new PhpShoutbox();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		
		$php_shoutbox->selectByParamsKonfirmasi(array("A.PAKET_ID" => $reqId));
		$i=0;
		while($php_shoutbox->nextRow())
		{
				
			$met[$i]['KODE'] = $php_shoutbox->getField("KODE");
			$met[$i]['KODE_HALAMAN'] = $php_shoutbox->getField("KODE_HALAMAN");
			$met[$i]['HALAMAN'] = $php_shoutbox->getField("HALAMAN");
			$met[$i]['INFORMASI'] = $php_shoutbox->getField("INFORMASI");
			$i++;
		}
		echo json_encode($met);	
	}
}
?>