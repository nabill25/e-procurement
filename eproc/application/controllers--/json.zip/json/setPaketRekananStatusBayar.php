<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class setPaketRekananStatusBayar extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketRekanan");
		$paket_rekanan = new PaketRekanan();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
			$paket_rekanan->setField("FIELD", "STATUS_BAYAR");
			$paket_rekanan->setField("FIELD_VALUE", "(SELECT DECODE(COALESCE(STATUS_BAYAR, 0), 0, 1, 0) FROM PAKET_REKANAN X WHERE X.PAKET_REKANAN_ID = A.PAKET_REKANAN_ID)");
			$paket_rekanan->setField("PAKET_REKANAN_ID", $reqId);
			$paket_rekanan->update();
		$met = array();
		$i=0;
		
		$met[0]['STATUS'] = 1;
		echo json_encode($met);
	}
}
?>