<?php
/* INCLUDE FILE */

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class anggaran_combo_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Anggaran");
		$anggaran = new Anggaran();
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$anggaran->selectByParams(array());
		
		echo $anggaran->errorMsg;
		
		$arr_json = array();
		$i = 0;
		while($anggaran->nextRow())
		{
			$arr_json[$i]['id'] = $anggaran->getField("NO_PPA");
			$arr_json[$i]['text'] = utf8_encode($anggaran->getField("KET_TAMBAH"));
			$arr_json[$i]['dasar'] = $anggaran->getField("DASAR_PPA");
			
			$i++;
		}
		echo json_encode($arr_json, JSON_UNESCAPED_UNICODE);
	}
}
?>