<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/FileHandler.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class delete extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$reqId = $_GET['id'];
		$reqMode = $_GET['reqMode'];
		
		$file = new FileHandler(); 
		
		if($reqMode == "pembagian_pic_add")
		{
			$this->load->model("PaketProgres");
			$set= new PaketProgres();
			$set->setField('PAKET_PROGRES_ID', $reqId);
			if($set->deleteDetil())
				$alertMsg .= "Data berhasil dihapus";
			else
				$alertMsg .= "Error ".$set->getErrorMsg();
		}
		elseif($reqMode == "sk_daftar_panitia")
		{
			$this->load->model("Panitia");
			$set= new Panitia();
			$set->setField('PANITIA_ID', $reqId);
		
			if($set->delete())
				$alertMsg .= "Data berhasil dihapus";
			else
				$alertMsg .= "Error ".$set->getErrorMsg();
		}
		elseif($reqMode == "sk_panitia")
		{
			$this->load->model("SKPanitia");
			$set= new SKPanitia();
			$arrayId=explode('*', $reqId);
			$set->setField('SK_PANITIA_ID', $arrayId[1]);
		
			if($set->delete())
				$alertMsg .= "Data berhasil dihapus";
			else
				$alertMsg .= "Error ".$set->getErrorMsg();
			
		}
		elseif($reqMode == "paket_work_order")
		{
			$FILE_DIR = "uploads/progres_paket/";
			
			$this->load->model("PaketProgresDetil");
			$lampiran = new PaketProgresDetil();
			$lampiran->selectByParamsBlob(array("PAKET_PROGRES_DETIL_ID" => $reqId), -1, -1);
			$lampiran->firstRow();
			$tempLinkFileTemp= $lampiran->getField("PATH_FILE");
			
			if($tempLinkFileTemp == ""){}
			else
			{
				$varSource=$FILE_DIR.$tempLinkFileTemp;
				if($file->delete($varSource)){}
			}
			
			$set= new PaketProgresDetil();
			$set->setField('PAKET_PROGRES_DETIL_ID', $reqId);
			if($set->delete())
			{	
				$alertMsg .= "Data berhasil dihapus";
			}
			else
				$alertMsg .= "Error ".$set->getErrorMsg();
		}
		elseif($reqMode == "daftar_panitia")
		{
			
			$this->load->model("PaketPanitia");
			$set= new PaketPanitia();
			$set->setField('PAKET_PANITIA_ID', $reqId);
			if($set->deletePanitia())
			{	
				echo "Data berhasil dihapus";
			}
			else
				echo "Data gagal dihapus";
		}		
	}
}
?>