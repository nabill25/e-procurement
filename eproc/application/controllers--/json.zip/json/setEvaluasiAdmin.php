<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class setEvaluasiAdmin extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananEvaluasiAdminTawar");
		$rekanan_evaluasi_admin = new RekananEvaluasiAdminTawar();
		
		$reqId = httpFilterGet("reqId");
		$arrId = explode(";", $reqId);
		
		$reqPaketRekananId = $arrId[0];
		$reqEvaluasiAdminId = $arrId[1];
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		//, , 
		$check = $rekanan_evaluasi_admin->getCountByParams(array("PAKET_REKANAN_ID" => $reqPaketRekananId, "PAKET_EVAL_ADMIN_TAWAR_ID" => $reqEvaluasiAdminId));
		
		if($check == 0)
		{	
			$rekanan_evaluasi_admin->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
			$rekanan_evaluasi_admin->setField("PAKET_EVAL_ADMIN_TAWAR_ID", $reqEvaluasiAdminId);
			$rekanan_evaluasi_admin->insertStatus();
		}
		else
		{
			$rekanan_evaluasi_admin->setField("STATUS", "(SELECT DECODE(COALESCE(STATUS, 0), 0, 1, 0) FROM PAKET_EVAL_ADMIN_TAWAR X WHERE X.PAKET_EVAL_ADMIN_TAWAR_ID = A.PAKET_EVAL_ADMIN_TAWAR_ID)");
			$rekanan_evaluasi_admin->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
			$rekanan_evaluasi_admin->setField("PAKET_EVAL_ADMIN_TAWAR_ID", $reqEvaluasiAdminId);
			$rekanan_evaluasi_admin->update();
		}
		$met = array();
		$i=0;
		
		$met[0]['STATUS'] = 1;
		echo json_encode($met);
	}
}
?>