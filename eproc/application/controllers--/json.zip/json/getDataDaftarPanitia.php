<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataDaftarPanitia extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Panitia");
		$panitia = new Panitia();
		
		$reqId = httpFilterGet("reqId");
		$reqPaketId = httpFilterGet("reqPaketId");
		$reqUnitKerjaId = httpFilterGet("reqUnitKerjaId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		if($reqUnitKerjaId == "1")
			$arrStatement = array();
		else
			$arrStatement = array("UNIT_KERJA_ID" => $reqUnitKerjaId);	
				
		//$panitia->selectByParams(array());
		if($reqId == '')
		$panitia->selectByParamsCari($arrStatement, -1, -1, $reqPaketId); 
		else{
			$reqId = "'".CommaToQuery($reqId)."'";
		$panitia->selectByParamsCari($arrStatement, -1, -1, $reqPaketId, " AND NOT NIP IN (".$reqId.")");
		}
		
		$met = array();
		$i=0;
		
		while($panitia->nextRow()){
			$met[$i]['NAMA'] = $panitia->getField('NAMA');
			$met[$i]['NIP'] = $panitia->getField('NIP');
			$met[$i]['JABATAN'] = $panitia->getField('JABATAN');
			$met[$i]['FUNGSI'] = $panitia->getField('FUNGSI');
			$met[$i]['KETUA'] = $panitia->getField('KETUA');
			$i++;
		}
		echo json_encode($met);
	}
}
?>