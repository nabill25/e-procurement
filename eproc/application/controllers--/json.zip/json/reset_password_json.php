<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class reset_password_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("UsersBase");
		$user_login = new UsersBase();
		
		$reqId = httpFilterGet("reqId");
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		$str = " UPDATE  USER_LOGIN SET USER_PASSWORD    = ".md5($this->getField(""))."	WHERE  USER_LOGIN_ID = ".$reqId." "; 
		
		echo $str;
	}
}
?>
