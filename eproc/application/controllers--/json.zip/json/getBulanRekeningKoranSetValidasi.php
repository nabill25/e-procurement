<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getBulanRekeningKoranSetValidasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Metode");
		$metode = new Metode();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$arrBulanTahun = explode("-", $reqId);
		$reqBulan = $arrBulanTahun[0];
		$year = $year1 = $year2 = $arrBulanTahun[1];
		
		$month = $reqBulan;
		if($month <= 0) 
		{
			$year = date("Y") - 1;
			$month = 12 + $month;
			$monthname = getNameMonth($month);
		}
		else
			$monthname = getNameMonth($month);
		$month1 = $reqBulan - 1;
		if($month1 <= 0) 
		{
			$year1 = date("Y") - 1;
			$month1 = 12 + $month1;
			$monthname1 = getNameMonth($month1);
		}	
		else
			$monthname1 = getNameMonth($month1);
		$month2 = $reqBulan - 2;
		if($month2 <= 0) 
		{
			$year2 = date("Y") - 1;
			$month2 = 12 + $month2;
			$monthname2 = getNameMonth($month2);
		}									
		else
			$monthname2 = getNameMonth($month2);
				
		$met = array("REKENING_KORAN" => $monthname2." ".$year2.", ".$monthname1." ".$year1.", ".$monthname." ".$year,"REKENING_KORAN_SET_VALID" => $month2.$year2.", ".$month1.$year1.", ".$month.$year);
		
		echo json_encode($met);
	}
}
?>