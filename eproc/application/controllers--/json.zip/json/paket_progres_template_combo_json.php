<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class paket_progres_template_combo_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketProgresTemplate");
		$set= new PaketProgresTemplate();
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$reqStatus= httpFilterGet("reqStatus");
		
		$arr_json = array();
		$i = 0;
		
		// setkondisi
		//$statement= " AND A.KELOMPOK_PEGAWAI = 'D' ";
		//$statement= " AND A.PEGAWAI_ID = ".$userLogin->setId;
		$set->selectByParams(array(),-1,-1,$statement);
		while($set->nextRow()){
			$arr_json[$i]['id'] = $set->getField("PAKET_PROGRES_TEMPLATE_ID");
			$arr_json[$i]['text'] = $set->getField("NAMA");
			$arr_json[$i]['tipe'] = $set->getField("USER_TYPE_ID");
			$arr_json[$i]['keterangan'] = $set->getField("KETERANGAN");
			$i++;
		}
		
		echo json_encode($arr_json);
	}
}
?>