<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class aanwijzing_validasi_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketAanwijzingValidasi");
		
		$paket_aanwijzing_validasi = new PaketAanwijzingValidasi();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		$reqJenis = httpFilterGet("reqJenis");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_aanwijzing_validasi->setField("PAKET_ID", $reqId);
		$paket_aanwijzing_validasi->setField("USER_LOGIN_ID", $userLogin->UID);
		$paket_aanwijzing_validasi->setField("KODE", $reqKode);
		$paket_aanwijzing_validasi->setField("JENIS", $reqJenis);
		if($paket_aanwijzing_validasi->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}

	function pembukaan() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketPembukaanValidasi");
		
		$paket_pembukaan_validasi = new PaketPembukaanValidasi();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		$reqJenis = httpFilterGet("reqJenis");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_pembukaan_validasi->setField("PAKET_ID", $reqId);
		$paket_pembukaan_validasi->setField("USER_LOGIN_ID", $userLogin->UID);
		$paket_pembukaan_validasi->setField("KODE", $reqKode);
		$paket_pembukaan_validasi->setField("JENIS", $reqJenis);
		if($paket_pembukaan_validasi->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}

	function pembukaankedua() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketPembukaanKeduaValidasi");
		
		$paket_pembukaan_validasi = new PaketPembukaanKeduaValidasi();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		$reqJenis = httpFilterGet("reqJenis");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_pembukaan_validasi->setField("PAKET_ID", $reqId);
		$paket_pembukaan_validasi->setField("USER_LOGIN_ID", $userLogin->UID);
		$paket_pembukaan_validasi->setField("KODE", $reqKode);
		$paket_pembukaan_validasi->setField("JENIS", $reqJenis);
		if($paket_pembukaan_validasi->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}
	
	function evaluasi() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketEvaluasiValidasi");
		
		$paket_evaluasi_validasi = new PaketEvaluasiValidasi();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		$reqJenis = httpFilterGet("reqJenis");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_evaluasi_validasi->setField("PAKET_ID", $reqId);
		$paket_evaluasi_validasi->setField("USER_LOGIN_ID", $userLogin->UID);
		$paket_evaluasi_validasi->setField("KODE", $reqKode);
		$paket_evaluasi_validasi->setField("JENIS", $reqJenis);
		
		if($paket_evaluasi_validasi->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}
	
	function negosiasi() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketNegosiasiValidasi");
		
		$paket_negosiasi_validasi = new PaketNegosiasiValidasi();
		
		$reqId = httpFilterGet("reqId");
		$reqKode = httpFilterGet("reqKode");
		$reqJenis = httpFilterGet("reqJenis");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_negosiasi_validasi->setField("PAKET_ID", $reqId);
		$paket_negosiasi_validasi->setField("USER_LOGIN_ID", $userLogin->UID);
		$paket_negosiasi_validasi->setField("KODE", $reqKode);
		$paket_negosiasi_validasi->setField("JENIS", $reqJenis);
		if($paket_negosiasi_validasi->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}
			
}
?>