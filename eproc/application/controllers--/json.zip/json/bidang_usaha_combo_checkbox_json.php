<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class bidang_usaha_combo_checkbox_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("BidangUsaha");
		
		$bidang_usaha = new BidangUsaha();
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$reqMode= httpFilterGet("reqMode");
		$reqId= httpFilterGet("reqId");
		
		$i = 0;
		
		function checkVariabel($text, $search)
		{
			$arrText = explode(",",$text);
			for($i=0;$i<count($arrText);$i++)
			{
				if(trim($arrText[$i]) == trim($search))
					return true;	
			}
			return false;
		}
		
		$bidang_usaha->selectByParams(array("BIDANG_USAHA_PARENT_ID" => 0), -1,-1, $statement);
		
		while($bidang_usaha->nextRow())
		{
			$arr_json[$i]['id'] = $bidang_usaha->getField("BIDANG_USAHA_ID");
			$arr_json[$i]['text'] = $bidang_usaha->getField("NAMA_TANPA_KOMA");
			$parent = new BidangUsaha();
			$parent->selectByParams(array("BIDANG_USAHA_PARENT_ID" => $bidang_usaha->getField("BIDANG_USAHA_ID")));	
			$j=0;
			while($parent->nextRow())
			{
				$arr_parent[$j]['id'] = $parent->getField("BIDANG_USAHA_ID");
				$arr_parent[$j]['text'] = $parent->getField("NAMA_TANPA_KOMA");	
				$arr_parent[$j]['checked'] = checkVariabel($reqId, $parent->getField("BIDANG_USAHA_ID"));		
		
				$child = new BidangUsaha();
				$child->selectByParams(array("BIDANG_USAHA_PARENT_ID" => $parent->getField("BIDANG_USAHA_ID")));	
				$k=0;
				while($child->nextRow())
				{
					$arr_child[$k]['id'] = $child->getField("BIDANG_USAHA_ID");
					$arr_child[$k]['text'] = $child->getField("NAMA_TANPA_KOMA");		
					$arr_child[$k]['checked'] = checkVariabel($reqId, $child->getField("BIDANG_USAHA_ID"));			
					
		
					$sub = new BidangUsaha();
					$sub->selectByParams(array("BIDANG_USAHA_PARENT_ID" => $child->getField("BIDANG_USAHA_ID")));	
					$l=0;
					while($sub->nextRow())
					{
						$arr_sub[$l]['id'] = $sub->getField("BIDANG_USAHA_ID");
						$arr_sub[$l]['text'] = $sub->getField("NAMA_TANPA_KOMA");	
						$arr_sub[$l]['checked'] = checkVariabel($reqId, $sub->getField("BIDANG_USAHA_ID"));													
						
						$detil = new BidangUsaha();
						$detil->selectByParams(array("BIDANG_USAHA_PARENT_ID" => $sub->getField("BIDANG_USAHA_ID")));	
						$m=0;
						while($detil->nextRow())
						{
							$arr_detil[$m]['id'] = $detil->getField("BIDANG_USAHA_ID");
							$arr_detil[$m]['text'] = $detil->getField("NAMA_TANPA_KOMA");
							$arr_detil[$m]['checked'] = checkVariabel($reqId, $detil->getField("BIDANG_USAHA_ID"));												
							
							$m++;
						}
						
						$arr_sub[$l]['children'] = $arr_detil;
						
						unset($detil);
						unset($arrdetil);
						
						$l++;
					}
					$arr_child[$k]['children'] = $arr_sub;
					
					unset($sub);
					unset($arr_sub);
					$k++;
				}
				$arr_parent[$j]['children'] = $arr_child;
				
				unset($child);
				unset($arr_child);
				$j++;
			}
			$arr_json[$i]['children'] = $arr_parent;
		
			unset($parent);
			unset($arr_parent);
			$i++;
		}
		echo json_encode($arr_json);
	}
}
?>