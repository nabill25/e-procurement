<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataKualifikasiPeralatan extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananPeralatan");
		$rekanan_peralatan = new RekananPeralatan();
		
		$reqId = httpFilterGet("reqId");
		
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		if($reqId == ""){}
		else
			$statement= " AND NOT REKANAN_PERALATAN_ID IN (".$reqId.")";
			
		$rekanan_peralatan->selectByParams(array("REKANAN_ID" => $userLogin->userRekanan), -1, -1, $statement); 
		$met = array();
		$i=0;
		
		while($rekanan_peralatan->nextRow()){
			$met[$i]['JENIS'] = $rekanan_peralatan->getField('JENIS');
			$met[$i]['JUMLAH'] = $rekanan_peralatan->getField('JUMLAH');
			$met[$i]['KAPASITAS'] = $rekanan_peralatan->getField('KAPASITAS');
			$met[$i]['TAHUN'] = $rekanan_peralatan->getField('TAHUN');
			$met[$i]['KONDISI'] = $rekanan_peralatan->getField('KONDISI');
			$met[$i]['BUKTI_KEPEMILIKAN'] = $rekanan_peralatan->getField('BUKTI_KEPEMILIKAN');
			$met[$i]['REKANAN_PERALATAN_ID'] = $rekanan_peralatan->getField('REKANAN_PERALATAN_ID');
			$i++;
		}
		echo json_encode($met);
	}
}
?>