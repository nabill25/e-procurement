<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getBulanRekeningKoranPanel extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Metode");
		$metode = new Metode();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$arrBulanTahun = explode("-", $reqId);
		$reqBulan = $arrBulanTahun[0];
		$year = $year1 = $year2 = $year3 = $year4 = $year5 = $arrBulanTahun[1];
		
		$month = $reqBulan;
		if($month <= 0) 
		{
			$year = date("Y") - 1;
			$month = 12 + $month;
			$monthname = getNameMonth($month);
		}
		else
			$monthname = getNameMonth($month);
		$month1 = $reqBulan - 1;
		if($month1 <= 0) 
		{
			$year1 = date("Y") - 1;
			$month1 = 12 + $month1;
			$monthname1 = getNameMonth($month1);
		}	
		else
			$monthname1 = getNameMonth($month1);
		$month2 = $reqBulan - 2;
		if($month2 <= 0) 
		{
			$year2 = date("Y") - 1;
			$month2 = 12 + $month2;
			$monthname2 = getNameMonth($month2);
		}									
		else
			$monthname2 = getNameMonth($month2);
		
		
		$month3 = $reqBulan - 3;
		if($month3 <= 0) 
		{
			$year3 = date("Y") - 1;
			$month3 = 12 + $month3;
			$monthname3 = getNameMonth($month3);
		}									
		else
			$monthname3 = getNameMonth($month3);
		
		$month4 = $reqBulan - 4;
		if($month4 <= 0) 
		{
			$year4 = date("Y") - 1;
			$month4 = 12 + $month4;
			$monthname4 = getNameMonth($month4);
		}									
		else
			$monthname4 = getNameMonth($month4);
		
		$month5 = $reqBulan - 5;
		if($month5 <= 0) 
		{
			$year5 = date("Y") - 1;
			$month5 = 12 + $month5;
			$monthname5 = getNameMonth($month5);
		}									
		else
			$monthname5 = getNameMonth($month5);
				
		$met = array("REKENING_KORAN" => $monthname5." ".$year5.", ".$monthname4." ".$year4.", ".$monthname3." ".$year3.", ".$monthname2." ".$year2.", ".$monthname1." ".$year1.", ".$monthname." ".$year,
					 "REKENING_KORAN_SET_VALID" => $month5.$year5.", ".$month4.$year4.", ".$month3.$year3.", ".$month2.$year2.", ".$month1.$year1.", ".$month.$year);
		
		echo json_encode($met);
	}
}
?>