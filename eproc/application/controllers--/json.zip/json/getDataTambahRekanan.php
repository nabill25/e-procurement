<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataTambahRekanan extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketBidangUsaha");
		$bidang_usaha = new PaketBidangUsaha();
		
		$reqId = httpFilterGet("reqId");
		$reqPaketId = httpFilterGet("reqPaketId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$bidang_usaha->selectByParamsRekanan(array(), -1, -1, $reqPaketId, " AND NOT A.REKANAN_ID IN (".$reqId.")"); 

		$met = array();
		$i=0;
		
		while($bidang_usaha->nextRow()){
			$met[$i]['NAMA'] = $bidang_usaha->getField('NAMA');
			$alamat = str_replace("\r\n",'',$bidang_usaha->getField("ALAMAT"));
			$met[$i]['ALAMAT'] = $alamat;
			$met[$i]['EMAIL'] = $bidang_usaha->getField('EMAIL');
			$met[$i]['REKANAN_ID'] = $bidang_usaha->getField('REKANAN_ID');
			$i++;
		}
		echo json_encode($met);
	}
}
?>