<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class daftar_rekanan_teknis_tenaga_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananTenagaAhli");
		$rekanan_tenaga_ahli = new RekananTenagaAhli();
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		$reqKeterangan = httpFilterRequest("reqKeterangan");
		$reqId = httpFilterRequest("reqId");
		$reqSearch = httpFilterGet("reqSearch");
		 
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		 
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
		
		if($reqSearch == "")
		{	
			$allRecord = $rekanan_tenaga_ahli->getCountByParams(array('REKANAN_ID'=>$reqId), $statement);
			$rekanan_tenaga_ahli->selectByParams(array('REKANAN_ID'=>$reqId), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement);
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = 1;
			$rekanan_tenaga_ahli->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		}
		
		$column = array('REKANAN_SERTIFIKAT_ID', 'NO', 'NAMA','PENDIDIKAN','PENGALAMAN','SERTIFIKAT');
			 
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$number = 1;
			while($rekanan_tenaga_ahli->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					if($column[$i]=='NO')		$row[] = $number;
					else						$row[] = $rekanan_tenaga_ahli->getField(trim($column[$i]));
				}
				$number++;
				$output['aaData'][] = $row;
			}
			echo json_encode( $output );
	}
}
?>
