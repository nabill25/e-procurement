<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class bidang_usaha_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("BidangUsaha");
		
		$bidang_usaha = new BidangUsaha();
		
		$reqRow = httpFilterGet("reqRow");
		$reqKey = httpFilterGet("reqKey");
		
		function getGroupBySatuanKerja($id_induk, $x)
		{
			$child = new BidangUsaha();	
			$child->selectByParams(array("BIDANG_USAHA_PARENT_ID" => $id_induk, $arrCompanyID, $arrCompanyName), -1, -1);
			//echo $child->query;
			while($child->nextRow())
			{
			  $param_key = $child->getField('BIDANG_USAHA_ID');
			  $param_key_id = $param_key;
				  
			  $arrCompanyID[] =  $child->getField("BIDANG_USAHA_ID");
			  $arrCompanyName[] =  "[".$child->getField('KODE')."]".$child->getField("NAMA");
			  $x++;
			  $_SESSION['set_id'] = $x;
			getGroupBySatuanKerja($param_key, $x, $arrCompanyID[], $arrCompanyName[]);
			//echo $_SESSION['set_id'].'---';
				
			}	
			unset($child);
		}
		
		$i = $_SESSION['set_id'] = 0;
		
		$bidang_usaha->selectByParams(array(), -1, -1, $reqKey);
		while($bidang_usaha->nextRow())
		{
			$arrMenu[] = array("BIDANG_USAHA_ID" => $bidang_usaha->getField("BIDANG_USAHA_ID"), 
							   "BIDANG_USAHA_PARENT_ID" => $bidang_usaha->getField("BIDANG_USAHA_PARENT_ID"), 
							   "KODE" => $bidang_usaha->getField("KODE"), 
							   "NAMA" => $bidang_usaha->getField("NAMA")
							   );
		}
		
		$arrIndex = in_array_column(0, "SATKER_ID_PARENT", $arrMenu);
		if(is_array($arrIndex))
		{
		  for($i=0;$i<count($arrIndex);$i++)
		  {
			  $id_menu = $arrMenu[$arrIndex[$i]]["SATKER_ID"];
			  $uraian = trim(str_replace("'", "", $arrMenu[$arrIndex[$i]]["NAMA"]));
			  
			  $arrCompanyID[] =  $arrMenu[$arrIndex[$i]]["BIDANG_USAHA_ID"];
			  $arrCompanyName[] =  "[".$arrMenu[$arrIndex[$i]]["KODE"]."]".$arrMenu[$arrIndex[$i]]["NAMA"];
			  //drawSatkerByParentArray($id_menu, $link, $arrMenu);
		  }
		}
			$arrFinal = array("BIDANG_USAHA_ID" => $arrCompanyID, 
							  "BIDANG_USAHA_NAMA" => $arrCompanyName);
			echo json_encode($arrFinal);
	}
}
?>