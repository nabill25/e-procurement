<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class timeline_paket_komen extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketProgresKomen");
		
		$reqId= httpFilterPost("reqId");
		$reqMode = httpFilterPost("reqMode");
		$reqKeterangan= httpFilterPost("reqKeterangan");
							
		if($reqMode == "insert")
		{
			$set= new PaketProgresKomen();
			$set->setField("USER_LOGIN_ID", $userLogin->UID);
			$set->setField("KETERANGAN", $reqKeterangan);
			$set->setField("PAKET_PROGRES_ID", $reqId);
			$set->setField("LAST_CREATE_USER", $userLogin->idUser);
			$set->setField("LAST_CREATE_DATE", "CURRENT_DATE");
			if($set->insert())
			{
				echo "Data berhasil disimpan.";
			}
		}
	}
}
?>