<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class pakta_integritas_validasi_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketPaktaIntegritas");
		$paket_pakta_integritas = new PaketPaktaIntegritas();
		
		$reqId = httpFilterGet("reqId"); //var_dump($reqId);die();
		$reqKode = httpFilterGet("reqKode"); //var_dump($reqKode);die();
		$reqJenis = httpFilterGet("reqJenis"); //var_dump($reqJenis);die();
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket_pakta_integritas->setField("PAKET_ID", $reqId);
		$paket_pakta_integritas->setField("USER_LOGIN_ID", $userLogin->UID); //var_dump($userLogin->UID);die();
		$paket_pakta_integritas->setField("KODE", $reqKode);
		$paket_pakta_integritas->setField("JENIS", $reqJenis);
		if($paket_pakta_integritas->insert())
			$pesan = "Validasi berhasil.";	
		else
			$pesan = "Validasi gagal.";	
		
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}
}
?>