<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class permohonan_lelang_add extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->model("PermohonanPaket");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$permohonan_paket = new PermohonanPaket();
		
		$reqId = httpFilterPost("reqId");
		$reqMode = httpFilterPost("reqMode");
		$reqNama = httpFilterPost("reqNama");
		$reqKeterangan = httpFilterPost("reqKeterangan");
		$reqNotaDinas = httpFilterPost("reqNotaDinas");
		$reqNama = httpFilterPost("reqNama");
		$reqNomorPPA = httpFilterPost("reqNomorPPA");
		$reqTanggal = httpFilterPost("reqTanggal");
		
							
		if($reqMode == "insert")
		{
			$permohonan_paket->setField('PERMOHONAN_PAKET_ID', $reqId);
			$permohonan_paket->setField('USER_LOGIN_ID', $userLogin->UID);
			$permohonan_paket->setField('UNIT_KERJA_ID', $userLogin->unitKerjaId);
			$permohonan_paket->setField('NOTA_DINAS', $reqNotaDinas);
			$permohonan_paket->setField('NAMA', $reqNama);
			$permohonan_paket->setField('KETERANGAN', $reqKeterangan);
			$permohonan_paket->setField('NO_PPA', $reqNomorPPA);
			$permohonan_paket->setField('TANGGAL', dateToDBCheck($reqTanggal));
			$permohonan_paket->setField("LAST_CREATE_USER", $userLogin->nama);
			
				
			if($permohonan_paket->insert())
			{
				$reqId = $permohonan_paket->id;
				echo "Data berhasil disimpan.-".$reqId;
			}
		}
		else
		{
			$permohonan_paket->setField('PERMOHONAN_PAKET_ID', $reqId);
			$permohonan_paket->setField('USER_LOGIN_ID', $userLogin->UID);
			$permohonan_paket->setField('UNIT_KERJA_ID', $userLogin->unitKerjaId);
			$permohonan_paket->setField('NOTA_DINAS', $reqNotaDinas);
			$permohonan_paket->setField('NAMA', $reqNama);
			$permohonan_paket->setField('KETERANGAN', $reqKeterangan);
			$permohonan_paket->setField('NO_PPA', $reqNomorPPA);
			$permohonan_paket->setField('TANGGAL', dateToDBCheck($reqTanggal));
			$permohonan_paket->setField("LAST_CREATE_USER", $userLogin->nama);		
			if($permohonan_paket->update())
				echo "Data berhasil disimpan.-".$reqId;
		}
	}
}
?>