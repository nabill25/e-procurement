<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class vendor_payment_add extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->model("IntegrasiAIM");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$integrasi_aim = new IntegrasiAIM();

			
		$reqId = httpFilterPost("reqId");
		$reqTermin = httpFilterPost("reqTermin");
		$reqJumlahDokumen = httpFilterPost("reqJumlahDokumen");
		$reqMode = httpFilterPost("reqMode");

		/* CHECK APAKAH PERMOHONAN BAYAR SUDAH DI CREATE */
		$integrasi_aim->selectByParamsSubProgramBayar(array("A.SUB_PROGRAM_SP2_ID" => $reqId, "A.TERMIN" => $reqTermin));
		$integrasi_aim->firstRow();
		$reqSubProgramBayarId = $integrasi_aim->getField("SUB_PROGRAM_BAYAR_ID");
		
		/* JIKA TIDAK ADA DI INSERT */
		if($reqSubProgramBayarId == "")
		{
			$integrasi_aim->setField("SUB_PROGRAM_SP2_ID", $reqId);
			$integrasi_aim->setField("TERMIN", $reqTermin);
			$integrasi_aim->setField("CREATED_DATE", "SYSDATE");
			$integrasi_aim->setField("CREATED_BY", $userLogin->UID);
			$integrasi_aim->insertSubProgramBayar();
			$reqSubProgramBayarId = $integrasi_aim->id;
		}

		/* START UPLOAD FILE */
		$FILE_DIR = "uploads/penagihan/";
		for($i=1;$i<=$reqJumlahDokumen;$i++)
		{
			$integrasi_aim_upload = new IntegrasiAIM();
			
			$reqLampiran = $_FILES["reqLampiran".$i];
			$reqTerminSyaratId = $_POST["reqTerminSyaratId".$i];
			$reqNamaDokumen = $_POST["reqNamaDokumen".$i];
			if($reqLampiran['name'] == "")
			{}
			else			
			{
				$renameFile = md5(date("dmYHis").$reqLampiran['name']).".".getExtension($reqLampiran['name']);
				if (move_uploaded_file($reqLampiran['tmp_name'], $FILE_DIR.$renameFile))
				{
					$insertLinkFile = $renameFile;
				}	
			
				$integrasi_aim_upload->setField("SUB_PROGRAM_BAYAR_ID", $reqSubProgramBayarId);
				$integrasi_aim_upload->setField("SUB_PROGRAM_SP2_TERMIN_SYARAT", $reqTerminSyaratId);
				$integrasi_aim_upload->setField("NAMA", $reqNamaDokumen);
				$integrasi_aim_upload->setField("TANGGAL", "SYSDATE");
				$integrasi_aim_upload->setField("UPLOAD", $insertLinkFile);
				$integrasi_aim_upload->setField("CREATED_DATE", "SYSDATE");
				$integrasi_aim_upload->setField("CREATED_BY", $userLogin->UID);
				$integrasi_aim_upload->insertSubProgramBayarDokumen();
								
						
			}	

			unset($integrasi_aim_upload);
			unset($reqLampiran);
			unset($reqTerminSyaratId);
			unset($reqNamaDokumen);
			
		}

				
		
	}
	
	function delete()
	{
		$reqId = $this->input->get("reqId");	
		$this->load->model("IntegrasiAIM");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$integrasi_aim = new IntegrasiAIM();
		
		$integrasi_aim->setField("SUB_PROGRAM_BAYAR_DOKUMEN_ID", $reqId);
		$integrasi_aim->setField("CREATED_BY", $userLogin->UID);
		$integrasi_aim->deleteSubProgramBayarDokumen();
		echo "Data berhasil dihapus.";
	}
	
	function posting()
	{
		$reqId = httpFilterPost("reqId");
		$reqTermin = httpFilterPost("reqTermin");
		$reqRevisi = httpFilterPost("reqRevisi");
		
		$this->load->model("IntegrasiAIM");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$integrasi_aim = new IntegrasiAIM();

		/* CHECK APAKAH PERMOHONAN BAYAR SUDAH DI CREATE */
		$integrasi_aim->selectByParamsSubProgramBayar(array("A.SUB_PROGRAM_SP2_ID" => $reqId, "A.TERMIN" => $reqTermin));
		$integrasi_aim->firstRow();
		$reqSubProgramBayarId = $integrasi_aim->getField("SUB_PROGRAM_BAYAR_ID");
		if($reqSubProgramBayarId == "")
			echo "Dokumen belum diupload.";
		else
		{
			/* APABILA REVISI PERPAJAKAN (RP) MAKA LANGSUNG DIKIRIM KE PAJAK */
			if($reqRevisi == md5('RP'))
				$reqApproval = "PP";
			elseif($reqRevisi == md5('RK'))
				$reqApproval = "PK";				
			else
				$reqApproval = "PR";
						
			$integrasi_aim->setField("APPROVAL", $reqApproval);
			$integrasi_aim->setField("SUB_PROGRAM_BAYAR_ID", $reqSubProgramBayarId);
			$integrasi_aim->setField("CREATED_BY", $userLogin->UID);
			$integrasi_aim->postingSubProgramBayar();
			echo "Dokumen berhasil diposting.";
		}
	}
	
	
}
?>