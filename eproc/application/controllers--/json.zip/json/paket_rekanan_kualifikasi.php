<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/FileHandler.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class paket_rekanan_kualifikasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}

	function add() 
	{

		$this->load->model("PaketRekananKualifikasi");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$reqPaketRekananId = httpFilterPost("reqPaketRekananId");
		$reqCatatan = httpFilterPost("reqCatatan");
		$reqKode = httpFilterPost("reqKode");
	
		$paket_rekanan_kualifikasi = new PaketRekananKualifikasi();
		$paket_rekanan_kualifikasi->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
		$paket_rekanan_kualifikasi->setField("KODE", $reqKode);
		$paket_rekanan_kualifikasi->setField("CATATAN", $reqCatatan);
		$paket_rekanan_kualifikasi->setField("CREATED_BY", $userLogin->UID);
		$paket_rekanan_kualifikasi->delete();
		$paket_rekanan_kualifikasi->insert();
		
		echo "Data berhasil disimpan.";
	}

}
?>