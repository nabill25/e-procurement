<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getPPH extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananPajak");
		$rekanan_pph	= new RekananPajak(); // tipe 2
		
		$reqId = httpFilterGet("reqId");
		$reqTahun = httpFilterGet("reqTahun");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$rekanan_pph->selectByParams(array("TIPE"=>2, "REKANAN_ID"=>$reqId, "TAHUN" => $reqTahun), -1, -1);
		$met = array();
		$i=0;
		
		$arrBulan = array("", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
		 
		while($rekanan_pph->nextRow()){
			$met[$i]['BULAN'] = $arrBulan[$rekanan_pph->getField('BULAN')];
			$met[$i]['NOMOR'] = $rekanan_pph->getField('NOMOR');
			$met[$i]['TANGGAL'] = getFormattedDate($rekanan_pph->getField('TANGGAL'));
			$i++;
		}
		echo json_encode($met);
	}
}
?>