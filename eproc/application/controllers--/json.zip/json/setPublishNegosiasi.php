<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class setPublishNegosiasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->library("paketinfo"); $paketInfo = new paketinfo();
		$this->load->model("Paket");
		$this->load->model("PaketNegosiasiValidasi");
		$paket = new Paket();
		
		$reqId = httpFilterGet("reqId");

		$paketInfo->getPaket($reqId);
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}

		
		if($paketInfo->jenis_pengadaan == "LELANG")
		{
			/* VALIDASI PEMBUKAAN PENAWARAN */
			$paket_negosiasi_validasi = new PaketNegosiasiValidasi();
			$jumlahValidasi = $paket_negosiasi_validasi->getCountByParams(array("A.PAKET_ID" => $reqId));
			
			if($jumlahValidasi == 0)
			{
				$arrFinal = array("STATUS" => "Minimal terdapat 1(satu) validasi dari panitia.");			
				echo json_encode($arrFinal);		
				return;
			}
		}
				
		$paket->setField("PAKET_ID", $reqId);
		$paket->publishBANegosiasi();
		$arrFinal = array("STATUS" => "1");			
		echo json_encode($arrFinal);		
	}
}
?>