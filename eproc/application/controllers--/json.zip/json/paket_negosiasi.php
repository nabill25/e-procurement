<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/FileHandler.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class paket_negosiasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}

	function add() 
	{

		$this->load->model("PaketNegoisasi");
		
		$reqId = httpFilterPost("reqId");
		$reqPaketPenawaranId = $_POST["reqPaketPenawaranId"];
		$reqUnitPriceNegosiasi = $_POST["reqUnitPriceNegosiasi"];
		$reqJumlahNegosiasi = $_POST["reqJumlahNegosiasi"];
		$reqQuantity = $_POST["reqQuantity"];
	
		$paket_negosiasi = new PaketNegoisasi();
		$paket_negosiasi->setField("PAKET_ID", $reqId);
		$paket_negosiasi->delete();
	
		for($i=0;$i<count($reqPaketPenawaranId);$i++)
		{
			$paket_negosiasi = new PaketNegoisasi();
			$paket_negosiasi->setField("PAKET_ID", $reqId);
			$paket_negosiasi->setField("JUMLAH", CommaToDot(dotToNo($reqJumlahNegosiasi[$i])));
			$paket_negosiasi->setField("PAKET_PENAWARAN_ID", $reqPaketPenawaranId[$i]);
			$paket_negosiasi->setField("UNIT_PRICE", CommaToDot(dotToNo($reqUnitPriceNegosiasi[$i])));
			$paket_negosiasi->setField("QUANTITY", $reqQuantity[$i]);
			$paket_negosiasi->insert();
			unset($paket_negosiasi);
		}
		
		echo "Data berhasil disimpan.";
	}

	function add_lelang() 
	{

		$this->load->model("RekananPaketPenawaran");
		$this->load->model("PaketNegoisasi");
		
		$reqId = httpFilterPost("reqId");
		$reqPaketRekananId = httpFilterPost("reqPaketRekananId");
		$reqPaketPenawaranId = $_POST["reqPaketPenawaranId"];
		$reqUnitPriceNegosiasi = $_POST["reqUnitPriceNegosiasi"];
		$reqJumlahNegosiasi = $_POST["reqJumlahNegosiasi"];
		$reqQuantity = $_POST["reqQuantity"];
		$reqUnitPricePenawaran = $_POST["reqUnitPricePenawaran"]; 
		$reqJumlahPenawaran = $_POST["reqJumlahPenawaran"]; 
		$reqTotalPenawaran = CommaToDot(dotToNo($_POST["reqTotalPenawaran"]));
		
		/* VALIDASI ENTRIAN PENAWARAN */
		$hasilPenawaran = 0;

		$rekanan_paket_penawaran = new RekananPaketPenawaran();
		$rekanan_paket_penawaran->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
		$rekanan_paket_penawaran->delete();
				
		for($i=0;$i<count($reqPaketPenawaranId);$i++)
		{
			$rekanan_paket_penawaran = new RekananPaketPenawaran();
			$rekanan_paket_penawaran->setField("PAKET_PENAWARAN_ID", $reqPaketPenawaranId[$i]);
			$rekanan_paket_penawaran->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
			$rekanan_paket_penawaran->setField("DELIVERY_DATE", "NULL");
			$rekanan_paket_penawaran->setField("QUANTITY", CommaToDot(dotToNo($reqQuantity[$i])));
			$rekanan_paket_penawaran->setField("UNIT_PRICE", CommaToDot(dotToNo($reqUnitPricePenawaran[$i])));
			$rekanan_paket_penawaran->setField("JUMLAH", CommaToDot(dotToNo($reqJumlahPenawaran[$i])));
			$rekanan_paket_penawaran->insert();
			unset($rekanan_paket_penawaran);
			
			$hasilPenawaran += CommaToDot(dotToNo($reqJumlahPenawaran[$i]));	
		}
		
		if($hasilPenawaran == $reqTotalPenawaran)
		{}
		else
		{
			echo "Rincian penawaran tidak sesuai, total rincian = ".numberToIna($hasilPenawaran).", sedangkan total penawaran = ".numberToIna($reqTotalPenawaran).".";	
			return;
		}
		
		$paket_negosiasi = new PaketNegoisasi();
		$paket_negosiasi->setField("PAKET_ID", $reqId);
		$paket_negosiasi->delete();
	
		for($i=0;$i<count($reqPaketPenawaranId);$i++)
		{
			$paket_negosiasi = new PaketNegoisasi();
			$paket_negosiasi->setField("PAKET_ID", $reqId);
			$paket_negosiasi->setField("JUMLAH", CommaToDot(dotToNo($reqJumlahNegosiasi[$i])));
			$paket_negosiasi->setField("PAKET_PENAWARAN_ID", $reqPaketPenawaranId[$i]);
			$paket_negosiasi->setField("UNIT_PRICE", CommaToDot(dotToNo($reqUnitPriceNegosiasi[$i])));
			$paket_negosiasi->setField("QUANTITY", $reqQuantity[$i]);
			$paket_negosiasi->insert();
			unset($paket_negosiasi);
		}
		
		echo "Data berhasil disimpan.";
	}
	
	function undangan() 
	{
		$this->load->library("KMail");	
		$this->load->model("PaketRekanan");
		$this->load->model("Metode");
		
		$paket_rekanan = new PaketRekanan();
		$metode = new Metode();
		
		$reqId = httpFilterPost("reqId");
		$reqPaketRekananId = httpFilterPost("reqPaketRekananId"); 
		$reqPaketTahapId = httpFilterPost("reqPaketTahapId"); 
		$reqTanggal = httpFilterPost("reqTanggalNegosiasi"); 
		$reqJamMulai = httpFilterPost("reqJamMulai"); 
		$reqMenitMulai = httpFilterPost("reqMenitMulai"); 
		$reqUrut = httpFilterPost("reqUrut"); 

		if(trim($reqTanggal) == "")
		{
			echo "Tanggal harus diisi.";	
			return;
		}
		
		if(trim($reqJamMulai) == "")
		{
			echo "Jam harus diisi.";	
			return;
		}

		if(trim($reqMenitMulai) == "")
		{
			echo "Menit harus diisi.";	
			return;
		}
		
		if($reqTanggal == "")
			$tanggal_awal = "NULL";
		elseif($reqJamMulai[$i] == "")		
			$tanggal_awal = "TO_DATE('".$reqTanggal."', 'DD-MM-YYYY')";
		else
		{
			$tanggal_awal = "TO_DATE('".$reqTanggal." ".$reqJamMulai.":".$reqMenitMulai."', 'DD-MM-YYYY HH24:MI')";
			$jam_awal = $reqJamMulai.":".$reqMenitMulai;
		}
		
		if($reqPaketTahapId == "")
		{
			$metode->setField("PAKET_ID", $reqId);
			$metode->setField("NAMA", "Negosiasi");
			$metode->setField("HADIR", "0");
			$metode->setField("TAMPILKAN", "1");
			$metode->setField("TANGGAL_AWAL", $tanggal_awal);
			$metode->setField("TANGGAL_AKHIR",  "NULL");
			$metode->setField("JAM_AWAL", $jam_awal);
			$metode->setField("JAM_AKHIR", "");
			$metode->setField("URUT", $reqUrut);
			$metode->insert();	
		}
		else
		{
			$metode->setField("TANGGAL_AWAL", $tanggal_awal);
			$metode->setField("JAM_AWAL", $jam_awal);
			$metode->setField("PAKET_TAHAP_ID", $reqPaketTahapId);
			$metode->update();					
		}
	


		$paket_rekanan->selectByParamsEmail(array('PAKET_REKANAN_ID' => $reqPaketRekananId));
		$paket_rekanan->firstRow();


		$mail = new KMail();
		$mail->AddAddress($paket_rekanan->getField("EMAIL") , $paket_rekanan->getField("NAMA"));
		$mail->Subject  =  "Undangan Negosiasi";
		$body = file_get_contents(base_url()."main/loadUrl/email/negosiasi_paket/".$reqId."/".$reqPaketRekananId);
		$mail->MsgHTML($body);
		if($mail->Send())
		{
			$paket_rekanan->setField("FIELD", "DI_EMAIL_NEGOSIASI");
			$paket_rekanan->setField("FIELD_VALUE", "(COALESCE(DI_EMAIL_NEGOSIASI, 0) + 1)");
			$paket_rekanan->setField("PAKET_REKANAN_ID", $reqPaketRekananId);
			$paket_rekanan->update();			
			echo "Kirim email berhasil.";
		}
		else
			echo "Kirim email gagal.";
		  
		
		
	}	

	function setujui() 
	{

		$this->load->model("PaketNegoisasi");
		
		$paket_negosiasi = new PaketNegoisasi();
		
		$reqId = httpFilterGet("reqId");
	
		$paket_negosiasi->setField("PAKET_PENAWARAN_ID", $reqId);
		$paket_negosiasi->updateSetujui();
		
	}		
	
	function negosiasi() 
	{

		$this->load->model("PaketNegoisasi");
		
		$paket_negosiasi = new PaketNegoisasi();
		
		$reqId = httpFilterGet("reqId");
		$reqNilai = httpFilterGet("reqNilai");
	
		$paket_negosiasi->setField("UNIT_PRICE", CommaToDot(dotToNo($reqNilai)));
		$paket_negosiasi->setField("PAKET_PENAWARAN_ID", $reqId);
		if($paket_negosiasi->updateUnitPrice())
			echo "Data berhasil disimpan.";
		else
			echo "Data gagal disimpan.";
		
	}			
	
	
	function ambil_negosiasi()
	{
		$this->load->model("PaketNegoisasi");
		
		$reqId = httpFilterGet("reqId");

		$paket_negosiasi = new PaketNegoisasi();
		$paket_negosiasi->selectByParams(array("PAKET_PENAWARAN_ID" => $reqId));
		$paket_negosiasi->firstRow();
		
		$data["UNIT_PRICE"] = numberToIna($paket_negosiasi->getField("UNIT_PRICE"));
		$data["TOTAL"] = numberToIna($paket_negosiasi->getField("TOTAL"));
		$data["SETUJUI"] = $paket_negosiasi->getField("SETUJUI");
		
		echo json_encode($data);
			
	}
	
}
?>