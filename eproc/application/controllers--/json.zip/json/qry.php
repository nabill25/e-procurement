<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class qry extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->model("PaketProgresKomen");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$set= new PaketProgresKomen();
		
		
		$str = "";
		
		if($set->execSQL($str))
		{
			echo "Data berhasil dieksekusi.";
		}
	}
}
?>