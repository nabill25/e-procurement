<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class setPublishAanwijzing extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("KMail");	
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->library("paketinfo"); $paketInfo = new paketinfo();
		$this->load->model("Aanwijzing");
		$this->load->model("PaketRekanan");
		$aanwijzing = new Aanwijzing();
		$paket_rekanan = new PaketRekanan();
		
		
		$reqId = httpFilterGet("reqId");
		
		$paketInfo->getPaket($reqId);
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$aanwijzing->setField("FIELD", "PUBLISH");
		$aanwijzing->setField("FIELD_VALUE", "1");
		$aanwijzing->setField("PAKET_ID", $reqId);
		$aanwijzing->updateByField();
		
		/* EMAIL KE PESERTA */
		$paket_rekanan->selectByParamsEmail(array("A.PAKET_ID" => $reqId, "AANWIJZING" => "1"));

		if($paketInfo->bahasa == "EN")
			$link_email = "aanwijzing_publish_en";
		else
			$link_email = "aanwijzing_publish";
							
		while($paket_rekanan->nextRow())
		{
			$mail = new KMail();
			$mail->AddAddress($paket_rekanan->getField("EMAIL") , $paket_rekanan->getField("NAMA"));
			$mail->Subject  =  "Pemberitahuan Publish Berita Acara Aanwijzing";
			$body = file_get_contents(base_url()."app/loadUrl/email/".$link_email."/".$reqId."/".$paket_rekanan->getField("REKANAN_ID"));
			$mail->MsgHTML($body);
			$mail->Send();

			unset($mail);
			unset($body);
		}
		
		$met = array();
		$i=0;
		
		$met[0]['STATUS'] = 1;
		echo "Publish aanwijzing dan kirim email berhasil.";
	}
}
?>