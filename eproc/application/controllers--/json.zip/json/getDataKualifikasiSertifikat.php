<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataKualifikasiSertifikat extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananSertifikat");
		$rekanan_sertifikat = new RekananSertifikat();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		if($reqId == ""){}
		else
			$statement= " AND NOT REKANAN_SERTIFIKAT_ID IN (".$reqId.")";
			
		$rekanan_sertifikat->selectByParams(array("REKANAN_ID" => $userLogin->userRekanan), -1, -1, $statement); 
		//$rekanan_sertifikat->selectByParams(array("REKANAN_ID" => $userLogin->userRekanan), -1, -1); 
		$met = array();
		$i=0;
		
		while($rekanan_sertifikat->nextRow()){
			$met[$i]['NAMA'] = $rekanan_sertifikat->getField('NAMA');
			$met[$i]['NOMOR'] = $rekanan_sertifikat->getField('NOMOR');
			$met[$i]['TANGGAL'] = getFormattedDate($rekanan_sertifikat->getField('TANGGAL'));
			$met[$i]['REKANAN_SERTIFIKAT_ID'] = $rekanan_sertifikat->getField('REKANAN_SERTIFIKAT_ID');
			$i++;
		}
		echo json_encode($met);
	}
}
?>