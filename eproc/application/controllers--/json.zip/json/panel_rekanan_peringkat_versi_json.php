<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class panel_rekanan_peringkat_versi_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PanelBidangUsaha");
		$panel_bidang_usaha = new PanelBidangUsaha();
		
		$reqId = httpFilterGet("reqId");
		$reqBidangUsaha = httpFilterGet("reqBidangUsaha");
		
		$panel_bidang_usaha->selectByParams(array("PANEL_ID" => $reqId, "MD5(BIDANG_USAHA_ID)" => $reqBidangUsaha));
		$panel_bidang_usaha->firstRow();
		
		$arrFinal = array("STATUS" => $panel_bidang_usaha->getField("PERUBAHAN_DATA"));
		echo json_encode($arrFinal);
	}
}
?>