<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class setPublishKualifikasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Paket");
		$paket = new Paket();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		
		$paket->setField("PAKET_ID", $reqId);
		$paket->publishBAKualifikasi();
		$met[0]['STATUS'] = 1;
		echo json_encode($met);
	}
}
?>