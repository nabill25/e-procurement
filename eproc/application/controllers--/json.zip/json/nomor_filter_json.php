<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class nomor_filter_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("EvaluasiAdmin");
		/* LOGIN CHECK 
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}*/
		
		$reqEvaluasiNumber = httpFilterGet("reqEvaluasiNumber");
		$reqOld= httpFilterGet("reqOld");
		$reqMode = httpFilterGet("reqMode");
		
		$reqBaru = httpFilterGet("reqBaru");
		
		if($reqMode == 'nomor'){
			$evaluasi_admin = new EvaluasiAdmin();
			if($reqBaru == 'baru')
				$evaluasi_admin->selectByParams(array('EVALUASI_NUMBER'=>$reqEvaluasiNumber));
			elseif($reqBaru == 'lama')
				$evaluasi_admin->selectByParams(array('EVALUASI_NUMBER'=>$reqEvaluasiNumber, "NOT EVALUASI_NUMBER " => $reqOld));
			//echo $evaluasi_admin->query;
			$evaluasi_admin->firstRow();
			if($reqEvaluasiNumber == $evaluasi_admin->getField("EVALUASI_NUMBER"))
				echo json_encode(false);
			else
				echo json_encode(true);
		}
	}
}
?>