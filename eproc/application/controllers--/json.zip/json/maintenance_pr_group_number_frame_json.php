<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class maintenance_pr_group_number_frame_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("SAP/SapPr");
		$sap_pr = new SapPr();
		
		/* LOGIN CHECK
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}*/
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		
		$aColumns = array("PR_GROUP_NUMBER", "PAKET_ID", "PR_GROUP_NUMBER", "PR_GROUP_NAME", "INTEGRATED_DATE");
		$aColumnsAlias = array("PR_GROUP_NUMBER", "PAKET_ID", "PR_GROUP_NUMBER", "PR_GROUP_NAME", "INTEGRATED_DATE");
		
		/*
		 * Ordering
		 */
		if ( isset( $_GET['iSortCol_0'] ) )
		{
			$sOrder = " ORDER BY ";
			 
			//Go over all sorting cols
			for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
			{
				//If need to sort by current col
				if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
				{
					//Add to the order by clause
					$sOrder .= $aColumnsAlias[ intval( $_GET['iSortCol_'.$i] ) ];
					 
					//Determine if it is sorted asc or desc
					if (strcasecmp(( $_GET['sSortDir_'.$i] ), "asc") == 0)
					{
						$sOrder .=" asc, ";
					}else
					{
						$sOrder .=" desc, ";
					}
				}
			}
			
			 
			//Remove the last space / comma
			$sOrder = substr_replace( $sOrder, "", -2 );
			
			//Check if there is an order by clause
			if ( trim($sOrder) == "ORDER BY PR_GROUP_NUMBER asc" )
			{
				/*
				* If there is no order by clause - ORDER BY INDEX COLUMN!!! DON'T DELETE IT!
				* If there is no order by clause there might be bugs in table display.
				* No order by clause means that the db is not responsible for the data ordering,
				* which means that the same row can be displayed in two pages - while
				* another row will not be displayed at all.
				*/
				$sOrder = " ORDER BY INTEGRATED_DATE DESC";
				 
			}
		}
		 
		 
		/*
		 * Filtering
		 * NOTE this does not match the built-in DataTables filtering which does it
		 * word by word on any field. It's possible to do here, but concerned about efficiency
		 * on very large tables.
		 */
		$sWhere = "";
		$nWhereGenearalCount = 0;
		if (isset($_GET['sSearch']))
		{
			$sWhereGenearal = $_GET['sSearch'];
		}
		else
		{
			$sWhereGenearal = '';
		}
		
		if ( $_GET['sSearch'] != "" )
		{
			//Set a default where clause in order for the where clause not to fail
			//in cases where there are no searchable cols at all.
			$sWhere = " AND (";
			for ( $i=0 ; $i<count($aColumnsAlias)+1 ; $i++ )
			{
				//If current col has a search param
				if ( $_GET['bSearchable_'.$i] == "true" )
				{
					//Add the search to the where clause
					$sWhere .= $aColumnsAlias[$i]." LIKE '%".$_GET['sSearch']."%' OR ";
					$nWhereGenearalCount += 1;
				}
			}
			$sWhere = substr_replace( $sWhere, "", -3 );
			$sWhere .= ')';
		}
		 
		/* Individual column filtering */
		$sWhereSpecificArray = array();
		$sWhereSpecificArrayCount = 0;
		for ( $i=0 ; $i<count($aColumnsAlias) ; $i++ )
		{
			if ( $_GET['bSearchable_'.$i] == "true" && $_GET['sSearch_'.$i] != '' )
			{
				//If there was no where clause
				if ( $sWhere == "" )
				{
					$sWhere = "AND ";
				}
				else
				{
					$sWhere .= " AND ";
				}
				 
				//Add the clause of the specific col to the where clause
				$sWhere .= $aColumnsAlias[$i]." LIKE '%' || :whereSpecificParam".$sWhereSpecificArrayCount." || '%' ";
				 
				//Inc sWhereSpecificArrayCount. It is needed for the bind var.
				//We could just do count($sWhereSpecificArray) - but that would be less efficient.
				$sWhereSpecificArrayCount++;
				 
				//Add current search param to the array for later use (binding).
				$sWhereSpecificArray[] =  $_GET['sSearch_'.$i];
				 
			}
		}
		 
		//If there is still no where clause - set a general - always true where clause
		if ( $sWhere == "" )
		{
			$sWhere = " AND 1=1";
		}
		//Bind variables.
		if ( isset( $_GET['iDisplayStart'] ))
		{
			$dsplyStart = $_GET['iDisplayStart'];
		}
		else{
			$dsplyStart = 0;
		}
		 
		if ( isset( $_GET['iDisplayLength'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$dsplyRange = $_GET['iDisplayLength'];
			if ($dsplyRange > (2147483645 - intval($dsplyStart)))
			{
				$dsplyRange = 2147483645;
			}
			else
			{
				$dsplyRange = intval($dsplyRange);
			}
		}
		else
		{
			$dsplyRange = 2147483645;
		}
		
		
		$allRecord = $sap_pr->getCountByParams(array());
		if($_GET['sSearch'] == "")
			$allRecordFilter = $allRecord;
		else	
			$allRecordFilter = $sap_pr->getCountByParams(array(), " AND (UPPER(PR_GROUP_NUMBER) LIKE '%".strtoupper($_GET['sSearch'])."%')");
		
		$sap_pr->selectByParams(array(), $dsplyRange, $dsplyStart, " AND (UPPER(PR_GROUP_NUMBER) LIKE '%".strtoupper($_GET['sSearch'])."%')", $sOrder);     		
		//echo $sap_pr->query;
		/* Output */
		$output = array(
			"sEcho" => intval($_GET['sEcho']),
			"iTotalRecords" => $allRecord,
			"iTotalDisplayRecords" => $allRecordFilter,
			"aaData" => array()
		);
		
		while($sap_pr->nextRow())
		{
			$row = array();
			for ( $i=0 ; $i<count($aColumns) ; $i++ )
			{
				if($aColumns[$i] == "INTEGRATED_DATE")
					$row[] = getFormattedDate($sap_pr->getField($aColumns[$i]));
				else if($aColumns[$i] == "KETERANNGAN")
					$row[] = truncate($sap_pr->getField($aColumns[$i]), 5)."...";
				else if($aColumns[$i] == "JUMLAH")
					$row[] = currencyToPage($sap_pr->getField($aColumns[$i]));
				else
					$row[] = $sap_pr->getField($aColumns[$i]).$sOrder;
			}
			
			$output['aaData'][] = $row;
		}
		
		echo json_encode( $output );
	}

	function hapusService()
	{
		$reqId = $this->input->get("reqId");
		
		$this->load->model("SAP/SapPrService");
		$sap_pr_service = new SapPrService();
		
		/* CHECK ID APA ADA KEMBAR */
		$jumlahData = $sap_pr_service->getCountByParams(array("SAP_PR_SERVICE_ID" => $reqId));
		
		if($jumlahData > 1)
		{
			echo "Terdapat lebih dari 1 data dengan ID sama. Hubungi Adminstrator...";	
			return;
		}
		
		$sap_pr_service->setField("SAP_PR_SERVICE_ID", $reqId);
		if($sap_pr_service->delete())
		{
			echo "Data berhasil dihapus.";	
		}
		else
			echo "Data gagal dihapus.";	
			
	}	

	function hapusServiceLimit()
	{
		$reqId = $this->input->get("reqId");
		
		$this->load->model("SAP/SapPrServiceLimit");
		$sap_pr_service_limit = new SapPrServiceLimit();

		/* CHECK ID APA ADA KEMBAR */
		$jumlahData = $sap_pr_service_limit->getCountByParams(array("SAP_PR_SERVICE_LIMIT_ID" => $reqId));
		
		if($jumlahData > 1)
		{
			echo "Terdapat lebih dari 1 data dengan ID sama. Hubungi Adminstrator...";	
			return;
		}
		
				
		$sap_pr_service_limit->setField("SAP_PR_SERVICE_LIMIT_ID", $reqId);
		if($sap_pr_service_limit->delete())
		{
			echo "Data berhasil dihapus.";	
		}
		else
			echo "Data gagal dihapus.";	
			
	}	
	
	function batalkan()
	{
		
		$reqId = $this->input->get("reqId");
		
		require_once('WEB-INF/lib/nusoap-0.9.5/lib/nusoap.php');
		$sc = new nusoap_client('http://integrator.pelindo.co.id/EPROCInboundCancelLelangDev.asmx?wsdl',TRUE);
		$psc = array('I_PRGROUPNO'=> $reqId
					);
					 
		$rsc = $sc->call('inboundCancelLelang',$psc);
		
		$jumlahPesan = count($rsc['inboundCancelLelangResult']['T_RETURN']["BAPIRET2"]);
		$pesanErrorSAP = "";
		$pesanSukses = "";
		$no = 1;
		$noSukses = 1;
		$tipeError = $rsc['inboundCancelLelangResult']['T_RETURN']["BAPIRET2"]["TYPE"];
		$pesanError = $rsc['inboundCancelLelangResult']['T_RETURN']["BAPIRET2"]["MESSAGE"];
		
		if($tipeError == "E")
		{
			$pesanErrorSAP = $pesanError;
		}
		else
		{
			$pesanSukses = $pesanError;
			$noSukses++;
		}
		
		if($pesanSukses == "")
		{
			if($pesanErrorSAP == "")
				echo "PR gagal dihapus.";
			else
				echo $pesanErrorSAP;
		}
		else
		{
			$this->load->model("SAP/SapPr");	
			$sap_pr = new SapPr();
		
			$sap_pr->setField('PR_GROUP_NUMBER', $reqId);
			$sap_pr->setField('DELETED_BY', $userLogin->UID);
			if($sap_pr->delete())		
			{
				echo $pesanSukses;		
			}
		}
		
	}
}
?>
