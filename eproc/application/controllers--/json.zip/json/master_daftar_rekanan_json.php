<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class master_daftar_rekanan_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth();
		$this->load->model("UsersBase");
		$user_login = new UsersBase();
		
		/* LOGIN CHECK 
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}*/
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		$reqKeterangan = httpFilterRequest("reqKeterangan");
		$reqId = httpFilterRequest("reqId");
		$reqMode = httpFilterRequest("reqMode");
		$reqSearch = httpFilterGet("reqSearch");
		
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		
		/*
		 * Ordering
		 */
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
		
		//$statement = " AND REKANAN_ID IS NOT NULL ";
		
		if($reqMode == 'Ubah'){
			$user_login_ubah = new UsersBase();
			
			$user_login_ubah->selectByParams(array("USER_LOGIN_ID"=>$reqId),-1,-1);
			$user_login_ubah->firstRow();
			$tmpStatus = $user_login_ubah->getField("USER_STATUS");
			
			
			if($tmpStatus == 1)	$tmpStatus = 0;
			else				$tmpStatus = 1;
			
			$user = new UsersBase();
			$user->setField("USER_LOGIN_ID",$reqId);
			$user->setField("USER_STATUS",$tmpStatus);
			
			if($user->update_status()){}
		}
		
		if($reqSearch == "")
		{	
			$allRecord = $user_login->getCountByParams(array(), $statement);
			$user_login->selectByParams(array("A.USER_TYPE_ID" => 6), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement);
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = 1;
			//$user_login->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		
		}
		
		$column = array('USER_LOGIN_ID', 'NO', 'USER_NAMA','USER_LOGIN','USER_STATUS');
			/*
			 * Output 
			 */
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$number = 1;
			while($user_login->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					
					if($column[$i]=='NO')		$row[] = $number;
					elseif($column[$i]=='USER_STATUS'){
						if($user_login->getField(trim($column[$i]))){
							//$img = "<img src="../main/images/centang.png">";
							$row[] = '<img src="WEB-INF/images/centang.png">';
							//$row[] = "ok";
						}else{
							$row[] = '<img src="WEB-INF/images/uncentang.png">';
							//$row[] = "no";
						}
					}
					else						$row[] = $user_login->getField(trim($column[$i]));

				}
				$number++;
				$output['aaData'][] = $row;
			}
			
			echo json_encode( $output );
	}
}
?>
