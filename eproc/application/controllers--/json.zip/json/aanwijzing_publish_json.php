<?php
/* INCLUDE FILE */

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class aanwijzing_publish_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Aanwijzing");
		$aanwijzing = new Aanwijzing();
		
		// $reqId = httpFilterGet("reqId");
		$reqId = $_GET["reqId"];
		
		$aanwijzing->selectByParams(array("PAKET_ID" => $reqId));
		$aanwijzing->firstRow();
		$i=0;
		$met[$i]['PUBLISH'] = $aanwijzing->getField("PUBLISH");
		echo json_encode($met);	
	}
}
?>