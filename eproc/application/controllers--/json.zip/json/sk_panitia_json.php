<?php
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

class sk_panitia_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("SKPanitia");
		$sk_panitia = new SKPanitia();
		
		/* LOGIN CHECK 
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		*/
		$reqKeterangan = httpFilterRequest("reqKeterangan");
		$reqId = httpFilterRequest("reqId");
		$reqSearch = httpFilterGet("reqSearch");
		$reqAgamaId = httpFilterGet("reqAgamaId");
		
		
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		
		/*
		 * Ordering
		 */
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
		
		/*if($reqId == "")
			$statement = "";
		else
			$statement = "AND A.SATKER_ID LIKE '".$reqId."%'";	
		
		if($reqAgamaId == "")
			$statement = $statement;
		else
			$statement = $statement." AND A.AGAMA_ID = ".$reqAgamaId;	*/
			
		if($reqSearch == "")
		{	
			$allRecord = $sk_panitia->getCountByParams(array(), $statement);
			$sk_panitia->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement);
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = $sk_panitia->getCountByParamsMonitoring(array(), $statement.$reqSearch);
			$sk_panitia->selectByParamsSKPanitiaAgama(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		
		}
		
		//echo "<script language='Javascript'>";
		//echo include_once "../jslib/formHandler.php";
		//echo "<script>";
		
		$column = array('UNIT_KERJA', 'NO', 'NO_SK', 'PEJABAT_PENETAP', 'PEJABAT_PENETAP_NIP', 'TANGGAL', 'TANGGAL_MULAI', 'TANGGAL_AKHIR', 'STATUS');
		
			/*
			 * Output 
			 */
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$tmp='';	$number = 1;
			while($sk_panitia->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					if($column[$i]=='NO')		$row[] = $number;
					elseif($column[$i]=='TANGGAL' || $column[$i]=='TANGGAL_MULAI' || $column[$i]=='TANGGAL_AKHIR')	$row[] = getFormattedDateJson($sk_panitia->getField(trim($column[$i])));
					elseif($column[$i]=='STATUS'){
						if( $sk_panitia->getField(trim($column[$i])) == 1)	$st = 'Berlaku';					
						else												$st = 'Tidak Berlaku';				
						$row[] = $st;
					}
					elseif($column[$i]=='UNIT_KERJA')	$row[] = $sk_panitia->getField(trim($column[$i]))."*".$sk_panitia->getField("SK_PANITIA_ID");
					else						$row[] = $sk_panitia->getField(trim($column[$i]));
				}
				$number++;
				$output['aaData'][] = $row;
			}
				
			echo json_encode( $output );
	}
}
?>
