<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getMetodeEvaluasi extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Metode");
		$metode = new Metode();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$metode->selectByParamsMetodeEvaluasi(array('PAKET_JENIS_ID'=>$reqId));
		$met = array();
		$i=0;
		
		while($metode->nextRow()){
			$met[$i]['PAKET_METODE_EVALUASI_ID'] = $metode->getField('PAKET_METODE_EVALUASI_ID');
			$met[$i]['PAKET_METODE_EVALUASI'] = $metode->getField('PAKET_METODE_EVALUASI');
			$i++;
		}
		echo json_encode($met);
	}
}
?>