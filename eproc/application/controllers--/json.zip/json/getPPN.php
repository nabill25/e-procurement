<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getPPN extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananPajak");
		$rekanan_ppn	= new RekananPajak(); // tipe 3
		
		$reqId = httpFilterGet("reqId");
		$reqTahun = httpFilterGet("reqTahun");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$rekanan_ppn->selectByParams(array("TIPE"=>3, "REKANAN_ID"=>$reqId, "TAHUN" => $reqTahun), -1, -1);
		$met = array();
		$i=0;
		
		$arrBulan = array("", "Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
		 
		while($rekanan_ppn->nextRow()){
			$met[$i]['BULAN'] = $arrBulan[$rekanan_ppn->getField('BULAN')];
			$met[$i]['NOMOR'] = $rekanan_ppn->getField('NOMOR');
			$met[$i]['TANGGAL'] = getFormattedDate($rekanan_ppn->getField('TANGGAL'));
			$i++;
		}
		echo json_encode($met);
	}
}
?>