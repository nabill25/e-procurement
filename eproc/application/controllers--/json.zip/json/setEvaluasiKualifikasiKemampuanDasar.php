<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */


class setEvaluasiKualifikasiKemampuanDasar extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("RekananEvaluasiPengalaman");
		$pengalaman = new RekananEvaluasiPengalaman();
		
		$reqId = httpFilterGet("reqId");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
			$pengalaman->setField("FIELD", "MEMENUHI_SYARAT");
			$pengalaman->setField("FIELD_VALUE", "(SELECT DECODE(COALESCE(MEMENUHI_SYARAT, 0), 0, 1, 0) FROM REKANAN_EVAL_PENGALAMAN X WHERE X.REKANAN_EVAL_PENGALAMAN_ID = A.REKANAN_EVAL_PENGALAMAN_ID)");
			$pengalaman->setField("PAKET_REKANAN_ID", $reqId);
			$pengalaman->updateByField();
		$met = array();
		$i=0;
		
		$met[0]['STATUS'] = 1;
		echo json_encode($met);
	}
}
?>