<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class panel_rekanan_peringkat_data_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PanelRekanan");
		$panel_rekanan = new PanelRekanan();
		
		$reqId = httpFilterGet("reqId");
		$reqBidangUsaha = httpFilterGet("reqBidangUsaha");
		
		$panel_rekanan->selectByParamsMonitoring(array("A.PANEL_ID" => $reqId, "MD5(P.PANEL_BIDANG_USAHA_ID)" => $reqBidangUsaha), -1, -1, " AND P.PERINGKAT IS NOT NULL ");
		$i=0;
		while($panel_rekanan->nextRow())
		{
				
			$met[$i]['PANEL_REKANAN_ID'] = $panel_rekanan->getField("PANEL_REKANAN_ID");
			$met[$i]['NILAI_PANEL'] = $panel_rekanan->getField("NILAI_PANEL");
			$met[$i]['PERINGKAT'] = $panel_rekanan->getField("PERINGKAT");
			$i++;
		}
		echo json_encode($met);	
	}
}
?>