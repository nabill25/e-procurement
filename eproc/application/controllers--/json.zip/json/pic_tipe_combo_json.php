<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class pic_tipe_combo_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("PaketProgresTemplate");
		
		$paket_progres_template= new PaketProgresTemplate();
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		$reqTipe= httpFilterGet("reqTipe");
		$reqId= httpFilterGet("reqId");
		
		$arr_json = array();
		$i = 0;
		
		// paket_progres_templatekondisi
		if($reqTipe == "9")
			$paket_progres_template->selectByParamsPicUserLogin(array(),-1,-1, " AND USER_TYPE_ID = 9 ");
		else
		{
			if($reqId == "")
			{
				if($userLogin->unitKerjaId == 1 || $userLogin->unitKerjaId == 2 || $userLogin->unitKerjaId == 24)
					$statement .= " AND UPPER(NAMA_SEK) LIKE '%%' AND KD_PEL = '".generateZero($userLogin->unitKerjaId, 2)."' ";
				else
					$statement .= " AND KD_PEL = '".generateZero($userLogin->unitKerjaId, 2)."' ";
		
			}
			else
				$statement .= " AND NIPP = '".$reqId."' ";
		
			$paket_progres_template->selectByParamsPic(array(),-1,-1,$statement);
		}
		
		while($paket_progres_template->nextRow()){
			$arr_json[$i]['id'] = $paket_progres_template->getField("USER_LOGIN_ID");
			$arr_json[$i]['text'] = $paket_progres_template->getField("USER_NAMA");
			$i++;
		}
		
		$arr_json[$i]['id'] = "150000000";
		$arr_json[$i]['text'] = "KHUSUS TESTING";
		
		echo json_encode($arr_json);
	}
}
?>