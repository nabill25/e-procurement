<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/pdf.func.php");
include_once("WEB-INF/functions/encrypt2.func.php");
include_once("WEB-INF/classes/utils/FileHandler.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class dokumen_pengadaan_upload_rekanan extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->model("PaketDokumen");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$paket_dokumen = new PaketDokumen();
		$file = new FileHandler();
		
		$reqMode = httpFilterRequest("reqMode");
		$reqId = httpFilterRequest("reqId");
		$reqCetak= httpFilterPost('reqCetak');
		$reqNamaDokumen= httpFilterPost('reqNamaDokumen');
		$reqDokumenKe = httpFilterPost('reqDokumenKe');
		$reqKeterangan= httpFilterPost('reqKeterangan');
		$reqJenisDokumen= httpFilterPost('reqJenisDokumen'); 
		$reqLinkFile= $_FILES['reqLinkFile'.$reqDokumenKe];
		$reqBayar= httpFilterPost('reqBayar');
		$reqToken= httpFilterPost('reqToken');
		$reqDokumenId = httpFilterGet('reqDokumenId');
		$submitSimpan= httpFilterPost('submitSimpan');
		$FILE_DIR = "uploads/penawaran/";
		
		$renameFile = md5(date("dmYHis").$reqLinkFile['name'].$userLogin->userRekanan).".".getExtension($reqLinkFile['name']);
		if($file->uploadToDir('reqLinkFile'.$reqDokumenKe, $FILE_DIR, $renameFile))
		{
			$paket_dokumen->setField("REKANAN_USER_ID", $userLogin->userRekanan);
			$paket_dokumen->setField("PAKET_ID", $reqId);
			$paket_dokumen->setField("NAMA", $reqNamaDokumen);
			$paket_dokumen->setField("UKURAN", $file->uploadedSize);
			$paket_dokumen->setField("TIPE", $file->uploadedExtension);
			$paket_dokumen->setField("PATH_FILE", $file->uploadedFileName);
			$paket_dokumen->setField("JENIS_DOKUMEN", $reqJenisDokumen);
			$paket_dokumen->setField("KETERANGAN", $reqKeterangan);
			$paket_dokumen->setField("FILE_PASSWORD", $reqToken);
			$paket_dokumen->insert();
			echo "Dokumen berhasil diupload.";
		}
		else
			echo "Dokumen gagal diupload.";
	}

	function upload_validasi() 
	{

		$this->load->model("PaketDokumen");
		$this->load->model("PaketRekanan");
		$this->load->model("PaketTahap");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->library("paketinfo"); $paketInfo = new paketinfo();
		
		$paket_rekanan = new PaketRekanan();
		$paket_dokumen = new PaketDokumen();
		$paket_tahap = new PaketTahap();
		$paket_tahap_metode = new PaketTahap();
		$file = new FileHandler();
		
		$reqMode = httpFilterRequest("reqMode");
		$reqId = httpFilterRequest("reqId");
		$reqCetak= httpFilterPost('reqCetak');
		$reqNamaDokumen= httpFilterPost('reqNamaDokumen');
		$reqDokumenKe = httpFilterPost('reqDokumenKe');
		$reqKeterangan= httpFilterPost('reqKeterangan');
		$reqJenisDokumen= httpFilterPost('reqJenisDokumen'); 
		$reqLinkFile= $_FILES['reqLinkFile'.$reqDokumenKe];
		$reqBayar= httpFilterPost('reqBayar');
		$reqDokumenId = httpFilterGet('reqDokumenId');
		$submitSimpan= httpFilterPost('submitSimpan');
		$FILE_DIR = "uploads/penawaran/";
		
		$paketInfo->getPaket($reqId);
		$paket_rekanan->selectByParamsPaketLelang(array("PAKET_ID" => $reqId, "REKANAN_ID" => $userLogin->userRekanan));
		$paket_rekanan->firstRow();		
		
		$reqToken= md5($paketInfo->pr_group_number.$paket_rekanan->getField("TANGGAL_DAFTAR_ENKRIPSI").$paket_rekanan->getField("KODE_REKANAN").$reqId.$paketInfo->user_login_id);

		/* VALIDASI WAKTU HABIS */
		$jenis_tahap = $paket_tahap_metode->getJenisTahapById($reqId);
		$arrDokumenPenawaran 	 	 = array(0, 11, 6,  11, 6,  10, 6,  11, 11);
		$aktif_dok_penawaran1 = $paket_tahap->getCountByParamsAktif(array("URUT" => $arrDokumenPenawaran[$jenis_tahap], "PAKET_ID" => $reqId, "TAMPILKAN" => 1, "HADIR" => 0));
		
		if($aktif_dok_penawaran1 == 0)
		{
			echo "Waktu pemasukan / upload penawaran telah berakhir. Dokumen penawaran gagal diupload.";	
			return;
		}
		
		$renameFile = md5(date("dmYHis").$reqLinkFile['name'].$userLogin->userRekanan).".".getExtension($reqLinkFile['name']);
		if($file->uploadToDir('reqLinkFile'.$reqDokumenKe, $FILE_DIR, $renameFile))
		{
			//password for the pdf file
			$password = $reqToken;
			//name of the original file (unprotected)
			$origFile = $FILE_DIR.$renameFile;
			//name of the destination file (password protected and printing rights removed)
			$destFile = $FILE_DIR."enc".$renameFile;
			//encrypt the book and create the protected file
			if(pdfEncrypt($origFile, $password, $destFile ))	
			{
				/**/
				unlink($origFile);
							
				$paket_dokumen->setField("REKANAN_USER_ID", $userLogin->userRekanan);
				$paket_dokumen->setField("PAKET_ID", $reqId);
				$paket_dokumen->setField("NAMA", $reqNamaDokumen);
				$paket_dokumen->setField("UKURAN", $file->uploadedSize);
				$paket_dokumen->setField("TIPE", $file->uploadedExtension);
				$paket_dokumen->setField("PATH_FILE", "enc".$renameFile);
				$paket_dokumen->setField("JENIS_DOKUMEN", $reqJenisDokumen);
				$paket_dokumen->setField("KETERANGAN", $reqLinkFile['name']);
				$paket_dokumen->insert();
				
				echo "Dokumen berhasil diupload.";

			}
			else
				echo "Dokumen gagal diupload.";
		}
	}	

	function upload() 
	{

		$this->load->model("PaketDokumen");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$paket_dokumen = new PaketDokumen();
		$file = new FileHandler();
		
		$reqMode = httpFilterRequest("reqMode");
		$reqId = httpFilterRequest("reqId");
		$reqCetak= httpFilterPost('reqCetak');
		$reqNamaDokumen= httpFilterPost('reqNamaDokumen');
		$reqDokumenKe = httpFilterPost('reqDokumenKe');
		$reqKeterangan= httpFilterPost('reqKeterangan');
		$reqJenisDokumen= httpFilterPost('reqJenisDokumen'); 
		$reqLinkFile= $_FILES['reqLinkFile'.$reqDokumenKe];
		$reqBayar= httpFilterPost('reqBayar');
		$reqDokumenId = httpFilterGet('reqDokumenId');
		$submitSimpan= httpFilterPost('submitSimpan');
		$FILE_DIR = "uploads/penawaran/";
		$reqToken= md5($userLogin->userRekanan.$reqId);
		
		$renameFile = md5(date("dmYHis").$reqLinkFile['name'].$userLogin->userRekanan).".".getExtension($reqLinkFile['name']);
		if($file->uploadToDir('reqLinkFile'.$reqDokumenKe, $FILE_DIR, $renameFile))
		{
			//password for the pdf file
			$password = $reqToken;
			//name of the original file (unprotected)
			$origFile = $FILE_DIR.$renameFile;
			//name of the destination file (password protected and printing rights removed)
			$destFile = $FILE_DIR."enc".$renameFile;
			//encrypt the book and create the protected file
			if(pdfEncrypt($origFile, $password, $destFile ))	
			{
				/**/
				unlink($origFile);
							
				$paket_dokumen->setField("REKANAN_USER_ID", $userLogin->userRekanan);
				$paket_dokumen->setField("PAKET_ID", $reqId);
				$paket_dokumen->setField("NAMA", $reqNamaDokumen);
				$paket_dokumen->setField("UKURAN", $file->uploadedSize);
				$paket_dokumen->setField("TIPE", $file->uploadedExtension);
				$paket_dokumen->setField("PATH_FILE", "enc".$renameFile);
				$paket_dokumen->setField("JENIS_DOKUMEN", $reqJenisDokumen);
				$paket_dokumen->setField("KETERANGAN", $reqLinkFile['name']);
				$paket_dokumen->insert();
				
				echo "Dokumen berhasil diupload.";

			}
			else
				echo "Dokumen gagal diupload.";
		}
	}	

	function add_administrasi() 
	{

		$this->load->model("RekananEvaluasiAdminTawar");

		$reqPaketRekananId = $_POST["reqPaketRekananId"];
		$reqPaketEvaluasiId = $_POST["reqPaketEvaluasiId"];
		$reqUraian = $_POST["reqUraian"];
		
		$tidak_ada = 0;
		for($i=0;$i<count($reqPaketRekananId);$i++)
		{
			if(trim($reqUraian[$i]) == "")
				$tidak_ada++;
				
			$rekanan_evaluasi_admin = new RekananEvaluasiAdminTawar();
			$check = $rekanan_evaluasi_admin->getCountByParams(array("PAKET_REKANAN_ID" => $reqPaketRekananId[$i], "PAKET_EVAL_ADMIN_TAWAR_ID" => $reqPaketEvaluasiId[$i]));
			if($check == 0)
			{
				if(trim($reqUraian[$i]) == "")
				{}
				else
				{
					$rekanan_evaluasi_admin->setField("URAIAN", $reqUraian[$i]);
					$rekanan_evaluasi_admin->setField("PAKET_REKANAN_ID", $reqPaketRekananId[$i]);
					$rekanan_evaluasi_admin->setField("PAKET_EVAL_ADMIN_TAWAR_ID", $reqPaketEvaluasiId[$i]);
					$rekanan_evaluasi_admin->insertUraian();							
				}
			}
			else
			{
				$rekanan_evaluasi_admin->setField("URAIAN", $reqUraian[$i]);
				$rekanan_evaluasi_admin->setField("PAKET_REKANAN_ID", $reqPaketRekananId[$i]);
				$rekanan_evaluasi_admin->setField("PAKET_EVAL_ADMIN_TAWAR_ID", $reqPaketEvaluasiId[$i]);
				$rekanan_evaluasi_admin->updateUraian();
			}
			unset($rekanan_evaluasi_admin);	
		}
		
		if($tidak_ada > 0)
			echo "Lengkapi data terlebih dahulu.";
		else
			echo "1";
			
	}

	function email() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->library("paketinfo"); $paketInfo = new paketinfo();

		$this->load->library("KMail");	
		$this->load->model("PaketRekanan");			
		
		$reqId = $this->input->get("reqId");
		
		$paket_rekanan = new PaketRekanan();
		$paket_rekanan->selectByParamsEmail(array("A.REKANAN_ID" => $userLogin->userRekanan, "A.PAKET_ID" => $reqId));
		$paket_rekanan->firstRow();
		
		
		$paketInfo->getPaket($reqId);

		/* BUAT FILE */		
		$reqFilename= $paketInfo->pr_group_number."-".$paket_rekanan->getField("KODE_REKANAN");
		//$reqToken= md5($userLogin->userRekanan.$reqId);
		$reqToken= md5($paketInfo->pr_group_number.$paket_rekanan->getField("TANGGAL_DAFTAR_ENKRIPSI").$paket_rekanan->getField("KODE_REKANAN").$reqId.$paketInfo->user_login_id);
		
		$reqFile = "uploads/penawaran/".$reqFilename.".cert";
		$myfile = fopen($reqFile, "w");
		$myfile = fopen($reqFile, "w") or die("Unable to open file!");
		$txt = $reqToken;
		fwrite($myfile, $txt);
		fclose($myfile);	
		
		$mail = new KMail();
		$mail->AddAddress($paket_rekanan->getField("EMAIL") , $paket_rekanan->getField("NAMA"));
		$mail->Subject  =  "Konfirmasi Upload Dokumen Penawaran";
		$mail->AddAttachment( $reqFile, $reqFilename.".cert");
		$body = file_get_contents(base_url()."main/loadUrl/email/dokumen_penawaran_upload/".$reqId."/".$userLogin->userRekanan);
		$mail->MsgHTML($body);
		if($mail->Send())
		{
			unlink($reqFile);
			echo 'Email sertifikat berhasil dikirim.';
		}
		else
			echo "gagal";
		
		unset($mail);
	}

	function upload_evaluasi() 
	{

		$this->load->model("PaketDokumen");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$paket_dokumen = new PaketDokumen();
		$file = new FileHandler();
		
		$reqMode = httpFilterRequest("reqMode");
		$reqId = httpFilterRequest("reqId");
		$reqCetak= httpFilterPost('reqCetak');
		$reqNamaDokumen= httpFilterPost('reqNamaDokumen');
		$reqDokumenKe = httpFilterPost('reqDokumenKe');
		$reqRekananId = httpFilterPost('reqRekananId');
		$reqKeterangan= httpFilterPost('reqKeterangan');
		$reqJenisDokumen= httpFilterPost('reqJenisDokumen'); 
		$reqLinkFile= $_FILES['reqLinkFile'.$reqRekananId];
		$reqBayar= httpFilterPost('reqBayar');
		$reqDokumenId = httpFilterGet('reqDokumenId');
		$submitSimpan= httpFilterPost('submitSimpan');
		$FILE_DIR = "uploads/penawaran/";
		$renameFile = md5(date("dmYHis").$reqLinkFile['name'].$userLogin->UID).".".getExtension($reqLinkFile['name']);
		;
		if($file->uploadToDir('reqLinkFile'.$reqRekananId, $FILE_DIR, $renameFile))
		{
							
			$paket_dokumen->setField("REKANAN_USER_ID", $reqRekananId);
			$paket_dokumen->setField("PAKET_ID", $reqId);
			$paket_dokumen->setField("NAMA", $reqNamaDokumen);
			$paket_dokumen->setField("UKURAN", $file->uploadedSize);
			$paket_dokumen->setField("TIPE", $file->uploadedExtension);
			$paket_dokumen->setField("PATH_FILE", $renameFile);
			$paket_dokumen->setField("JENIS_DOKUMEN", $reqJenisDokumen);
			$paket_dokumen->setField("KETERANGAN", $reqLinkFile['name']);
			$paket_dokumen->deleteByJenisPaketAdmin();
			$paket_dokumen->insert();
			
			echo "Dokumen berhasil diupload.";

		}
	}		

	function upload_surat_penawaran() 
	{

		$this->load->model("PaketDokumen");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$paket_dokumen = new PaketDokumen();
		$file = new FileHandler();
		
		$reqMode = httpFilterRequest("reqMode");
		$reqId = httpFilterRequest("reqId");
		$reqCetak= httpFilterPost('reqCetak');
		$reqNamaDokumen= httpFilterPost('reqNamaDokumen');
		$reqDokumenKe = httpFilterPost('reqDokumenKe');
		$reqRekananId = httpFilterPost('reqRekananId');
		$reqKeterangan= httpFilterPost('reqKeterangan');
		$reqJenisDokumen= httpFilterPost('reqJenisDokumen'); 
		$reqLinkFile= $_FILES['reqLinkFile'.$reqRekananId];
		$reqBayar= httpFilterPost('reqBayar');
		$reqDokumenId = httpFilterGet('reqDokumenId');
		$submitSimpan= httpFilterPost('submitSimpan');
		$FILE_DIR = "uploads/penawaran/";
		$renameFile = md5(date("dmYHis").$reqLinkFile['name'].$userLogin->UID).".".getExtension($reqLinkFile['name']);
		;
		if($file->uploadToDir('reqLinkFile'.$reqRekananId, $FILE_DIR, $renameFile))
		{
							
			$paket_dokumen->setField("REKANAN_USER_ID", $reqRekananId);
			$paket_dokumen->setField("PAKET_ID", $reqId);
			$paket_dokumen->setField("NAMA", $reqNamaDokumen);
			$paket_dokumen->setField("UKURAN", $file->uploadedSize);
			$paket_dokumen->setField("TIPE", $file->uploadedExtension);
			$paket_dokumen->setField("PATH_FILE", $renameFile);
			$paket_dokumen->setField("JENIS_DOKUMEN", $reqJenisDokumen);
			$paket_dokumen->setField("KETERANGAN", $reqLinkFile['name']);
			$paket_dokumen->deleteByJenisPaket();
			$paket_dokumen->insert();
			
			echo "Dokumen berhasil diupload.";

		}
	}	
		
}
?>