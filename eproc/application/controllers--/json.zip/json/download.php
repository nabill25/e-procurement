<?php

include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/string.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class download extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$reqMode = httpFilterGet("reqMode");
		$reqRowId= httpFilterGet("reqRowId");
		
		if($reqMode == "paket_work_order")
		{
			$this->load->model("PaketProgresDetil");
			
			$lampiran = new PaketProgresDetil();
			$lampiran->selectByParamsBlob(array("PAKET_PROGRES_DETIL_ID" => $reqRowId), -1, -1);
			$FILE_DIR= "uploads/progres_paket/";
		}
		
		$lampiran->firstRow();
		if($lampiran->getField('TIPE') == 'image/jpeg')
		{
			$tempFormat=str_replace('jpeg','jpg',$lampiran->getField('TIPE'));
		}
		else
		{
			$tempFormat=$lampiran->getField('TIPE');
		}
		
		$tipe = $tempFormat;
		$isi = $FILE_DIR.$lampiran->getField("PATH_FILE");
		$nama = $reqMode;//str_replace(" ","",$lampiran->getField("NOMOR"));
		
		header("Content-type: $tipe");
		header('Content-Disposition: filename="'.$reqMode.'"');
		header('Content-Disposition: attachment; filename='.$reqMode.'.'.getExe($tipe));		
		
		$isi= file_get_contents($isi);
		echo $isi;
	}
}
?>
