<?php
/* INCLUDE FILE */

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/functions/default.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class anggaran_get_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Anggaran");
		$anggaran = new Anggaran();
		
		$reqId = httpFilterGet("reqId");
		
		$anggaran->selectByParams(array("NO_PPA" => $reqId));
		$anggaran->firstRow();
		$orders[] = array(
						'NAMA' => $anggaran->getField("KET_TAMBAH"),
						'NO_PPA' => $anggaran->getField("NO_PPA")
					);
		
		echo json_encode($orders);
	}
}
?>