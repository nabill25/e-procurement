<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class getDataTambahRekananEmail extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Rekanan");
		$rekanan = new Rekanan();
		
		$reqId = httpFilterGet("reqId");
		$reqNamaRekanan = httpFilterGet("reqNamaRekanan");
		
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		
		if($reqNamaRekanan == ''){
			if($reqId > 0)
			$rekanan->selectByParams(array("STATUS_VALIDASI"=>1), -1, -1, " AND NOT REKANAN_ID IN (".$reqId.")"); 
			else
			$rekanan->selectByParams(array("STATUS_VALIDASI"=>1), -1, -1); 
			//echo $rekanan->query;
		}else{
			if($reqId > 0)
			$rekanan->selectByParams(array("STATUS_VALIDASI"=>1), -1, -1, " AND (UPPER(C.NAMA || ' ' || A.NAMA)) LIKE '%".strtoupper($reqNamaRekanan)."%' AND NOT REKANAN_ID IN (".$reqId.")"); 
			else
			$rekanan->selectByParams(array("STATUS_VALIDASI"=>1), -1, -1, " AND (UPPER(C.NAMA || ' ' || A.NAMA)) LIKE '%".strtoupper($reqNamaRekanan)."%'");
		}
		$met = array();
		$i=0;
		
		while($rekanan->nextRow()){
			$met[$i]['NAMA'] = $rekanan->getField('NAMA');
			$met[$i]['EMAIL'] = $rekanan->getField('EMAIL');
			$met[$i]['REKANAN_ID'] = $rekanan->getField('REKANAN_ID');
			$i++;
		}
		echo json_encode($met);
	}
}
?>