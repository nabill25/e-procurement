<?php
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

class unit_kerja_pic_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("UnitKerja");
		$unit_kerja = new UnitKerja();
		
		/* LOGIN CHECK 
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}
		*/
		$reqKeterangan = httpFilterRequest("reqKeterangan");
		$reqId = httpFilterRequest("reqId");
		$reqSearch = httpFilterGet("reqSearch");
		
		
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		
		/*
		 * Ordering
		 */
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
			
		if($reqSearch == "")
		{	
			$allRecord = $unit_kerja->getCountByParams(array(), $statement);
			$unit_kerja->selectByParamsMonitoringPic(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement);
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = $unit_kerja->getCountByParamsMonitoring(array(), $statement.$reqSearch);
			$unit_kerja->selectByParamsMonitoringPic(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		
		}
		
		$column = array('UNIT_KERJA_ID', 'NO', 'UNIT_KERJA', 'JUMLAH');
		
			/*
			 * Output 
			 */
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$tmp='';	$number = 1;
			while($unit_kerja->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					if($column[$i]=='NO')		$row[] = $number;
					else						$row[] = $unit_kerja->getField(trim($column[$i]));
				}
				$number++;
				$output['aaData'][] = $row;
			}
				
			echo json_encode( $output );
	}
	
	function add()
	{
		$this->load->model('UnitKerjaPic');
		
		$reqDelete = httpFilterPost("reqDelete");
		$reqId = httpFilterPost("reqId");
		$reqMode = httpFilterPost("reqMode");
		
		$reqUnitKerjaPicId = $this->input->post("reqUnitKerjaPicId");
		$reqNip = $this->input->post("reqNip");
		$reqNama = $this->input->post("reqNama");
		
		if($reqDelete == '0')
		{}
		else
		{
			$arrDeleteOut = explode(",", $reqDelete);
			for($d=0;$d<count($arrDeleteOut);$d++)
			{
				$unit_kerja_pic_delete = new UnitKerjaPic();
				$unit_kerja_pic_delete->setField("UNIT_KERJA_PIC_ID", $arrDeleteOut[$d]);
				$unit_kerja_pic_delete->delete();
			}
		}
		
		for($i=0;$i<count($reqNip);$i++)
		{
			if($reqNip[$i] == "")
			{}
			else
			{
				$unit_kerja_pic = new UnitKerjaPic();
				
				$unit_kerja_pic->setField("UNIT_KERJA_PIC_ID", $reqUnitKerjaPicId[$i]);
				$unit_kerja_pic->setField("UNIT_KERJA_ID", $reqId);
				$unit_kerja_pic->setField("NIP", $reqNip[$i]);
				$unit_kerja_pic->setField("NAMA", $reqNama[$i]);
				
				if($reqUnitKerjaPicId[$i] == "")
				{
					$unit_kerja_pic->setField("CREATED_DATE", "SYSDATE");
					$unit_kerja_pic->setField("CREATED_BY", $this->username);
					$unit_kerja_pic->insert();
				}
				else
				{
					$unit_kerja_pic->setField("UPDATED_DATE", "SYSDATE");
					$unit_kerja_pic->setField("UPDATED_BY", $this->username);
					$unit_kerja_pic->update();
				}
				unset($unit_kerja_pic);
			}
		}
		
		echo "Data berhasil disimpan.";
		
	}
	
	function delete() 
	{
		$this->load->model('UnitKerjaPic');
		$unit_kerja_pic = new UnitKerjaPic();
		
		$reqId =  $this->input->get('reqId');
		
		$unit_kerja_pic->setField("UNIT_KERJA_PIC_ID", $reqId);
		
		if($unit_kerja_pic->delete())
			$arrJson["PESAN"] = "Data berhasil dihapus.";
		else
			$arrJson["PESAN"] = "Data gagal dihapus.";		
		
		echo json_encode($arrJson);
		
	}
}
?>
