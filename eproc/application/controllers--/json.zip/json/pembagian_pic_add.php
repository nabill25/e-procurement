<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class pembagian_pic_add extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->model("PaketProgres");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$reqId = httpFilterPost("reqId");
		$reqMode = httpFilterPost("reqMode");
		
		$reqPegawaiId= $_POST["reqPegawaiId"];
		$reqNamaId= $_POST["reqNamaId"];
		$reqNama= $_POST["reqNama"];
		$reqKeterangan= $_POST["reqKeterangan"];
		$reqUrut= $_POST["reqUrut"];
		$reqTanggalAwalRen= $_POST["reqTanggalAwalRen"];
		$reqTanggalAkhirRen= $_POST["reqTanggalAkhirRen"];
		$reqArrayIndex= $_POST["reqArrayIndex"];
		$set_loop= $reqArrayIndex;
							
		if($reqMode == "insert")
		{
			$set= new PaketProgres();
			$set->setField("PAKET_ID", $reqId);
			$set->delete();
			unset($set);
			
			for($i=0;$i<=$set_loop;$i++)
			{
				if($reqPegawaiId[$i] == "")
				{}
				else
				{
				$index = $i;
				$set= new PaketProgres();
				
				$set->setField("TANGGAL_AWAL_REN", dateToDBCheck($reqTanggalAwalRen[$index]));
				$set->setField("TANGGAL_AKHIR_REN", dateToDBCheck($reqTanggalAkhirRen[$index]));
				$set->setField("NAMA", $reqNama[$index]);
				$set->setField("PAKET_PROGRES_TEMPLATE_ID", $reqNamaId[$index]);
				$set->setField("USER_LOGIN_ID", ValToNullDB($reqPegawaiId[$index]));
				$set->setField("KETERANGAN", $reqKeterangan[$index]);
				$set->setField("PAKET_ID", ValToNullDB($reqId));
				$set->setField("URUT", $reqUrut[$index]);
				$set->setField("RECRUITMENT_PROGRES_ID", $reqRowId[$i]);
				$set->setField("LAST_CREATE_USER", $userLogin->idUser);
				$set->setField("LAST_CREATE_DATE", "CURRENT_DATE");
				if($set->insert()){}
				//echo $set->query;
				unset($set);
				}
			}
			echo "Data berhasil disimpan.";
		}
	}
}
?>