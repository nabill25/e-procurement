<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */

class aanwijzing_publish_validasi_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 		
		$this->load->model("PaketAanwijzingValidasi");
		
		$paket_aanwijzing_validasi = new PaketAanwijzingValidasi();
		
		$reqId = httpFilterGet("reqId");
		/* LOGIN CHECK */
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();  
			if($userLogin->userLevel == 6)
			{
				echo '<script language="javascript">';
				echo 'alert("Anda tidak berhak mengakses halaman ini. IP address anda telah kami catat sebagai rekanan yang mencoba membuka halaman administrator.");';
				echo 'top.location.href = "index.php";';
				echo '</script>';
				exit;		
			}
		}
		$paket_aanwijzing_validasi->selectByParamsValidasiPublish($reqId);
		$paket_aanwijzing_validasi->firstRow();
		$total_anggota = $paket_aanwijzing_validasi->getField("TOTAL_ANGGOTA");
		$total_ttd = $paket_aanwijzing_validasi->getField("TOTAL_TTD");
		$diijinkan = round($paket_aanwijzing_validasi->getField("TOTAL_ANGGOTA") / 2);
		
		if($total_ttd >= $diijinkan)
			$pesan = "1";
		else
			$pesan = "Saat ini tercatat ".$paket_aanwijzing_validasi->getField("TOTAL_TTD")."/".$paket_aanwijzing_validasi->getField("TOTAL_ANGGOTA")." yang telah validasi. Publish diijinkan minimal terdapat ".$diijinkan." validasi.";
									
		$arrFinal = array("PESAN" => $pesan);
		
		echo json_encode($arrFinal);
	}
}
?>