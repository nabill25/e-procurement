<?php
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class daftar_rekanan_belum_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{
		
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Rekanan");
		$rekanan = new Rekanan(); 
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		$reqKeterangan = $this->input->post("reqKeterangan");
		$reqId = $this->input->post("reqId");
		$reqSearch = $this->input->get("reqSearch");
		$reqMode = $this->input->get("reqMode");
		
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		
		/*
		 * Ordering
		 */
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
		
		$statement = " AND COALESCE(STATUS_VALIDASI, 0) = 0 AND TANGGAL_HAPUS IS NULL ";
		//if($reqMode)	$arr_filter .= " AND D.BIDANG_USAHA_ID LIKE '".$reqMode."%' ";
		if($reqMode)	$arr_filter .= " AND EXISTS (SELECT 1
					FROM REKANAN_BIDANG_USAHA X
					WHERE X.REKANAN_ID = A.REKANAN_ID AND X.IJIN_USAHA_ID = A.IJIN_USAHA_ID AND X.BIDANG_USAHA_ID LIKE '".$reqMode."%') ";
		
		if($reqSearch == "")
		{	
			/*if($reqMode){
				$allRecord = $rekanan->getCountByParamsJenisUsaha(array(), $statement.$arr_filter);
				$rekanan->selectByParamsJenisUsaha(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$arr_filter);
			}else{*/
				$allRecord = $rekanan->getCountByParams(array(), $statement.$arr_filter);
				$rekanan->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$arr_filter);
			//}
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = 1;
			//$rekanan->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		
		}				   
		$column = array('REKANAN_ID', 'NO', 'KODE', 'NAMA','KOTA','TANGGAL_DAFTAR');
			/*
			 * Output 
			 */
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$number = 1;
			while($rekanan->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					if($column[$i]=='NO')		$row[] = $number;
					elseif($column[$i]=='TANGGAL_DAFTAR') $row[] = strtoupper(getFormattedDateJson($rekanan->getField(trim($column[$i]))));
					else						$row[] = strtoupper($rekanan->getField(trim($column[$i])));
				}
				
				$output['aaData'][] = $row;
				$number++;
			}
			
			echo json_encode( $output );
	}
}
?>
