<?php

include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");
include_once("WEB-INF/classes/utils/Validate.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class blacklist_json extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	
	function json() 
	{
		$this->load->library("kauth");  $userLogin = new kauth(); 
		$this->load->model("Blacklist");
		$blacklist = new Blacklist();
		
		/* LOGIN CHECK 
		if ($userLogin->checkUserLogin()) 
		{ 
			$userLogin->retrieveUserInfo();
		}*/
		
		ini_set("memory_limit","500M");
		ini_set('max_execution_time', 520);
		
		$reqKeterangan = httpFilterRequest("reqKeterangan");
		$reqId = httpFilterRequest("reqId");
		$reqSearch = httpFilterGet("reqSearch");
		
		/* 
		 * Paging
		 */
		$sLimit = "";
		if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
		{
			$sLimit = "LIMIT ".mysql_real_escape_string( $_GET['iDisplayStart'] ).", ".
				mysql_real_escape_string( $_GET['iDisplayLength'] );
		}
		else{
			$_GET['iDisplayStart'] = $_GET['iDisplayLength'] = '-1';
		}
		
		/*
		 * Ordering
		 */
		$sOrder = "";
			if ( isset( $_GET['iSortCol_0'] ) )
			{
				$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$sOrder .= 'upper('.$aColumns[ intval( $_GET['iSortCol_'.$i] ) ].") 
							".mysql_real_escape_string( $_GET['sSortDir_'.$i] ) .", ";
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
			}
		
				
		if($reqSearch == "")
		{	
			$allRecord = $blacklist->getCountByParams();
			$blacklist->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement);
		}
		else
		{
			$reqSearch = str_replace('\\', '', $reqSearch);
			$allRecord = 1;
			//$blacklist->selectByParams(array(), $_GET['iDisplayLength'], $_GET['iDisplayStart'], $statement.$reqSearch." ");
		
		}
		
		 
		$column = array('BLACKLIST_ID', 'NO', 'NAMA', 'ALAMAT','NPWP','TANGGAL','ALASAN','NO_SK');
			/*
			 * Output 
			 */
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => $allRecord,
				"iTotalDisplayRecords" => $allRecord,
				"aaData" => array()
			);
			$number = 1;
			while($blacklist->nextRow())
			{
				$row = array();
				for ( $i=0 ; $i<count($column) ; $i++ )
				{
					if($column[$i]=='NO')		$row[] = $number;
					elseif($column[$i]=='TANGGAL')	$row[] = getFormattedDate($blacklist->getField("TANGGAL_MULAI"))." s/d ".getFormattedDate($blacklist->getField("TANGGAL_SELESAI"));
					else						$row[] = $blacklist->getField(trim($column[$i]));
				}
				$number++;
				$output['aaData'][] = $row;
			}
			
			echo json_encode( $output );
	}
	
	function blacklist_add_coba() 
	{
		/* INCLUDE FILE */
		$this->load->model("Blacklist");
		$this->load->model("Rekanan");
		
		/* create objects */
		$blacklist = new Blacklist();
		
		/* VARIABLE */
		$reqPerusahaan	= $this->input->post("reqPerusahaan");
		$reqNama	= $this->input->post("reqNama");
		$reqAlamat	= $this->input->post("reqAlamat");
		$reqAlasan	= $this->input->post("reqAlasan");
		$reqKota	= $this->input->post("reqKota");
		$reqNPWP	= $this->input->post("reqNPWP");
		$reqTanggalMulai	= $this->input->post("reqTanggalMulai");
		$reqTanggalSelesai	= $this->input->post("reqTanggalSelesai");
		$reqNoSk	= $this->input->post("reqNoSk");
		$reqRekananId	= $this->input->post("reqRekananId");
		$reqSubmit	= $this->input->post("reqSubmit");
		
		/* VALIDATION */
			echo "fsdfsdf";
		// trigger the validation
		/* ACTION BY REQMODE */
		if($reqSubmit == "Simpan"){
			$blacklist->setField("ALAMAT",$reqAlamat);
			$blacklist->setField("ALASAN",$reqAlasan);
			$blacklist->setField("KOTA",$reqKota);
			$blacklist->setField("NPWP",$reqNPWP);
			$blacklist->setField("TANGGAL_MULAI",dateToDBCheck($reqTanggalMulai));
			$blacklist->setField("TANGGAL_SELESAI",dateToDBCheck($reqTanggalSelesai));
			$blacklist->setField("NO_SK",$reqNoSk);
			$blacklist->setField("REKANAN_TIPE_ID",$reqPerusahaan);
			
			if($reqPerusahaan == 1) $reqPerusahaan = "PT";
			elseif($reqPerusahaan == 2) $reqPerusahaan = "CV";
			elseif($reqPerusahaan == 3) $reqPerusahaan = "Firma";
			elseif($reqPerusahaan == 4) $reqPerusahaan = "Koperasi";
			elseif($reqPerusahaan == 5) $reqPerusahaan = "UD";
			elseif($reqPerusahaan == 6) $reqPerusahaan = "Lain-lain";
				
			$blacklist->setField("NAMA",$reqPerusahaan." ".$reqNama);
			$blacklist->setField("REKANAN_ID",ValToNullDB($reqRekananId));
			//$blacklist->setField("STATUS","null");
			$blacklist->setField("STATUS",1);
			if($blacklist->insert())
			{
				echo "Data berhasil di Simpan";

			}
			else
			{
				echo "Data gagal di Simpan";
			}
		
		
		}
	}
}
?>
