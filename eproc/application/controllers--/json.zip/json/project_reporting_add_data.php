<?php
/* INCLUDE FILE */
include_once("WEB-INF/functions/string.func.php");
include_once("WEB-INF/functions/default.func.php");
include_once("WEB-INF/functions/date.func.php");

defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * @package 	eProcurement Application
 * @author 		eproc2025
 * @since 		25. Version 3.1
 * 
 */
class project_reporting_add_data extends CI_Controller {

	function __construct() {
		parent::__construct(); $this->db->query("SET TIME ZONE 'Asia/Jakarta'"); 
	}
	function json() 
	{

		$this->load->model("IntegrasiAIM");
		$this->load->library("kauth");  $userLogin = new kauth(); 
		
		$integrasi_aim = new IntegrasiAIM();
		
		$reqId = httpFilterPost("reqId");
		$reqRealisasiId = httpFilterPost("reqRealisasiId");
		$reqMode = httpFilterPost("reqMode");
		$reqTanggal = httpFilterPost("reqTanggal");
		$reqProgres = httpFilterPost("reqProgres");
		$reqKeterangan = httpFilterPost("reqKeterangan");
		$reqKendala = httpFilterPost("reqKendala");
		$reqLampiranLaporan = $_FILES["reqLampiranLaporan"];
		$reqLampiran = $_FILES["reqLampiran"];
		$reqLampiranTemp = $_POST["reqLampiranTemp"];
		$reqLampiranLaporanTemp = httpFilterPost("reqLampiranLaporanTemp");
		
							
		$integrasi_aim->setField('SUB_PROGRAM_SP2_REALISASI_ID', $reqRealisasiId);
		$integrasi_aim->setField('SUB_PROGRAM_SP2_ID', $reqId);
		$integrasi_aim->setField('PROGRES', $reqProgres);
		$integrasi_aim->setField('TANGGAL', dateToDBCheck($reqTanggal));
		$integrasi_aim->setField('NAMA', $reqNama);
		$integrasi_aim->setField('KETERANGAN', $reqKeterangan);
		$integrasi_aim->setField('KENDALA', $reqKendala);
		$integrasi_aim->setField('CREATED_BY', $userLogin->UID);
		$integrasi_aim->setField("CREATED_DATE", "SYSDATE");
		$integrasi_aim->setField('UPDATED_BY', $userLogin->UID);
		$integrasi_aim->setField("UPDATED_DATE", "SYSDATE");

		/* START UPLOAD FILE */
		$FILE_DIR = "uploads/pelaporan/";
		for($i=0;$i<count($reqLampiranLaporan);$i++)
		{	
			if($reqLampiranLaporan['name'][$i] == "")
			{}
			else			
			{
				$renameFile = md5(date("dmYHis").$reqLampiranLaporan['name'][$i]).".".getExtension($reqLampiranLaporan['name'][$i]);
				if (move_uploaded_file($reqLampiranLaporan['tmp_name'][$i], $FILE_DIR.$renameFile))
				{
					if($i == 0)	
						$insertLinkFile = $renameFile;
					else
						$insertLinkFile .= ",".$renameFile;
					
				}			
			}	
		}
		
		if($insertLinkFile == "")
			$insertLinkFile = $reqLampiranLaporanTemp;
			
		$integrasi_aim->setField("LINK_FILE", $insertLinkFile);


		$insertLinkFile = "";
		for($i=0;$i<count($reqLampiran);$i++)
		{	
			if($reqLampiran['name'][$i] == "")
			{}
			else			
			{
				$renameFile = md5(date("dmYHis").$reqLampiran['name'][$i]).".".getExtension($reqLampiran['name'][$i]);
				if (move_uploaded_file($reqLampiran['tmp_name'][$i], $FILE_DIR.$renameFile))
				{
					if($i == 0)	
						$insertLinkFile = $renameFile;
					else
						$insertLinkFile .= ",".$renameFile;
					
				}			
			}	
		}
		
		for($i=0;$i<count($reqLampiranTemp);$i++)
		{
			if($reqLampiranTemp[$i] == "")
			{}
			else
			{
				if($insertLinkFile == "")	
					$insertLinkFile = $reqLampiranTemp[$i];
				else
					$insertLinkFile .= ",".$reqLampiranTemp[$i];
			}
		}
			
		$integrasi_aim->setField("LINK_FOTO", $insertLinkFile);					
			
		if($reqMode == "insert")
		{	
			if($integrasi_aim->insertRealisasiKontrak())
			{
				$reqRealisasiId = $integrasi_aim->id;
				echo "Data berhasil disimpan.-".$reqId."-".$reqRealisasiId;
			}
		}
		else
		{
			if($integrasi_aim->updateRealisasiKontrak())
				echo "Data berhasil disimpan.-".$reqId."-".$reqRealisasiId;
		}
	}
}
?>